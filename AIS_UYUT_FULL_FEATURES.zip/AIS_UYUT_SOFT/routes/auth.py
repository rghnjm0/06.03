from flask import render_template, request, redirect, url_for, flash, session, current_app
from datetime import datetime, timedelta
import sqlite3
import os
from db import get_db, DB_NAME
from utils import sync_room_statuses, booking_conflicts, next_id, booking_total
from auth import login_required, admin_required, password_matches, hash_password

LOGIN_MAX_ATTEMPTS = 5
LOGIN_LOCK_MINUTES = 15


def ensure_login_attempts_table(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS Попытки_входа (
            ID INTEGER PRIMARY KEY AUTOINCREMENT,
            Идентификатор TEXT NOT NULL,
            IP TEXT NOT NULL,
            Неудачные_попытки INTEGER NOT NULL DEFAULT 0,
            Заблокировано_до TEXT
        )
    """)
    conn.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS ux_login_attempts_identity_ip
        ON Попытки_входа(Идентификатор, IP)
    """)
    conn.commit()


def get_login_attempt_state(conn, identifier, ip):
    row = conn.execute(
        "SELECT Неудачные_попытки, Заблокировано_до FROM Попытки_входа WHERE Идентификатор=? AND IP=?",
        (identifier, ip)
    ).fetchone()
    if not row:
        return 0, None
    return int(row[0] or 0), row[1]


def record_failed_login(conn, identifier, ip):
    now = datetime.now()
    attempts, _ = get_login_attempt_state(conn, identifier, ip)
    attempts += 1
    locked_until = None
    if attempts >= LOGIN_MAX_ATTEMPTS:
        locked_until = (now + timedelta(minutes=LOGIN_LOCK_MINUTES)).isoformat(timespec="seconds")
        attempts = 0
    conn.execute("""
        INSERT INTO Попытки_входа(Идентификатор, IP, Неудачные_попытки, Заблокировано_до)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(Идентификатор, IP) DO UPDATE SET
            Неудачные_попытки=excluded.Неудачные_попытки,
            Заблокировано_до=excluded.Заблокировано_до
    """, (identifier, ip, attempts, locked_until))
    conn.commit()
    return attempts, locked_until


def clear_login_attempts(conn, identifier, ip):
    conn.execute("DELETE FROM Попытки_входа WHERE Идентификатор=? AND IP=?", (identifier, ip))
    conn.commit()


def login_is_locked(conn, identifier, ip):
    attempts, locked_until = get_login_attempt_state(conn, identifier, ip)
    if not locked_until:
        return False, attempts, 0
    try:
        until = datetime.fromisoformat(locked_until)
    except ValueError:
        clear_login_attempts(conn, identifier, ip)
        return False, 0, 0
    remaining = int((until - datetime.now()).total_seconds())
    if remaining <= 0:
        clear_login_attempts(conn, identifier, ip)
        return False, 0, 0
    return True, attempts, remaining



def register_auth_routes(app):
    @app.route('/register', methods=['GET', 'POST'])


    def register():


        if request.method == 'POST':


            try:


                last_name = request.form['last_name']


                first_name = request.form['first_name']


                middle_name = request.form.get('middle_name', '')


                phone = request.form['phone']


                birth_date = request.form.get('birth_date', '')


                address = request.form.get('address', '')


                password = request.form['password']


                confirm_password = request.form['confirm_password']





                if not all([last_name, first_name, phone, password]):


                    flash('Заполните все обязательные поля', 'danger')


                    return render_template('register.html')





                if password != confirm_password:


                    flash('Пароли не совпадают', 'danger')


                    return render_template('register.html')





                if len(password) < 6:


                    flash('Пароль должен содержать минимум 6 символов', 'danger')


                    return render_template('register.html')





                conn = get_db()


                cursor = conn.cursor()





                cursor.execute("SELECT ID_Клиента FROM Клиенты WHERE Телефон = ?", (phone,))


                if cursor.fetchone():


                    flash('Клиент с таким телефоном уже зарегистрирован', 'danger')


                    conn.close()


                    return render_template('register.html')





                cursor.execute("SELECT COUNT(*) FROM Клиенты")


                count = cursor.fetchone()[0] + 1


                client_id = f"CL{count:03d}"





                cursor.execute("""


                    INSERT INTO Клиенты (ID_Клиента, Фамилия, Имя, Отчество, Телефон, Дата_рождения, Адрес)


                    VALUES (?, ?, ?, ?, ?, ?, ?)


                """, (client_id, last_name, first_name, middle_name, phone, birth_date or None, address or None))





                cursor.execute("""


                    INSERT INTO Пользователи (ID_Клиента, Логин, Пароль, Роль)


                    VALUES (?, ?, ?, ?)


                """, (client_id, phone, hash_password(password), 'client'))





                conn.commit()


                conn.close()





                flash('Регистрация успешна! Теперь вы можете войти в систему.', 'success')


                return redirect(url_for('login'))





            except Exception as e:


                flash(f'Ошибка при регистрации: {str(e)}', 'danger')


                return render_template('register.html')





        return render_template('register.html')








    # Вход в систему (единый для всех)


    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """Единая авторизация: один экран для гостя и администратора."""
        conn = get_db()
        ensure_login_attempts_table(conn)
        if request.method == 'POST':
            try:
                login_value = request.form.get('login', '').strip()
                password = request.form.get('password', '')
                client_ip = (request.headers.get('X-Forwarded-For', request.remote_addr) or 'unknown').split(',')[0].strip()
                identifier = login_value.lower()
                locked, _, lock_seconds = login_is_locked(conn, identifier, client_ip)
                if locked:
                    minutes = max(1, (lock_seconds + 59) // 60)
                    flash(f'Слишком много неудачных попыток. Попробуйте снова через {minutes} мин.', 'danger')
                    conn.close()
                    return render_template('login.html')

                # Для телефона допускаем ввод с пробелами, скобками и дефисами.
                normalized = ''.join(ch for ch in login_value if ch.isdigit() or ch == '+')
                cursor = conn.cursor()

                user = None
                if login_value.lower() == 'admin':
                    cursor.execute("""
                        SELECT u.ID_Клиента, u.Роль, u.Пароль,
                               s.Фамилия, s.Имя, s.Отчество
                        FROM Пользователи u
                        LEFT JOIN Сотрудники s ON s.ID_Сотрудника = u.ID_Клиента
                        WHERE u.Роль = 'admin'
                        LIMIT 1
                    """)
                    user = cursor.fetchone()
                else:
                    cursor.execute("""
                        SELECT u.ID_Клиента, u.Роль, u.Пароль,
                               c.Фамилия, c.Имя, c.Отчество
                        FROM Пользователи u
                        LEFT JOIN Клиенты c ON u.ID_Клиента = c.ID_Клиента
                        WHERE u.Логин = ?
                    """, (login_value,))
                    user = cursor.fetchone()

                    # Поиск телефона и среди гостей, и среди сотрудников.
                    if not user and normalized:
                        cursor.execute("""
                            SELECT u.ID_Клиента, u.Роль, u.Пароль,
                                   COALESCE(c.Фамилия, s.Фамилия) AS Фамилия,
                                   COALESCE(c.Имя, s.Имя) AS Имя,
                                   COALESCE(c.Отчество, s.Отчество) AS Отчество
                            FROM Пользователи u
                            LEFT JOIN Клиенты c ON u.ID_Клиента = c.ID_Клиента
                            LEFT JOIN Сотрудники s ON s.ID_Сотрудника = u.ID_Клиента
                            WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(u.Логин,' ',''),'-',''),'(',''),')',''),'.',''), '+', '') = REPLACE(?, '+', '')
                        """, (normalized,))
                        user = cursor.fetchone()

                    # Резервный поиск телефона непосредственно в сотрудниках.
                    if not user and normalized:
                        cursor.execute("""
                            SELECT ID_Сотрудника AS ID_Клиента, 'admin' AS Роль, Пароль,
                                   Фамилия, Имя, Отчество
                            FROM Сотрудники
                            WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Телефон,' ',''),'-',''),'(',''),')',''),'.',''), '+', '') = REPLACE(?, '+', '')
                              AND Должность IN ('Администратор','Управляющий')
                        """, (normalized,))
                        user = cursor.fetchone()

                # Проверяем хэш. Старый пароль из учебной БД при успешном входе автоматически хэшируется.
                if user and password_matches(user['Пароль'], password):
                    clear_login_attempts(conn, identifier, client_ip)
                    session.clear()
                    session['user_id'] = user['ID_Клиента']
                    session['user_role'] = user['Роль']

                    # Миграция старых открытых паролей в безопасный хэш.
                    if not str(user['Пароль']).startswith(('scrypt:', 'pbkdf2:', 'argon2:')):
                        conn.execute('UPDATE Пользователи SET Пароль=? WHERE ID_Клиента=?', (hash_password(password), user['ID_Клиента']))
                        if user['Роль'] == 'admin':
                            conn.execute('UPDATE Сотрудники SET Пароль=? WHERE ID_Сотрудника=?', (hash_password(password), user['ID_Клиента']))
                        conn.commit()

                    if user['Роль'] == 'admin':
                        name = ((user['Имя'] or '') + ' ' + (user['Фамилия'] or '')).strip() or 'Администратор'
                        session['user_name'] = name
                        session['admin_id'] = user['ID_Клиента']
                        session['admin_name'] = 'Администратор'
                        flash('Добро пожаловать в панель администратора!', 'success')
                        return redirect(url_for('admin_dashboard'))

                    name = f"{user['Фамилия'] or ''} {user['Имя'] or ''}".strip() or 'Гость'
                    session['user_name'] = name
                    session['client_id'] = user['ID_Клиента']
                    session['client_name'] = name
                    flash(f'Добро пожаловать, {user["Имя"] or "гость"}!', 'success')
                    next_page = request.args.get('next')
                    return redirect(next_page or url_for('index'))

                attempts, locked_until = record_failed_login(conn, identifier, client_ip)
                if locked_until:
                    flash(f'Слишком много неудачных попыток. Вход заблокирован на {LOGIN_LOCK_MINUTES} мин.', 'danger')
                else:
                    remaining = max(0, LOGIN_MAX_ATTEMPTS - attempts)
                    flash(f'Неверные данные для входа. Осталось попыток: {remaining}', 'danger')
            except Exception as e:
                flash('Не удалось выполнить вход', 'danger')

        conn.close()
        return render_template('login.html')


    # Выход из системы


    @app.route('/logout')


    def logout():


        session.clear()


        flash('Вы вышли из системы', 'info')


        return redirect(url_for('index'))








    # Личный кабинет


    @app.route('/profile')


    @login_required


    def profile():


        try:


            conn = get_db()


            cursor = conn.cursor()





            cursor.execute("SELECT * FROM Клиенты WHERE ID_Клиента = ?", (session['client_id'],))


            client = cursor.fetchone()





            if not client:


                flash('Клиент не найден', 'danger')


                return redirect(url_for('index'))





            cursor.execute("""


                SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,


                       CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) as days_count


                FROM Бронирования b


                JOIN Номера n ON b.ID_Номера = n.ID_Номера


                WHERE b.ID_Клиента = ?


                ORDER BY b.Дата_заезда DESC


            """, (session['client_id'],))





            bookings = cursor.fetchall()


            bookings_with_total = []


            for booking in bookings:


                booking_dict = dict(booking)


                days = booking_dict.get('days_count', 0)


                if days <= 0:


                    days = 1


                booking_dict['total_price'] = days * booking_dict.get('Цена_за_сутки', 0)


                if booking_dict.get('Дата_заезда'):


                    booking_dict['Дата_заезда'] = str(booking_dict['Дата_заезда'])


                if booking_dict.get('Дата_выезда'):


                    booking_dict['Дата_выезда'] = str(booking_dict['Дата_выезда'])


                bookings_with_total.append(booking_dict)





            conn.close()


            return render_template('profile.html', client=client, bookings=bookings_with_total)





        except Exception as e:


            flash(f'Ошибка при загрузке профиля: {str(e)}', 'danger')


            return redirect(url_for('index'))








    # Создание бронирования — два шага: выбор параметров → подтверждение
    @app.route('/booking/<string:room_id>', methods=['GET', 'POST'])
    @login_required
    def create_booking(room_id):
        from hotel_logic import service_total, log_action
        conn = get_db()
        try:
            room = conn.execute("SELECT * FROM Номера WHERE ID_Номера = ?", (room_id,)).fetchone()
            services = conn.execute("SELECT * FROM Услуги WHERE Активна=1 ORDER BY Название").fetchall()
            if not room:
                flash('Номер не найден', 'danger')
                return redirect(url_for('index'))
            if room['Статус_обслуживания'] if 'Статус_обслуживания' in room.keys() else False:
                flash(f"Номер временно недоступен: {room['Статус_обслуживания']}.", 'danger')
                return redirect(url_for('room_detail', room_id=room_id))

            if request.method == 'POST':
                action = request.form.get('action', 'review')
                check_in = request.form.get('check_in', '').strip()
                check_out = request.form.get('check_out', '').strip()
                guests = request.form.get('guests', 1, type=int)
                selected_services = request.form.getlist('services')

                try:
                    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
                    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
                except ValueError:
                    flash('Укажите корректные даты.', 'danger')
                    return render_template('booking.html', room=room, services=services, check_in=check_in, check_out=check_out, guests=guests)
                today = datetime.now().date()
                if check_in_date < today or check_out_date <= check_in_date:
                    flash('Проверьте даты проживания.', 'danger')
                    return render_template('booking.html', room=room, services=services, check_in=check_in, check_out=check_out, guests=guests)
                if guests < 1 or guests > room['Вместимость']:
                    flash(f"Вместимость номера — до {room['Вместимость']} гостей.", 'danger')
                    return render_template('booking.html', room=room, services=services, check_in=check_in, check_out=check_out, guests=guests)
                if booking_conflicts(conn, room_id, check_in, check_out):
                    flash('Номер уже занят на выбранные даты. Выберите другой период.', 'danger')
                    return render_template('booking.html', room=room, services=services, check_in=check_in, check_out=check_out, guests=guests)

                valid_service_ids = {s['ID_Услуги'] for s in services}
                selected_services = [x for x in selected_services if x in valid_service_ids]
                total_room, nights = booking_total(conn, room_id, check_in, check_out)
                selected_rows = []
                for sid in selected_services:
                    row = conn.execute('SELECT * FROM Услуги WHERE ID_Услуги=?', (sid,)).fetchone()
                    if row:
                        selected_rows.append(row)
                services_sum = sum(float(x['Цена']) for x in selected_rows)
                subtotal = total_room + services_sum
                promo_code = request.form.get('promo_code','').strip().upper()
                if promo_code:
                    session['promo'] = {'code': promo_code}
                promo = session.get('promo') or {}
                discount = 0.0
                if promo.get('code'):
                    p = conn.execute("SELECT * FROM Промокоды WHERE Код=? AND Активен=1 AND (Действует_до IS NULL OR Действует_до>=date('now'))", (promo['code'],)).fetchone()
                    used = conn.execute("SELECT 1 FROM Использованные_промокоды WHERE Код=? AND ID_Клиента=?", (promo['code'], session['client_id'])).fetchone()
                    if p and not used and (not p['Лимит'] or p['Использовано'] < p['Лимит']):
                        discount = round(subtotal * float(p['Скидка']) / 100, 2)
                    else:
                        session.pop('promo', None)
                total = round(subtotal - discount, 2)

                if action == 'review':
                    session['booking_draft'] = {
                        'room_id': room_id, 'check_in': check_in, 'check_out': check_out,
                        'guests': guests, 'services': selected_services, 'promo_code': (session.get('promo') or {}).get('code','')
                    }
                    return render_template('booking_review.html', room=room, services=selected_rows,
                                           check_in=check_in, check_out=check_out, guests=guests,
                                           nights=nights, room_total=total_room, services_total=services_sum, subtotal=subtotal, discount=discount, promo_code=(session.get('promo') or {}).get('code',''),
                                           total=total, prepayment=round(total*0.30,2))

                if action == 'confirm':
                    draft = session.get('booking_draft') or {}
                    if draft.get('room_id') != room_id or draft.get('check_in') != check_in or draft.get('check_out') != check_out:
                        raise ValueError('Срок действия черновика бронирования истёк. Начните бронирование заново.')
                    booking_id = next_id(conn, 'Бронирования', 'BR', 'ID_Бронирования')
                    invoice_id = next_id(conn, 'Счета', 'INV', 'ID_Счета')
                    prepayment = round(total * 0.30, 2)
                    conn.execute("""INSERT INTO Бронирования
                        (ID_Бронирования, ID_Клиента, ID_Номера, Дата_бронирования, Дата_заезда, Дата_выезда,
                         Количество_гостей, Статус, Предоплата)
                        VALUES (?, ?, ?, date('now'), ?, ?, ?, 'Подтверждено', ?)""",
                        (booking_id, session['client_id'], room_id, check_in, check_out, guests, prepayment))
                    for row in selected_rows:
                        conn.execute("INSERT INTO Бронирование_Услуги(ID_Бронирования,ID_Услуги,Количество,Цена) VALUES(?,?,1,?)",
                                     (booking_id, row['ID_Услуги'], row['Цена']))
                    conn.execute("INSERT INTO Счета(ID_Счета,ID_Бронирования,Дата_выставления,Сумма_проживание,Оплачено) VALUES(?,?,date('now'),?,0)",
                                 (invoice_id, booking_id, total))
                    if promo.get('code') and discount > 0:
                        conn.execute("UPDATE Промокоды SET Использовано=Использовано+1 WHERE Код=?", (promo['code'],))
                        conn.execute("INSERT OR IGNORE INTO Использованные_промокоды(Код,ID_Клиента,ID_Бронирования) VALUES(?,?,?)", (promo['code'],session['client_id'],booking_id))
                    conn.commit()
                    session.pop('booking_draft', None); session.pop('promo', None)
                    log_action('Создано бронирование', booking_id, f'Номер {room["Номер_Комнаты"]}, {check_in} — {check_out}')
                    sync_room_statuses()
                    flash(f'Бронирование {booking_id} создано.', 'success')
                    return redirect(url_for('booking_confirmation', booking_id=booking_id))

            check_in = request.args.get('check_in', datetime.now().strftime('%Y-%m-%d'))
            check_out = request.args.get('check_out', (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d'))
            guests = request.args.get('guests', 1, type=int)
            return render_template('booking.html', room=room, services=services, check_in=check_in, check_out=check_out, guests=guests)
        except Exception as e:
            conn.rollback()
            flash(f'Ошибка при создании бронирования: {str(e)}', 'danger')
            return redirect(url_for('room_detail', room_id=room_id))
        finally:
            conn.close()

    # Подтверждение бронирования


    @app.route('/booking/confirmation/<string:booking_id>')
    @login_required
    def booking_confirmation(booking_id):
        try:
            conn = get_db()
            booking = conn.execute("""
                SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,
                       CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) AS days_count,
                       c.Фамилия, c.Имя, c.Отчество
                FROM Бронирования b
                JOIN Номера n ON b.ID_Номера=n.ID_Номера
                JOIN Клиенты c ON b.ID_Клиента=c.ID_Клиента
                WHERE b.ID_Бронирования=? AND b.ID_Клиента=?
            """, (booking_id, session['client_id'])).fetchone()
            if not booking:
                conn.close()
                flash('Бронирование не найдено', 'danger')
                return redirect(url_for('profile'))
            invoice = conn.execute("SELECT * FROM Счета WHERE ID_Бронирования=?", (booking_id,)).fetchone()
            services = conn.execute("""SELECT u.*, bs.Количество, bs.Цена AS Цена_при_бронировании
                FROM Бронирование_Услуги bs JOIN Услуги u ON u.ID_Услуги=bs.ID_Услуги
                WHERE bs.ID_Бронирования=?""", (booking_id,)).fetchall()
            conn.close()
            booking_dict = dict(booking)
            booking_dict['total_price'] = float(invoice['Сумма_проживание']) if invoice else float(booking_dict.get('days_count', 0)) * float(booking_dict.get('Цена_за_сутки', 0))
            booking_dict['payment_paid'] = bool(invoice and invoice['Оплачено'])
            booking_dict['payment_amount'] = float(booking_dict.get('Предоплата') or 0)
            return render_template('confirmation.html', booking=booking_dict, services=services, invoice=invoice)
        except Exception as e:
            flash(f'Ошибка при загрузке подтверждения: {str(e)}', 'danger')
            return redirect(url_for('profile'))


    # Отмена бронирования
    @app.route('/booking/cancel/<string:booking_id>', methods=['POST'])
    @login_required
    def cancel_booking(booking_id):
        conn = get_db()
        try:
            booking = conn.execute("SELECT Дата_заезда, ID_Номера FROM Бронирования WHERE ID_Бронирования=? AND ID_Клиента=?", (booking_id, session['client_id'])).fetchone()
            if not booking:
                flash('Бронирование не найдено.', 'danger')
                return redirect(url_for('profile'))
            check_in = datetime.strptime(booking['Дата_заезда'], '%Y-%m-%d').date()
            if check_in <= datetime.now().date():
                flash('Нельзя отменить бронирование в день заезда или позже.', 'danger')
                return redirect(url_for('profile'))
            conn.execute("UPDATE Бронирования SET Статус='Отменено' WHERE ID_Бронирования=?", (booking_id,))
            conn.commit()
        except Exception as e:
            conn.rollback(); flash(f'Ошибка отмены: {str(e)}', 'danger')
            return redirect(url_for('profile'))
        finally:
            conn.close()
        sync_room_statuses()
        from hotel_logic import log_action
        log_action('Отменено бронирование', booking_id, 'Гость отменил бронь')
        flash('Бронирование отменено.', 'success')
        return redirect(url_for('profile'))

