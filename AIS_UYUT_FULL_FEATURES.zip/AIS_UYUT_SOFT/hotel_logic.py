"""Расширенная бизнес-логика АИС «Уют»."""
from datetime import datetime
from db import get_db


def ensure_extended_schema():
    conn = get_db()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS Услуги (
                ID_Услуги TEXT PRIMARY KEY,
                Название TEXT NOT NULL UNIQUE,
                Описание TEXT,
                Цена REAL NOT NULL DEFAULT 0,
                Активна INTEGER NOT NULL DEFAULT 1
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS Бронирование_Услуги (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                ID_Бронирования TEXT NOT NULL,
                ID_Услуги TEXT NOT NULL,
                Количество INTEGER NOT NULL DEFAULT 1,
                Цена REAL NOT NULL DEFAULT 0,
                UNIQUE(ID_Бронирования, ID_Услуги),
                FOREIGN KEY(ID_Бронирования) REFERENCES Бронирования(ID_Бронирования) ON DELETE CASCADE,
                FOREIGN KEY(ID_Услуги) REFERENCES Услуги(ID_Услуги)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS Журнал_действий (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                Время TEXT NOT NULL,
                Пользователь TEXT,
                Роль TEXT,
                Действие TEXT NOT NULL,
                Объект TEXT,
                Детали TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_booking_services_booking ON Бронирование_Услуги(ID_Бронирования)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_time ON Журнал_действий(Время)")
        services = [
            ('SRV001', 'Завтрак', 'Шведский стол', 900),
            ('SRV002', 'Парковка', 'Место на охраняемой парковке', 500),
            ('SRV003', 'Трансфер', 'Трансфер из/в аэропорт', 1800),
            ('SRV004', 'Поздний выезд', 'Выезд до 18:00', 1500),
            ('SRV005', 'Дополнительное место', 'Раскладная кровать', 1200),
            ('SRV006', 'Романтический пакет', 'Украшение номера и комплимент', 2500),
            ('SRV007', 'Кофейный набор', 'Кофе и чай в номер', 450),
            ('SRV008', 'Ранний заезд', 'Заезд с 10:00 при наличии номера', 1200),
        ]
        for sid, name, desc, price in services:
            conn.execute("INSERT OR IGNORE INTO Услуги(ID_Услуги,Название,Описание,Цена) VALUES(?,?,?,?)", (sid,name,desc,price))
        conn.commit()
    finally:
        conn.close()


def service_total(conn, booking_id):
    row = conn.execute("SELECT COALESCE(SUM(Количество*Цена),0) total FROM Бронирование_Услуги WHERE ID_Бронирования=?", (booking_id,)).fetchone()
    return float(row['total'] or 0)


def log_action(action, obj='', details=''):
    try:
        from flask import session
        user = session.get('user_name') or session.get('admin_name') or 'Система'
        role = session.get('user_role') or 'system'
    except Exception:
        user, role = 'Система', 'system'
    conn = get_db()
    try:
        conn.execute("INSERT INTO Журнал_действий(Время,Пользователь,Роль,Действие,Объект,Детали) VALUES(?,?,?,?,?,?)",
                     (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), user, role, action, obj, details))
        conn.commit()
    finally:
        conn.close()
