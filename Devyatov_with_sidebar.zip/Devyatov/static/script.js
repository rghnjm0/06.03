function showToast(message, type = 'success') {
    let c = document.querySelector('.flash-container');
    if (!c) { c = document.createElement('div'); c.className = 'flash-container'; document.body.appendChild(c); }
    const t = document.createElement('div');
    t.className = `flash flash-${type}`;
    t.textContent = message;
    c.appendChild(t);
    setTimeout(() => {
        t.style.transition = 'opacity .4s, transform .4s';
        t.style.opacity = '0'; t.style.transform = 'translateX(120%)';
        setTimeout(() => t.remove(), 400);
    }, 3500);
}

function updateBadge(selector, count, badgeClass) {
    const btn = document.querySelector(selector);
    if (!btn) return;
    let badge = btn.querySelector('.' + badgeClass);
    if (count > 0) {
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'cart-badge ' + (badgeClass === 'wishlist-badge' ? 'wishlist-badge' : '');
            btn.appendChild(badge);
        }
        badge.textContent = count;
    } else if (badge) badge.remove();
}

/* ============ ДОБАВЛЕНИЕ В КОРЗИНУ ============ */
document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const pid = btn.dataset.id;
        let qty = 1;
        if (btn.dataset.qtyFromInput) {
            const inp = document.getElementById(btn.dataset.qtyFromInput);
            if (inp) qty = parseInt(inp.value) || 1;
        }
        btn.style.transform = 'scale(0.9)';
        setTimeout(() => btn.style.transform = '', 150);
        try {
            const res = await fetch('/add_to_cart', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ product_id: pid, quantity: qty })
            });
            const data = await res.json();
            if (data.success) { showToast('✓ ' + data.message); updateBadge('.cart-btn:not(.wishlist-btn)', data.cart_count, 'cart-badge'); }
            else showToast('Ошибка: ' + data.message, 'error');
        } catch { showToast('Ошибка соединения', 'error'); }
    });
});

/* ============ ИЗБРАННОЕ ============ */
document.querySelectorAll('.wish-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const pid = btn.dataset.id;
        btn.style.transform = 'scale(1.3)';
        setTimeout(() => btn.style.transform = '', 200);
        try {
            const res = await fetch('/toggle_wishlist', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ product_id: pid })
            });
            const data = await res.json();
            if (data.success) {
                btn.classList.toggle('active', data.added);
                showToast((data.added ? '❤️ ' : '💔 ') + data.message);
                updateBadge('.wishlist-btn', data.wishlist_count, 'wishlist-badge');
                // Если мы на странице /wishlist — перезагружаем, чтобы карточка исчезла
                if (window.location.pathname === '/wishlist' && !data.added) {
                    setTimeout(() => location.reload(), 400);
                }
            }
        } catch { showToast('Ошибка соединения', 'error'); }
    });
});

/* ============ КОРЗИНА ============ */
document.querySelectorAll('.cart-item').forEach(item => {
    const pid = item.dataset.id;
    const qtyEl = item.querySelector('.cart-qty');
    async function sendQty(newQty) {
        try {
            const res = await fetch('/update_cart', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ product_id: pid, quantity: newQty })
            });
            const data = await res.json();
            if (data.success) {
                if (newQty <= 0) {
                    item.style.opacity = '0'; item.style.transform = 'translateX(-40px)';
                    setTimeout(() => location.reload(), 300);
                } else { qtyEl.textContent = newQty; location.reload(); }
            }
        } catch { showToast('Ошибка', 'error'); }
    }
    item.querySelectorAll('.cart-qty-btn').forEach(b => {
        b.addEventListener('click', () => {
            const current = parseInt(qtyEl.textContent) || 1;
            sendQty(b.dataset.action === 'plus' ? current + 1 : current - 1);
        });
    });
});

document.querySelectorAll('.cart-remove').forEach(btn => {
    btn.addEventListener('click', async () => {
        const pid = btn.dataset.id;
        const item = btn.closest('.cart-item');
        try {
            const res = await fetch('/remove_from_cart', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ product_id: pid })
            });
            const data = await res.json();
            if (data.success) {
                updateBadge('.cart-btn:not(.wishlist-btn)', data.cart_count, 'cart-badge');
                item.style.transition = 'opacity .3s, transform .3s';
                item.style.opacity = '0'; item.style.transform = 'translateX(-40px)';
                setTimeout(() => location.reload(), 300);
                showToast('Товар удалён');
            }
        } catch { showToast('Ошибка', 'error'); }
    });
});

/* ============ КОЛИЧЕСТВО НА СТРАНИЦЕ ТОВАРА ============ */
const qtyInput = document.getElementById('qty');
if (qtyInput) {
    document.querySelector('.qty-minus')?.addEventListener('click', () => {
        qtyInput.value = Math.max(1, (parseInt(qtyInput.value) || 1) - 1);
    });
    document.querySelector('.qty-plus')?.addEventListener('click', () => {
        qtyInput.value = Math.min(10, (parseInt(qtyInput.value) || 1) + 1);
    });
}

if (window.dashData && typeof Chart !== 'undefined') {
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.font.size = 12;

    const d = window.dashData;

    // График по брендам
    const cb = document.getElementById('chartBrands');
    if (cb) new Chart(cb, {
        type: 'bar',
        data: {
            labels: d.brands.labels,
            datasets: [{
                label: 'Моделей',
                data: d.brands.data,
                backgroundColor: 'rgba(139, 92, 246, 0.6)',
                borderColor: '#8b5cf6',
                borderWidth: 1,
                borderRadius: 8,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: 'rgba(255,255,255,0.05)' } },
                y: { grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true }
            }
        }
    });

    // Круговая по ценам
    const cp = document.getElementById('chartPrices');
    if (cp) new Chart(cp, {
        type: 'doughnut',
        data: {
            labels: d.prices.labels,
            datasets: [{
                data: d.prices.data,
                backgroundColor: d.prices.colors,
                borderWidth: 0,
                hoverOffset: 10,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { padding: 14, usePointStyle: true, pointStyle: 'circle' } }
            },
            cutout: '65%'
        }
    });

    // Scatter: цена vs рейтинг
    const cs = document.getElementById('chartScatter');
    if (cs) new Chart(cs, {
        type: 'scatter',
        data: {
            datasets: [{
                label: 'Смартфоны',
                data: d.scatter,
                backgroundColor: 'rgba(236, 72, 153, 0.7)',
                borderColor: '#ec4899',
                pointRadius: 7,
                pointHoverRadius: 10,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = ctx.raw;
                            return `${p.label}: ${p.x.toLocaleString('ru-RU')} ₽ · ⭐ ${p.y}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: { display: true, text: 'Цена, ₽', color: '#94a3b8' },
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    ticks: { callback: v => v.toLocaleString('ru-RU') }
                },
                y: {
                    title: { display: true, text: 'Рейтинг', color: '#94a3b8' },
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    min: 4, max: 5
                }
            }
        }
    });
}

/* ============ COMPARE: логика ============ */
function updateCompareUrl(ids) {
    const clean = ids.filter(Boolean);
    window.location.href = '/compare' + (clean.length ? '?ids=' + clean.join(',') : '');
}

(function initCompare() {
    const picker = document.getElementById('comparePicker');
    if (!picker) return;

    const currentIds = Array.from(document.querySelectorAll('.slot-filled'))
        .map(s => s.dataset.id);

    // Выбор в пустом слоте
    document.querySelectorAll('.slot-select').forEach(sel => {
        sel.addEventListener('change', () => {
            if (sel.value) updateCompareUrl([...currentIds, sel.value]);
        });
    });

    // Удаление из слота
    document.querySelectorAll('.slot-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const slot = btn.closest('.slot-filled');
            const id = slot.dataset.id;
            updateCompareUrl(currentIds.filter(x => x !== id));
        });
    });

    // Быстрое добавление
    document.querySelectorAll('.quick-compare-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.add;
            if (currentIds.length >= 4) {
                showToast('Максимум 4 товара в сравнении', 'error');
                return;
            }
            if (!currentIds.includes(id)) updateCompareUrl([...currentIds, id]);
        });
    });
})();
/* ===== Левый сайдбар — мобильный toggle ===== */
(function () {
    const sidebar = document.getElementById('leftSidebar');
    const toggle = document.getElementById('sidebarToggle');
    if (!sidebar || !toggle) return;

    toggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
    });

    // Закрывать при клике вне сайдбара на мобильных
    document.addEventListener('click', (e) => {
        if (window.innerWidth > 900) return;
        if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    });
})();
