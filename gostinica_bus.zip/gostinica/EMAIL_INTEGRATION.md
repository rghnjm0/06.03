# Интеграция с почтой (SMTP / Flask-Mail)

## Что сделано

1. **Модуль `email_service.py`** — единая точка отправки писем:
   - подтверждение бронирования гостю;
   - приветственное письмо после регистрации;
   - пересылка сообщений с формы «Контакты» администратору;
   - дублирование in-app уведомлений на email.

2. **Колонка `Email` в таблице `Клиенты`**
   - миграция при старте приложения (`ensure_email_column` в `app.py`);
   - поле в формах регистрации и редактирования профиля.

3. **Форма на странице `/contact`**
   - POST → письмо на `MAIL_ADMIN_RECIPIENT` с Reply-To гостя.

4. **После создания брони** автоматически уходит письмо с деталями, если у клиента указан email.

5. **Настройки** в `.env.example` (скопируйте в `.env` или задайте переменные окружения).

## Как включить реальную отправку

```bash
pip install -r requirements.txt

# Пример для Gmail (нужен «пароль приложения», не обычный пароль)
export MAIL_SERVER=smtp.gmail.com
export MAIL_PORT=587
export MAIL_USE_TLS=1
export MAIL_USERNAME=your@gmail.com
export MAIL_PASSWORD=xxxx-xxxx-xxxx-xxxx
export MAIL_DEFAULT_SENDER="ONYX Hotel <your@gmail.com>"
export MAIL_ADMIN_RECIPIENT=info@onyx-hotel.ru
# MAIL_SUPPRESS_SEND=1  # только лог, без реальной отправки

python app.py
```

Без `MAIL_USERNAME` / `MAIL_PASSWORD` письма **не падают с ошибкой**: они пишутся в лог (`[EMAIL DEMO]`) и бизнес-операции (бронь, регистрация) продолжают работать.

## Другие SMTP

| Провайдер | SERVER | PORT | TLS |
|-----------|--------|------|-----|
| Gmail | smtp.gmail.com | 587 | 1 |
| Yandex | smtp.yandex.ru | 465 | SSL=1, TLS=0 |
| Mail.ru | smtp.mail.ru | 587 | 1 |
| SendGrid | smtp.sendgrid.net | 587 | 1 (user=apikey) |

## Безопасность

- Пароль SMTP только в переменных окружения, не в коде.
- CSRF на форме контактов.
- Валидация email и ограничение длины сообщения.
- Ошибки SMTP не прерывают бронирование (try/except вокруг send).
