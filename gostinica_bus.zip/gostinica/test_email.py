#!/usr/bin/env python3
"""
Проверка реальной отправки email.

Использование:
  1. Заполните MAIL_USERNAME и MAIL_PASSWORD в файле .env
  2. python test_email.py
  3. python test_email.py ваш@email.com   # куда отправить тестовое письмо

Скрипт загружает .env, инициализирует Flask-Mail и пытается отправить письмо.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:
    print("Установите зависимости: pip install -r requirements.txt")
    sys.exit(1)

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")

# Подставляем проект в path
sys.path.insert(0, str(ROOT))

from flask import Flask
from email_service import init_mail, send_email, _mail_configured


def main() -> int:
    to = (sys.argv[1] if len(sys.argv) > 1 else "").strip()
    username = os.environ.get("MAIL_USERNAME", "").strip()
    password = os.environ.get("MAIL_PASSWORD", "").strip()
    suppress = os.environ.get("MAIL_SUPPRESS_SEND", "0") == "1"

    print("=== Проверка SMTP ===")
    print(f"  MAIL_SERVER          = {os.environ.get('MAIL_SERVER', '')}")
    print(f"  MAIL_PORT            = {os.environ.get('MAIL_PORT', '')}")
    print(f"  MAIL_USE_TLS         = {os.environ.get('MAIL_USE_TLS', '')}")
    print(f"  MAIL_USERNAME        = {username or '(пусто!)'}")
    print(f"  MAIL_PASSWORD        = {'***' if password else '(пусто!)'}")
    print(f"  MAIL_DEFAULT_SENDER  = {os.environ.get('MAIL_DEFAULT_SENDER', '')}")
    print(f"  MAIL_ADMIN_RECIPIENT = {os.environ.get('MAIL_ADMIN_RECIPIENT', '')}")
    print(f"  MAIL_SUPPRESS_SEND   = {os.environ.get('MAIL_SUPPRESS_SEND', '0')}")
    print()

    if not username or not password or username.startswith("ВАШ_"):
        print("ОШИБКА: в .env не заполнены реальные MAIL_USERNAME / MAIL_PASSWORD.")
        print()
        print("Для Gmail:")
        print("  1. Включите 2FA: https://myaccount.google.com/security")
        print("  2. Создайте пароль приложения: https://myaccount.google.com/apppasswords")
        print("  3. В .env укажите:")
        print("       MAIL_USERNAME=ваш@gmail.com")
        print("       MAIL_PASSWORD=xxxx xxxx xxxx xxxx   # 16 символов без пробелов или с")
        print("       MAIL_DEFAULT_SENDER=ONYX Hotel <ваш@gmail.com>")
        print("       MAIL_ADMIN_RECIPIENT=ваш@gmail.com")
        print("       MAIL_SUPPRESS_SEND=0")
        return 1

    if suppress:
        print("ВНИМАНИЕ: MAIL_SUPPRESS_SEND=1 — письмо НЕ уйдёт на сервер, только в лог.")
        print("Поставьте MAIL_SUPPRESS_SEND=0 для реальной отправки.")
        print()

    if not to:
        to = username
        print(f"Адрес получателя не указан — отправляем на {to}")
    print(f"Отправка тестового письма на: {to}")
    print()

    app = Flask(__name__)
    init_mail(app)

    with app.app_context():
        if not _mail_configured():
            print("ОШИБКА: Flask-Mail считает, что SMTP не настроен.")
            return 1

        ok = send_email(
            to=to,
            subject="[Тест] ONYX Hotel — проверка почты",
            html_body=(
                "<html><body style='font-family:Arial,sans-serif'>"
                "<h2>Почта работает</h2>"
                "<p>Это тестовое письмо из проекта отеля «Уют» / ONYX Hotel.</p>"
                "<p>Если вы его видите — SMTP настроен правильно.</p>"
                "</body></html>"
            ),
        )

    if ok:
        print("УСПЕХ: письмо принято к отправке (проверьте входящие и «Спам»).")
        return 0

    print("НЕУДАЧА: send_email вернул False. Смотрите traceback выше / логи SMTP.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
