"""Фоновый агент гостиницы.

  * читает requests/hotel/ и отвечает в responses/<from>/;
  * раз в BUS_SNAPSHOT_INTERVAL публикует snapshots/hotel.json.

Запускается из app.py через start(app).
"""
import json
import os
import sqlite3
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

from flask import current_app


MY_CODE = "hotel"
_thread = None
_stop = threading.Event()


def _log(msg: str) -> None:
    try:
        current_app.logger.info("[bus] %s", msg)
    except Exception:
        pass


def _atomic_write(target: Path, data: dict) -> None:
    tmp_dir = target.parent.parent.parent / "tmp"
    try:
        tmp_dir.mkdir(parents=True, exist_ok=True)
        target.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        _log(f"mkdir fail for write {target}: {e}")
        raise
    tmp = tmp_dir / f"{target.name}.{uuid.uuid4().hex}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)


def _db_query(sql: str, params=()) -> list[dict]:
    """Запрос к БД гостиницы (hotel_management.db)."""
    db = current_app.config.get("DATABASE")
    if not db:
        return []
    conn = sqlite3.connect(str(db), timeout=5.0)
    conn.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Обработчики входящих
# ---------------------------------------------------------------------------
def _h_ping(req):
    return {
        "status": "ok",
        "service": MY_CODE,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def _h_guest_lookup(req):
    """Поиск гостя по ФИО в таблице Клиенты."""
    name = (req.get("payload", {}).get("guest_name") or "").strip()
    if not name:
        return {"found": False, "error": "guest_name обязателен"}

    # Ищем по Фамилии / Имени / полному ФИО
    rows = _db_query(
        """
        SELECT
            c.ID_Клиента,
            c.Фамилия,
            c.Имя,
            c.Отчество,
            c.Телефон,
            (
                SELECT n.Номер_Комнаты
                FROM Бронирования b
                JOIN Номера n ON n.ID_Номера = b.ID_Номера
                WHERE b.ID_Клиента = c.ID_Клиента
                  AND b.Статус IN ('Подтверждено', 'Заселен')
                ORDER BY b.Дата_заезда DESC
                LIMIT 1
            ) AS room
        FROM Клиенты c
        WHERE (c.Фамилия || ' ' || c.Имя || ' ' || COALESCE(c.Отчество, '')) LIKE ?
           OR (c.Фамилия || ' ' || c.Имя) LIKE ?
           OR c.Фамилия LIKE ?
           OR c.Имя LIKE ?
        LIMIT 1
        """,
        (f"%{name}%", f"%{name}%", f"%{name}%", f"%{name}%"),
    )
    if not rows:
        return {"found": False, "guest_name": name}

    g = rows[0]
    full_name = " ".join(
        filter(None, [g.get("Фамилия"), g.get("Имя"), g.get("Отчество")])
    )
    return {
        "found": True,
        "guest_name": full_name,
        "room": g.get("room") or None,
        "client_id": g.get("ID_Клиента"),
        "phone": g.get("Телефон"),
        "vip": False,
    }



def _map_room_type(room_type: str) -> list[str]:
    """Сопоставление типа из шины с категориями в БД."""
    t = (room_type or "").strip().lower()
    mapping = {
        "standard": ["Стандарт", "Стандарт Плюс"],
        "стандарт": ["Стандарт", "Стандарт Плюс"],
        "lux": ["Люкс", "Премиум"],
        "luxury": ["Люкс", "Премиум"],
        "люкс": ["Люкс", "Премиум"],
        "suite": ["Полулюкс", "Люкс"],
        "полулюкс": ["Полулюкс"],
        "apartments": ["Апартаменты"],
        "апартаменты": ["Апартаменты"],
        "premium": ["Премиум"],
        "премиум": ["Премиум"],
    }
    if t in mapping:
        return mapping[t]
    # Прямое совпадение с названием категории
    if room_type:
        return [room_type]
    return []


def _h_room_availability(req):
    """Узнать свободные номера на дату (type: room_availability)."""
    p = req.get("payload", {}) or {}
    date_str = (p.get("date") or datetime.now().strftime("%Y-%m-%d")).strip()
    # Опционально: ночь/выезд; по умолчанию одна ночь
    checkout = (p.get("checkout") or p.get("date_out") or "").strip()
    if not checkout:
        try:
            d = datetime.strptime(date_str, "%Y-%m-%d")
            from datetime import timedelta
            checkout = (d + timedelta(days=1)).strftime("%Y-%m-%d")
        except ValueError:
            return {"status": "error", "error": "Некорректная дата (ожидается YYYY-MM-DD)"}

    # Номера без пересекающихся активных броней на период [date_str, checkout)
    free = _db_query(
        """
        SELECT n.ID_Номера, n.Номер_Комнаты, n.Категория, n.Вместимость, n.Цена_за_сутки, n.Статус
        FROM Номера n
        WHERE n.ID_Номера NOT IN (
            SELECT b.ID_Номера FROM Бронирования b
            WHERE b.Статус IN ('Подтверждено', 'Заселен')
              AND NOT (b.Дата_выезда <= ? OR b.Дата_заезда >= ?)
        )
        ORDER BY n.Категория, n.Номер_Комнаты
        """,
        (date_str, checkout),
    )

    by_type: dict[str, int] = {}
    rooms_list = []
    for r in free:
        cat = r["Категория"]
        by_type[cat] = by_type.get(cat, 0) + 1
        rooms_list.append({
            "room_number": r["Номер_Комнаты"],
            "room_id": r["ID_Номера"],
            "category": cat,
            "capacity": r["Вместимость"],
            "price": r["Цена_за_сутки"],
        })

    return {
        "status": "ok",
        "date": date_str,
        "checkout": checkout,
        "free_rooms": len(free),
        "available_types": sorted(by_type.keys()),
        "by_type": by_type,
        "rooms": rooms_list[:20],  # краткий список
    }


def _h_book_room(req):
    """Забронировать номер (type: book_room)."""
    p = req.get("payload", {}) or {}
    guest_name = (p.get("guest_name") or "Неизвестный гость").strip()
    room_type = (p.get("room_type") or "standard").strip()
    date_str = (p.get("date") or "").strip()
    nights = int(p.get("nights") or 1)
    guests_count = int(p.get("guests") or 1)

    if not date_str:
        return {"status": "error", "error": "Не указана дата заезда"}
    if nights < 1:
        nights = 1

    try:
        d0 = datetime.strptime(date_str, "%Y-%m-%d")
        from datetime import timedelta
        checkout = (d0 + timedelta(days=nights)).strftime("%Y-%m-%d")
    except ValueError:
        return {"status": "error", "error": "Некорректная дата (ожидается YYYY-MM-DD)"}

    categories = _map_room_type(room_type)
    # Ищем свободный номер нужной категории
    if categories:
        placeholders = ",".join("?" * len(categories))
        candidates = _db_query(
            f"""
            SELECT n.ID_Номера, n.Номер_Комнаты, n.Категория, n.Вместимость, n.Цена_за_сутки
            FROM Номера n
            WHERE n.Категория IN ({placeholders})
              AND n.ID_Номера NOT IN (
                  SELECT b.ID_Номера FROM Бронирования b
                  WHERE b.Статус IN ('Подтверждено', 'Заселен')
                    AND NOT (b.Дата_выезда <= ? OR b.Дата_заезда >= ?)
              )
            ORDER BY n.Цена_за_сутки ASC, n.Номер_Комнаты
            LIMIT 1
            """,
            (*categories, date_str, checkout),
        )
    else:
        candidates = _db_query(
            """
            SELECT n.ID_Номера, n.Номер_Комнаты, n.Категория, n.Вместимость, n.Цена_за_сутки
            FROM Номера n
            WHERE n.ID_Номера NOT IN (
                SELECT b.ID_Номера FROM Бронирования b
                WHERE b.Статус IN ('Подтверждено', 'Заселен')
                  AND NOT (b.Дата_выезда <= ? OR b.Дата_заезда >= ?)
            )
            ORDER BY n.Цена_за_сутки ASC, n.Номер_Комнаты
            LIMIT 1
            """,
            (date_str, checkout),
        )

    if not candidates:
        return {
            "status": "error",
            "error": f"Нет свободных номеров типа «{room_type}» на {date_str}",
            "booked": False,
        }

    room = candidates[0]
    if guests_count > int(room["Вместимость"] or 1):
        guests_count = int(room["Вместимость"] or 1)

    # Разбор ФИО
    parts = guest_name.split()
    last = parts[0] if parts else "Гость"
    first = parts[1] if len(parts) > 1 else "Шина"
    middle = parts[2] if len(parts) > 2 else ""

    db = current_app.config.get("DATABASE")
    if not db:
        return {"status": "error", "error": "БД не настроена"}

    conn = sqlite3.connect(str(db), timeout=5.0)
    conn.row_factory = sqlite3.Row
    try:
        # Клиент: ищем по ФИО или создаём
        client = conn.execute(
            """
            SELECT ID_Клиента FROM Клиенты
            WHERE Фамилия=? AND Имя=?
            LIMIT 1
            """,
            (last, first),
        ).fetchone()
        if client:
            client_id = client["ID_Клиента"]
        else:
            # next_id без utils (чтобы не тянуть Flask-контекст лишний раз)
            row = conn.execute(
                "SELECT ID_Клиента FROM Клиенты WHERE ID_Клиента LIKE 'CL%' ORDER BY ID_Клиента DESC LIMIT 1"
            ).fetchone()
            if row and row[0]:
                digits = "".join(ch for ch in str(row[0]) if ch.isdigit())
                num = int(digits or 0) + 1
            else:
                num = 1
            client_id = f"CL{num:03d}"
            phone = f"+7(900){num:07d}"[-16:]
            conn.execute(
                """
                INSERT INTO Клиенты(ID_Клиента, Фамилия, Имя, Отчество, Телефон)
                VALUES (?,?,?,?,?)
                """,
                (client_id, last, first, middle or None, phone),
            )

        row = conn.execute(
            "SELECT ID_Бронирования FROM Бронирования WHERE ID_Бронирования LIKE 'BR%' ORDER BY ID_Бронирования DESC LIMIT 1"
        ).fetchone()
        if row and row[0]:
            digits = "".join(ch for ch in str(row[0]) if ch.isdigit())
            bnum = int(digits or 0) + 1
        else:
            bnum = 1
        booking_id = f"BR{bnum:03d}"

        total = float(room["Цена_за_сутки"]) * nights
        prepayment = round(total * 0.30, 2)

        conn.execute(
            """
            INSERT INTO Бронирования(
                ID_Бронирования, ID_Клиента, ID_Номера, ID_Сотрудника,
                Дата_бронирования, Дата_заезда, Дата_выезда,
                Количество_гостей, Статус, Предоплата
            ) VALUES (?,?,?,?,date('now'),?,?,?,?,?)
            """,
            (
                booking_id,
                client_id,
                room["ID_Номера"],
                "ADM001",
                date_str,
                checkout,
                guests_count,
                "Подтверждено",
                prepayment,
            ),
        )

        inv_row = conn.execute(
            "SELECT ID_Счета FROM Счета WHERE ID_Счета LIKE 'INV%' ORDER BY ID_Счета DESC LIMIT 1"
        ).fetchone()
        if inv_row and inv_row[0]:
            digits = "".join(ch for ch in str(inv_row[0]) if ch.isdigit())
            inum = int(digits or 0) + 1
        else:
            inum = 1
        invoice_id = f"INV{inum:03d}"
        conn.execute(
            """
            INSERT INTO Счета(ID_Счета, ID_Бронирования, Дата_выставления, Сумма_проживание, Оплачено)
            VALUES (?,?,date('now'),?,0)
            """,
            (invoice_id, booking_id, total),
        )
        # Помечаем бронь как пришедшую с шины (для поиска в интеграции)
        try:
            conn.execute(
                """
                INSERT INTO Журнал_действий(Время, Пользователь, Роль, Действие, Объект, Детали)
                VALUES (datetime('now','localtime'), ?, 'bus', ?, ?, ?)
                """,
                (
                    req.get("from") or "external",
                    "Бронь через шину (book_room)",
                    booking_id,
                    f"номер {room['Номер_Комнаты']}, {guest_name}, {date_str}—{checkout}, от {req.get('from') or '?'}",
                ),
            )
        except Exception:
            pass
        conn.commit()
    except Exception as e:
        conn.rollback()
        return {"status": "error", "error": str(e), "booked": False}
    finally:
        conn.close()

    return {
        "status": "ok",
        "booked": True,
        "room_number": room["Номер_Комнаты"],
        "room_type": room["Категория"],
        "guest_name": guest_name,
        "booking_id": booking_id,
        "check_in": date_str,
        "check_out": checkout,
        "nights": nights,
        "total": total,
        "client_id": client_id,
        "source": req.get("from") or "external",
    }


_HANDLERS = {
    "ping": _h_ping,
    "guest_lookup": _h_guest_lookup,
    "room_availability": _h_room_availability,
    "book_room": _h_book_room,
}


# ---------------------------------------------------------------------------
# Обработка одного запроса
# ---------------------------------------------------------------------------
def _process_request(root: Path, req_file: Path) -> None:
    try:
        with open(req_file, "r", encoding="utf-8") as f:
            req = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        _log(f"не смог прочитать {req_file.name}: {e}")
        return

    rid = req.get("request_id") or req_file.stem
    req_type = req.get("type", "")
    sender = req.get("from", "?")
    _log(f"вход ← {sender}/{req_type} id={rid}")

    handler = _HANDLERS.get(req_type)
    try:
        if handler:
            payload = handler(req)
            status = "error" if payload.get("status") == "error" else "ok"
        else:
            payload = {"error": f"Неизвестный тип: {req_type}"}
            status = "error"
    except Exception as e:
        _log(f"ошибка {req_type}: {e}")
        payload = {"error": str(e)}
        status = "error"

    resp = {
        "request_id": rid,
        "from": MY_CODE,
        "to": sender,
        "status": status,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload,
    }
    _atomic_write(root / "responses" / sender / f"{rid}.json", resp)
    _log(f"ответ → {sender}/{status} id={rid}")

    proc = root / "processed" / MY_CODE
    proc.mkdir(parents=True, exist_ok=True)
    try:
        os.replace(req_file, proc / req_file.name)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Публикация snapshot
# ---------------------------------------------------------------------------
def _publish_snapshot(root: Path) -> None:
    rooms = _db_query(
        "SELECT Статус AS status, COUNT(*) AS cnt FROM Номера GROUP BY Статус"
    )
    counts = {r["status"]: r["cnt"] for r in rooms}

    today = datetime.now().strftime("%Y-%m-%d")

    today_checkouts = _db_query(
        """
        SELECT COUNT(*) AS c FROM Бронирования
        WHERE Дата_выезда = ? AND Статус IN ('Заселен', 'Подтверждено')
        """,
        (today,),
    )
    today_guests = _db_query(
        """
        SELECT COUNT(*) AS c FROM Бронирования
        WHERE Дата_заезда <= ? AND Дата_выезда >= ?
          AND Статус IN ('Подтверждено', 'Заселен')
        """,
        (today, today),
    )

    payload = {
        "hotel_name": current_app.config.get("HOTEL_NAME", "Гостиница «Уют»"),
        "rooms_total": sum(counts.values()),
        "rooms_free": counts.get("Свободен", 0),
        "rooms_occupied": counts.get("Занят", 0) + counts.get("Будет занят", 0),
        "guests_today": today_guests[0]["c"] if today_guests else 0,
        "checkouts_today": today_checkouts[0]["c"] if today_checkouts else 0,
    }
    _atomic_write(
        root / "snapshots" / f"{MY_CODE}.json",
        {
            "service": MY_CODE,
            "published_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "payload": payload,
        },
    )
    _log("snapshot опубликован")


# ---------------------------------------------------------------------------
# Основной цикл
# ---------------------------------------------------------------------------
def _loop(app, root: Path) -> None:
    req_dir = root / "requests" / MY_CODE
    last_snap = 0.0
    seen: set[str] = set()

    with app.app_context():
        for d in (
            req_dir,
            root / "responses" / MY_CODE,
            root / "snapshots",
            root / "processed" / MY_CODE,
            root / "tmp",
        ):
            try:
                d.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                _log(f"не удалось создать {d}: {e}")
        _log(f"агент запущен. Слежу за {req_dir}")

    while not _stop.is_set():
        try:
            with app.app_context():
                if req_dir.exists():
                    for f in req_dir.iterdir():
                        if (
                            f.is_file()
                            and f.suffix == ".json"
                            and f.name not in seen
                        ):
                            seen.add(f.name)
                            try:
                                _process_request(root, f)
                            except Exception as e:
                                _log(f"process: {e}")

                now = time.time()
                if now - last_snap >= app.config.get("BUS_SNAPSHOT_INTERVAL", 120):
                    try:
                        _publish_snapshot(root)
                    except Exception as e:
                        _log(f"publish: {e}")
                    last_snap = now
        except Exception as e:
            _log(f"loop: {e}")
        _stop.wait(1.0)

    _log("агент остановлен")


def start(app) -> None:
    global _thread
    root = Path(app.config.get("BUS_ROOT", ""))
    if not root or not str(root):
        app.logger.warning("[bus] BUS_ROOT не задан")
        return
    # На Windows-шаре путь может не существовать локально — не блокируем старт
    if not root.exists():
        app.logger.warning("[bus] папка шины не найдена: %s (агент всё равно запущен)", root)
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(
        target=_loop,
        args=(app, root),
        name="bus-hotel",
        daemon=True,
    )
    _thread.start()


def stop() -> None:
    _stop.set()
    if _thread:
        _thread.join(timeout=3)
