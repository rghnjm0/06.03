import json
import os
import time
import uuid
from datetime import datetime
from pathlib import Path

from flask import current_app


class BusError(Exception):
    pass


def _root() -> Path:
    return Path(current_app.config["BUS_ROOT"])


def _atomic_write(target: Path, data: dict) -> None:
    tmp_dir = _root() / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = tmp_dir / f"{target.name}.{uuid.uuid4().hex}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)


def reserve_table(
    *,
    guests: int,
    guest_name: str = "",
    time_str: str = "",
    table_number=None,
    timeout_sec: float = None,
) -> dict:
    """Забронировать стол в ресторане через шину.

    Возвращает payload ответа:
        {"table_number": 5, "seats": 4, "reservation_id": "RES-..."}
    Бросает BusError при таймауте или ошибке.

    table_number — опционально конкретный стол (int/str).
    """
    if timeout_sec is None:
        timeout_sec = current_app.config.get("BUS_REQUEST_TIMEOUT", 30)

    root = _root()
    rid = f"{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}-{uuid.uuid4().hex[:6]}"

    payload = {
        "guests": int(guests),
        "guest_name": guest_name,
        "time": time_str or datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    if table_number is not None and str(table_number).strip() != "":
        # Число, если возможно — удобнее ресторану
        try:
            payload["table_number"] = int(table_number)
        except (TypeError, ValueError):
            payload["table_number"] = str(table_number).strip()

    req = {
        "request_id": rid,
        "from": "hotel",
        "to": "gurman",
        "type": "reserve_table",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload,
    }
    req_dir = root / "requests" / "gurman"
    try:
        req_dir.mkdir(parents=True, exist_ok=True)
        (root / "responses" / "hotel").mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    _atomic_write(req_dir / f"{rid}.json", req)

    resp_path = root / "responses" / "hotel" / f"{rid}.json"
    deadline = time.monotonic() + timeout_sec

    while time.monotonic() < deadline:
        if resp_path.exists():
            try:
                with open(resp_path, "r", encoding="utf-8") as f:
                    resp = json.load(f)
            except (json.JSONDecodeError, OSError):
                time.sleep(0.3)
                continue

            proc = root / "processed" / "hotel"
            proc.mkdir(parents=True, exist_ok=True)
            try:
                os.replace(resp_path, proc / resp_path.name)
            except OSError:
                pass

            if resp.get("status") == "error":
                raise BusError(
                    resp.get("payload", {}).get("message")
                    or resp.get("payload", {}).get("error")
                    or "ошибка ресторана"
                )
            return resp.get("payload") or {}

        time.sleep(0.5)

    raise BusError(f"Ресторан не ответил за {timeout_sec} с (id={rid})")


def get_restaurant_snapshot() -> dict | None:
    """Читать снимок ресторана (свободные столы и т.д.)."""
    path = _root() / "snapshots" / "gurman.json"
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def list_free_tables(min_seats: int = 1) -> list[dict]:
    """Список свободных столов из снимка ресторана.

    Поддерживает несколько форматов payload:
      - payload.tables.list / payload.tables.free_list
      - payload.free_tables
      - payload.tables как список
      - payload.tables.details
    Элемент: number/table_number/id, seats/capacity, status.
    """
    snap = get_restaurant_snapshot()
    if not snap:
        return []
    payload = snap.get("payload") if isinstance(snap, dict) else None
    if not isinstance(payload, dict):
        payload = snap if isinstance(snap, dict) else {}

    candidates = []
    tables = payload.get("tables")
    if isinstance(tables, dict):
        for key in ("list", "free_list", "details", "items", "available"):
            val = tables.get(key)
            if isinstance(val, list):
                candidates.extend(val)
        # иногда free — число, а all/all_tables — полный список
        for key in ("all", "all_tables"):
            val = tables.get(key)
            if isinstance(val, list):
                candidates.extend(val)
    elif isinstance(tables, list):
        candidates.extend(tables)

    for key in ("free_tables", "available_tables", "table_list"):
        val = payload.get(key)
        if isinstance(val, list):
            candidates.extend(val)

    free = []
    seen = set()
    for t in candidates:
        if not isinstance(t, dict):
            continue
        num = t.get("table_number", t.get("number", t.get("id", t.get("num"))))
        if num is None:
            continue
        status = str(t.get("status", t.get("state", "free"))).lower()
        # считаем свободным, если явно free/available/свободен или статус не reserved/occupied
        busy = status in (
            "reserved", "occupied", "busy", "booked",
            "занят", "забронирован", "reserved_table",
        )
        if busy:
            continue
        seats = t.get("seats", t.get("capacity", t.get("seats_count", 2)))
        try:
            seats_i = int(seats)
        except (TypeError, ValueError):
            seats_i = 2
        if seats_i < int(min_seats or 1):
            continue
        key = str(num)
        if key in seen:
            continue
        seen.add(key)
        free.append({
            "table_number": num,
            "seats": seats_i,
            "status": status or "free",
            "label": f"Стол №{num} ({seats_i} мест)",
        })

    free.sort(key=lambda x: (int(x["table_number"]) if str(x["table_number"]).isdigit() else 999, str(x["table_number"])))
    return free
