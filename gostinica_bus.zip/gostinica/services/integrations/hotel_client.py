import json
import os
import time
import uuid
from datetime import datetime
from pathlib import Path

from flask import current_app


class BusError(Exception):
    pass


def _root() -> Path:
    return Path(current_app.config["BUS_ROOT"])


def _atomic_write(target: Path, data: dict) -> None:
    tmp_dir = _root() / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = tmp_dir / f"{target.name}.{uuid.uuid4().hex}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)


def reserve_table(*, guests: int, guest_name: str = "",
                  time_str: str = "", timeout_sec: float = None) -> dict:
    """Забронировать стол в ресторане через шину.

    Возвращает payload ответа:
        {"table_number": 5, "seats": 4, "reservation_id": "RES-..."}
    Бросает BusError при таймауте или ошибке.
    """
    if timeout_sec is None:
        timeout_sec = current_app.config.get("BUS_REQUEST_TIMEOUT", 30)

    root = _root()
    rid = f"{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}-{uuid.uuid4().hex[:6]}"

    req = {
        "request_id": rid,
        "from": "hotel",
        "to": "gurman",
        "type": "reserve_table",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": {
            "guests": int(guests),
            "guest_name": guest_name,
            "time": time_str or datetime.now().strftime("%Y-%m-%d %H:%M"),
        },
    }
    req_dir = root / "requests" / "gurman"
    try:
        req_dir.mkdir(parents=True, exist_ok=True)
        (root / "responses" / "hotel").mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    _atomic_write(req_dir / f"{rid}.json", req)

    resp_path = root / "responses" / "hotel" / f"{rid}.json"
    deadline = time.monotonic() + timeout_sec

    while time.monotonic() < deadline:
        if resp_path.exists():
            try:
                with open(resp_path, "r", encoding="utf-8") as f:
                    resp = json.load(f)
            except (json.JSONDecodeError, OSError):
                time.sleep(0.3)
                continue

            # Аудит: в processed/
            proc = root / "processed" / "hotel"
            proc.mkdir(parents=True, exist_ok=True)
            try:
                os.replace(resp_path, proc / resp_path.name)
            except OSError:
                pass

            if resp.get("status") == "error":
                raise BusError(
                    resp.get("payload", {}).get("message", "ошибка ресторана")
                )
            return resp.get("payload") or {}

        time.sleep(0.5)

    raise BusError(f"Ресторан не ответил за {timeout_sec} с (id={rid})")


def get_restaurant_snapshot() -> dict | None:
    """Читать снимок ресторана (свободные столы и т.д.)."""
    path = _root() / "snapshots" / "gurman.json"
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None