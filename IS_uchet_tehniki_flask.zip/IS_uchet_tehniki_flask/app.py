#!/usr/bin/env python3
"""
Информационная система учёта техники в техникуме
Flask-версия · Учебная практика ПМ 06
"""

from flask import Flask, render_template, request, redirect, url_for, flash, send_file
import sqlite3
from datetime import datetime, date
import os
import io
import csv

app = Flask(__name__)
app.secret_key = "uchet_tehniki_2026"

DB_PATH = os.path.join(os.path.dirname(__file__), "uchet_tehniki.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def query(sql, params=None):
    conn = get_db()
    cur = conn.execute(sql, params or ())
    rows = cur.fetchall()
    conn.close()
    return rows


def execute(sql, params=None):
    conn = get_db()
    cur = conn.execute(sql, params or ())
    conn.commit()
    last_id = cur.lastrowid
    conn.close()
    return last_id


def get_categories():
    return query("SELECT id, name FROM categories ORDER BY name")


def get_locations():
    return query("SELECT id, name, building FROM locations ORDER BY name")


def get_responsible():
    return query("SELECT id, full_name, position FROM responsible ORDER BY full_name")


# ===================== ГЛАВНАЯ =====================
@app.route("/")
def index():
    total = query("SELECT COUNT(*) as c FROM equipment")[0]["c"]
    in_use = query("SELECT COUNT(*) as c FROM equipment WHERE status='В эксплуатации'")[0]["c"]
    in_repair = query("SELECT COUNT(*) as c FROM equipment WHERE status='В ремонте'")[0]["c"]
    on_stock = query("SELECT COUNT(*) as c FROM equipment WHERE status='На складе'")[0]["c"]
    written = query("SELECT COUNT(*) as c FROM equipment WHERE status='Списано'")[0]["c"]
    total_cost = query("SELECT COALESCE(SUM(cost),0) as s FROM equipment WHERE status!='Списано'")[0]["s"]

    by_status = query("""
        SELECT status, COUNT(*) as cnt FROM equipment GROUP BY status ORDER BY cnt DESC
    """)
    by_cat = query("""
        SELECT c.name, COUNT(e.id) as cnt
        FROM categories c LEFT JOIN equipment e ON e.category_id=c.id
        GROUP BY c.id ORDER BY cnt DESC
    """)
    recent = query("""
        SELECT e.inv_number, e.name, c.name as cat, e.status, e.purchase_date
        FROM equipment e LEFT JOIN categories c ON c.id=e.category_id
        ORDER BY e.id DESC LIMIT 5
    """)

    return render_template("index.html",
                           total=total, in_use=in_use, in_repair=in_repair,
                           on_stock=on_stock, written=written, total_cost=total_cost,
                           by_status=by_status, by_cat=by_cat, recent=recent)


# ===================== СПИСОК =====================
@app.route("/list")
def equipment_list():
    status = request.args.get("status", "")
    category = request.args.get("category", "")
    location = request.args.get("location", "")
    search = request.args.get("search", "")

    sql = """
        SELECT e.id, e.inv_number, e.name, c.name as category, e.serial_number,
               l.name as location, r.full_name as mol, e.status, e.cost, e.purchase_date
        FROM equipment e
        LEFT JOIN categories c ON c.id=e.category_id
        LEFT JOIN locations l ON l.id=e.location_id
        LEFT JOIN responsible r ON r.id=e.responsible_id
        WHERE 1=1
    """
    params = []
    if status:
        sql += " AND e.status=?"
        params.append(status)
    if category:
        sql += " AND c.name=?"
        params.append(category)
    if location:
        sql += " AND l.name=?"
        params.append(location)
    if search:
        sql += " AND (e.inv_number LIKE ? OR e.name LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    sql += " ORDER BY e.inv_number"

    items = query(sql, params)
    return render_template("list.html",
                           items=items,
                           categories=get_categories(),
                           locations=get_locations(),
                           status=status, category=category,
                           location=location, search=search)


# ===================== ДОБАВИТЬ =====================
@app.route("/add", methods=["GET", "POST"])
def add_equipment():
    if request.method == "POST":
        inv = request.form.get("inv_number", "").strip()
        name = request.form.get("name", "").strip()
        if not inv or not name:
            flash("Заполните обязательные поля", "danger")
            return redirect(url_for("add_equipment"))
        try:
            execute("""
                INSERT INTO equipment
                (inv_number, name, category_id, serial_number, purchase_date, cost,
                 location_id, responsible_id, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                inv, name,
                request.form.get("category_id"),
                request.form.get("serial_number") or None,
                request.form.get("purchase_date") or None,
                float(request.form.get("cost") or 0),
                request.form.get("location_id"),
                request.form.get("responsible_id"),
                request.form.get("status", "В эксплуатации"),
                request.form.get("notes") or None
            ))
            flash(f"Техника {inv} успешно добавлена", "success")
            return redirect(url_for("equipment_list"))
        except sqlite3.IntegrityError:
            flash("Инвентарный номер уже существует", "danger")
    return render_template("add.html",
                           categories=get_categories(),
                           locations=get_locations(),
                           responsible=get_responsible(),
                           today=date.today().isoformat())


# ===================== ПЕРЕМЕЩЕНИЕ =====================
@app.route("/move", methods=["GET", "POST"])
def move_equipment():
    if request.method == "POST":
        eq_id = request.form.get("equipment_id")
        new_loc = request.form.get("location_id")
        new_resp = request.form.get("responsible_id")
        move_date = request.form.get("move_date") or date.today().isoformat()
        reason = request.form.get("reason", "")

        old = query("SELECT location_id, responsible_id FROM equipment WHERE id=?", (eq_id,))[0]
        execute("""
            INSERT INTO movements
            (equipment_id, from_location_id, to_location_id,
             from_responsible_id, to_responsible_id, move_date, reason)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (eq_id, old["location_id"], new_loc, old["responsible_id"], new_resp, move_date, reason))
        execute("""
            UPDATE equipment SET location_id=?, responsible_id=?, status='В эксплуатации' WHERE id=?
        """, (new_loc, new_resp, eq_id))
        flash("Перемещение выполнено", "success")
        return redirect(url_for("move_equipment"))

    equipment = query("""
        SELECT id, inv_number || ' — ' || name as label
        FROM equipment WHERE status IN ('В эксплуатации','На складе') ORDER BY inv_number
    """)
    history = query("""
        SELECT e.inv_number, e.name, fl.name as from_loc, tl.name as to_loc,
               m.move_date, m.reason
        FROM movements m
        JOIN equipment e ON e.id=m.equipment_id
        LEFT JOIN locations fl ON fl.id=m.from_location_id
        LEFT JOIN locations tl ON tl.id=m.to_location_id
        ORDER BY m.move_date DESC LIMIT 15
    """)
    return render_template("move.html",
                           equipment=equipment,
                           locations=get_locations(),
                           responsible=get_responsible(),
                           history=history,
                           today=date.today().isoformat())


# ===================== РЕМОНТ =====================
@app.route("/repair", methods=["GET", "POST"])
def repair():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "start":
            eq_id = request.form.get("equipment_id")
            desc = request.form.get("description", "")
            start = request.form.get("start_date") or date.today().isoformat()
            execute("""
                INSERT INTO repairs (equipment_id, start_date, description, status)
                VALUES (?, ?, ?, 'В работе')
            """, (eq_id, start, desc))
            execute("UPDATE equipment SET status='В ремонте' WHERE id=?", (eq_id,))
            flash("Техника отправлена в ремонт", "success")
        elif action == "finish":
            repair_id = request.form.get("repair_id")
            cost = float(request.form.get("cost") or 0)
            eq_inv = request.form.get("inv_number")
            execute("""
                UPDATE repairs SET end_date=?, cost=?, status='Завершён' WHERE id=?
            """, (date.today().isoformat(), cost, repair_id))
            execute("UPDATE equipment SET status='В эксплуатации' WHERE inv_number=?", (eq_inv,))
            flash("Ремонт завершён", "success")
        return redirect(url_for("repair"))

    equipment = query("""
        SELECT id, inv_number || ' — ' || name as label
        FROM equipment WHERE status IN ('В эксплуатации','На складе') ORDER BY inv_number
    """)
    repairs = query("""
        SELECT r.id, e.inv_number, e.name, r.start_date, r.end_date,
               r.description, r.cost, r.status
        FROM repairs r JOIN equipment e ON e.id=r.equipment_id
        ORDER BY r.start_date DESC
    """)
    return render_template("repair.html",
                           equipment=equipment,
                           repairs=repairs,
                           today=date.today().isoformat())


# ===================== СПИСАНИЕ =====================
@app.route("/writeoff", methods=["GET", "POST"])
def writeoff():
    if request.method == "POST":
        eq_id = request.form.get("equipment_id")
        reason = request.form.get("reason", "").strip()
        wdate = request.form.get("writeoff_date") or date.today().isoformat()
        if not reason:
            flash("Укажите основание списания", "danger")
        else:
            execute("""
                UPDATE equipment SET status='Списано',
                notes = COALESCE(notes,'') || ?
                WHERE id=?
            """, (f"\n[Списано {wdate}: {reason}]", eq_id))
            flash("Техника списана", "success")
        return redirect(url_for("writeoff"))

    equipment = query("""
        SELECT id, inv_number || ' — ' || name || ' (' || status || ')' as label
        FROM equipment WHERE status != 'Списано' ORDER BY inv_number
    """)
    written = query("""
        SELECT inv_number, name, cost, notes FROM equipment WHERE status='Списано' ORDER BY inv_number
    """)
    return render_template("writeoff.html",
                           equipment=equipment,
                           written=written,
                           today=date.today().isoformat())


# ===================== ОТЧЁТЫ =====================
@app.route("/reports")
def reports():
    report = request.args.get("type", "mol")

    if report == "mol":
        data = query("""
            SELECT r.full_name, r.position, COUNT(e.id) as cnt, COALESCE(SUM(e.cost),0) as total
            FROM responsible r
            LEFT JOIN equipment e ON e.responsible_id=r.id AND e.status!='Списано'
            GROUP BY r.id ORDER BY cnt DESC
        """)
        title = "Ведомость по МОЛ"
    elif report == "location":
        data = query("""
            SELECT l.name, l.building, COUNT(e.id) as cnt, COALESCE(SUM(e.cost),0) as total
            FROM locations l
            LEFT JOIN equipment e ON e.location_id=l.id AND e.status!='Списано'
            GROUP BY l.id ORDER BY cnt DESC
        """)
        title = "Ведомость по кабинетам"
    elif report == "cost":
        data = query("""
            SELECT c.name, COUNT(e.id) as cnt, COALESCE(SUM(e.cost),0) as total, COALESCE(AVG(e.cost),0) as avg
            FROM categories c
            LEFT JOIN equipment e ON e.category_id=c.id AND e.status!='Списано'
            GROUP BY c.id HAVING cnt > 0 ORDER BY total DESC
        """)
        title = "Сводка по стоимости"
    elif report == "repair":
        data = query("""
            SELECT e.inv_number, e.name, r.start_date, r.description
            FROM equipment e
            JOIN repairs r ON r.equipment_id=e.id AND r.status='В работе'
            WHERE e.status='В ремонте'
        """)
        title = "Техника в ремонте"
    else:
        data = query("""
            SELECT e.inv_number, e.name, c.name as cat, l.name as loc,
                   r.full_name as mol, e.status, e.cost, e.purchase_date
            FROM equipment e
            LEFT JOIN categories c ON c.id=e.category_id
            LEFT JOIN locations l ON l.id=e.location_id
            LEFT JOIN responsible r ON r.id=e.responsible_id
            ORDER BY e.inv_number
        """)
        title = "Полный реестр"

    return render_template("reports.html", data=data, report=report, title=title)


@app.route("/export")
def export_csv():
    rows = query("""
        SELECT e.inv_number, e.name, c.name as cat, l.name as loc,
               r.full_name as mol, e.status, e.cost, e.purchase_date
        FROM equipment e
        LEFT JOIN categories c ON c.id=e.category_id
        LEFT JOIN locations l ON l.id=e.location_id
        LEFT JOIN responsible r ON r.id=e.responsible_id
        ORDER BY e.inv_number
    """)
    buf = io.StringIO()
    writer = csv.writer(buf, delimiter=';')
    writer.writerow(["Инв. №", "Наименование", "Категория", "Местоположение",
                     "МОЛ", "Статус", "Стоимость", "Дата покупки"])
    for r in rows:
        writer.writerow([
            r["inv_number"], r["name"], r["cat"] or "", r["loc"] or "",
            r["mol"] or "", r["status"], r["cost"] or "", r["purchase_date"] or ""
        ])
    # utf-8-sig для корректного открытия в Excel
    output = io.BytesIO(buf.getvalue().encode("utf-8-sig"))
    output.seek(0)
    return send_file(output, mimetype="text/csv", as_attachment=True,
                     download_name="reestr_tehniki.csv")


# ===================== СПРАВОЧНИКИ =====================
@app.route("/refs", methods=["GET", "POST"])
def refs():
    if request.method == "POST":
        kind = request.form.get("kind")
        if kind == "category":
            name = request.form.get("name", "").strip()
            if name:
                try:
                    execute("INSERT INTO categories (name) VALUES (?)", (name,))
                    flash("Категория добавлена", "success")
                except:
                    flash("Уже существует", "danger")
        elif kind == "location":
            name = request.form.get("name", "").strip()
            building = request.form.get("building", "Основной корпус")
            if name:
                try:
                    execute("INSERT INTO locations (name, building) VALUES (?, ?)", (name, building))
                    flash("Местоположение добавлено", "success")
                except:
                    flash("Уже существует", "danger")
        elif kind == "responsible":
            fio = request.form.get("full_name", "").strip()
            pos = request.form.get("position", "")
            phone = request.form.get("phone", "")
            if fio:
                execute("INSERT INTO responsible (full_name, position, phone) VALUES (?, ?, ?)",
                        (fio, pos, phone))
                flash("МОЛ добавлен", "success")
        return redirect(url_for("refs"))

    return render_template("refs.html",
                           categories=get_categories(),
                           locations=get_locations(),
                           responsible=get_responsible())


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        print("База не найдена. Запустите init_db.py")
    else:
        print("Система учёта техники запущена: http://127.0.0.1:5000")
        app.run(debug=True, host="0.0.0.0", port=5000)
