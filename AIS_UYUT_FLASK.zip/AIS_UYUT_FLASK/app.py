from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime

app = Flask(__name__)
app.secret_key = "uyut-demo-secret-key"

rooms = [
    {"number": "101", "category": "Стандарт", "beds": 2, "price": 4500, "status": "Свободен"},
    {"number": "102", "category": "Стандарт", "beds": 2, "price": 4500, "status": "Занят"},
    {"number": "201", "category": "Комфорт", "beds": 2, "price": 6200, "status": "Свободен"},
    {"number": "202", "category": "Комфорт", "beds": 3, "price": 6800, "status": "Уборка"},
    {"number": "301", "category": "Люкс", "beds": 2, "price": 9500, "status": "Свободен"},
    {"number": "302", "category": "Люкс", "beds": 3, "price": 10500, "status": "Занят"},
]

bookings = [
    {"id": 1, "guest": "Иван Петров", "room": "102", "checkin": "18.09.2026", "checkout": "21.09.2026", "status": "Подтверждено", "amount": 13500},
    {"id": 2, "guest": "Анна Смирнова", "room": "302", "checkin": "20.09.2026", "checkout": "23.09.2026", "status": "Ожидает оплаты", "amount": 31500},
    {"id": 3, "guest": "Дмитрий Волков", "room": "201", "checkin": "17.09.2026", "checkout": "19.09.2026", "status": "Заезд", "amount": 12400},
]

guests = [
    {"name": "Иван Петров", "phone": "+7 900 123-45-67", "visits": 4, "last": "18.09.2026"},
    {"name": "Анна Смирнова", "phone": "+7 901 222-33-44", "visits": 2, "last": "20.09.2026"},
    {"name": "Дмитрий Волков", "phone": "+7 902 555-66-77", "visits": 1, "last": "17.09.2026"},
]

@app.context_processor
def inject_globals():
    return {
        "now": datetime.now().strftime("%d.%m.%Y"),
        "free_rooms": sum(r["status"] == "Свободен" for r in rooms),
        "occupied_rooms": sum(r["status"] == "Занят" for r in rooms),
    }

@app.route("/")
def dashboard():
    return render_template("dashboard.html", active="dashboard")

@app.route("/bookings", methods=["GET", "POST"])
def bookings_page():
    if request.method == "POST":
        guest = request.form.get("guest", "").strip()
        room = request.form.get("room", "").strip()
        checkin = request.form.get("checkin", "")
        checkout = request.form.get("checkout", "")
        if guest and room and checkin and checkout:
            try:
                start = datetime.strptime(checkin, "%Y-%m-%d")
                end = datetime.strptime(checkout, "%Y-%m-%d")
                nights = max((end - start).days, 1)
                room_data = next((r for r in rooms if r["number"] == room), None)
                amount = nights * (room_data["price"] if room_data else 0)
                bookings.append({
                    "id": len(bookings) + 1,
                    "guest": guest,
                    "room": room,
                    "checkin": start.strftime("%d.%m.%Y"),
                    "checkout": end.strftime("%d.%m.%Y"),
                    "status": "Новое",
                    "amount": amount
                })
                flash("Бронирование создано.", "success")
            except ValueError:
                flash("Проверьте даты бронирования.", "error")
        else:
            flash("Заполните все поля.", "error")
        return redirect(url_for("bookings_page"))
    return render_template("bookings.html", active="bookings", bookings=bookings, rooms=rooms)

@app.route("/rooms")
def rooms_page():
    return render_template("rooms.html", active="rooms", rooms=rooms)

@app.route("/guests")
def guests_page():
    return render_template("guests.html", active="guests", guests=guests)

@app.route("/reports")
def reports():
    return render_template("reports.html", active="reports", bookings=bookings, rooms=rooms)

@app.route("/settings")
def settings():
    return render_template("settings.html", active="settings")

@app.route("/checkin/<int:booking_id>")
def checkin(booking_id):
    booking = next((b for b in bookings if b["id"] == booking_id), None)
    if booking:
        booking["status"] = "Проживает"
        for room in rooms:
            if room["number"] == booking["room"]:
                room["status"] = "Занят"
        flash("Гость успешно зарегистрирован.", "success")
    return redirect(url_for("bookings_page"))

@app.route("/checkout/<int:booking_id>")
def checkout(booking_id):
    booking = next((b for b in bookings if b["id"] == booking_id), None)
    if booking:
        booking["status"] = "Выселен"
        for room in rooms:
            if room["number"] == booking["room"]:
                room["status"] = "Уборка"
        flash("Выселение оформлено. Номер передан в уборку.", "success")
    return redirect(url_for("bookings_page"))

if __name__ == "__main__":
    app.run(debug=True)
