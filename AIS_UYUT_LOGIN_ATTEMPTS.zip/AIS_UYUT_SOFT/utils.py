"""Общие вспомогательные функции приложения «Уют»."""
import os
from datetime import datetime, timedelta
from flask import url_for
from db import get_db

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOMS_DIR = os.path.join(BASE_DIR, "static", "images", "rooms")
ACTIVE_BOOKING_STATUSES = ("Подтверждено", "Заселен")


def init_uploads():
    os.makedirs(ROOMS_DIR, exist_ok=True)


def get_room_image(room_number):
    room_number_str = str(room_number)
    extensions = (".jpg", ".jpeg", ".png", ".webp")
    for ext in extensions:
        filename = f"{room_number_str}{ext}"
        if os.path.isfile(os.path.join(ROOMS_DIR, filename)):
            return url_for("static", filename=f"images/rooms/{filename}")
    available = sorted(
        f for f in os.listdir(ROOMS_DIR)
        if os.path.isfile(os.path.join(ROOMS_DIR, f)) and f.lower().endswith(extensions)
    )
    if available:
        filename = available[sum(ord(ch) for ch in room_number_str) % len(available)]
        return url_for("static", filename=f"images/rooms/{filename}")
    return ""


def get_room_image_extra(room_number, index):
    return get_room_image(room_number)


def normalize_date(value):
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    return str(value)


def booking_conflicts(conn, room_id, check_in, check_out, exclude_booking_id=None):
    """True, если даты пересекаются с подтверждённой/заселённой бронью."""
    query = """
        SELECT ID_Бронирования
        FROM Бронирования
        WHERE ID_Номера = ?
          AND Статус IN ('Подтверждено', 'Заселен')
          AND NOT (Дата_выезда <= ? OR Дата_заезда >= ?)
    """
    params = [room_id, check_in, check_out]
    if exclude_booking_id:
        query += " AND ID_Бронирования <> ?"
        params.append(exclude_booking_id)
    return conn.execute(query, params).fetchone() is not None


def next_id(conn, table, prefix, field):
    """Генерирует следующий ID без зависимости от COUNT(), поэтому удаление записей не ломает IDs."""
    row = conn.execute(
        f"SELECT {field} FROM {table} WHERE {field} LIKE ? ORDER BY {field} DESC LIMIT 1",
        (f"{prefix}%",),
    ).fetchone()
    if not row or not row[field]:
        return f"{prefix}001"
    digits = "".join(ch for ch in str(row[field]) if ch.isdigit())
    number = int(digits or 0) + 1
    return f"{prefix}{number:03d}"


def booking_total(conn, room_id, check_in, check_out):
    room = conn.execute("SELECT Цена_за_сутки FROM Номера WHERE ID_Номера = ?", (room_id,)).fetchone()
    if not room:
        return 0.0, 0
    start = datetime.strptime(str(check_in), "%Y-%m-%d").date()
    end = datetime.strptime(str(check_out), "%Y-%m-%d").date()
    nights = (end - start).days
    return max(nights, 0) * float(room["Цена_за_сутки"]), max(nights, 0)


def sync_room_statuses():
    """Пересчитывает фактический статус каждого номера из бронирований.

    Правило:
    - сегодня проживание -> «Занят»;
    - есть будущая активная бронь -> «Будет занят»;
    - иначе -> «Свободен».
    Прошедшие подтверждённые/заселённые брони переводятся в «Завершено».
    """
    conn = get_db()
    try:
        today = datetime.now().date().strftime("%Y-%m-%d")
        conn.execute("""
            UPDATE Бронирования
            SET Статус = 'Завершено'
            WHERE Статус IN ('Подтверждено', 'Заселен')
              AND Дата_выезда <= ?
        """, (today,))

        conn.execute("UPDATE Номера SET Статус = 'Свободен'")
        conn.execute("""
            UPDATE Номера
            SET Статус = 'Занят'
            WHERE ID_Номера IN (
                SELECT DISTINCT ID_Номера
                FROM Бронирования
                WHERE Статус IN ('Подтверждено', 'Заселен')
                  AND Дата_заезда <= ?
                  AND Дата_выезда > ?
            )
        """, (today, today))
        conn.execute("""
            UPDATE Номера
            SET Статус = 'Будет занят'
            WHERE Статус = 'Свободен'
              AND ID_Номера IN (
                SELECT DISTINCT ID_Номера
                FROM Бронирования
                WHERE Статус IN ('Подтверждено', 'Заселен')
                  AND Дата_заезда > ?
              )
        """, (today,))
        conn.commit()
        return True
    finally:
        conn.close()


def register_context_processors(app):
    @app.context_processor
    def utility_processor():
        return {
            "now": datetime.now(),
            "today": datetime.now().date(),
            "timedelta": timedelta,
            "get_room_image": get_room_image,
            "get_room_image_extra": get_room_image_extra,
        }
