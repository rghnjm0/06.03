"""Внешние интеграции: ЮKassa и SMS.RU.

Ключи берутся только из переменных окружения. Никакие секреты не хранятся в коде.
"""
import os
import uuid
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlencode

import requests


class IntegrationError(Exception):
    pass


def _money(value):
    return str(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def yookassa_configured():
    return bool(os.getenv("YOOKASSA_SHOP_ID") and os.getenv("YOOKASSA_SECRET_KEY"))


def sms_configured():
    return bool(os.getenv("SMSRU_API_ID"))


def create_yookassa_payment(amount, description, return_url, booking_id):
    """Создаёт одностадийный redirect-платёж в ЮKassa.

    Для тестового магазина ЮKassa используются те же API-вызовы, но с тестовыми
    ключами. Реальные деньги не списываются в тестовом магазине.
    """
    shop_id = os.getenv("YOOKASSA_SHOP_ID")
    secret = os.getenv("YOOKASSA_SECRET_KEY")
    if not shop_id or not secret:
        raise IntegrationError("ЮKassa не настроена: задайте YOOKASSA_SHOP_ID и YOOKASSA_SECRET_KEY")

    payload = {
        "amount": {"value": _money(amount), "currency": "RUB"},
        "capture": True,
        "confirmation": {"type": "redirect", "return_url": return_url},
        "description": description[:128],
        "metadata": {"booking_id": str(booking_id)},
    }
    idem = str(uuid.uuid4())
    response = requests.post(
        "https://api.yookassa.ru/v3/payments",
        auth=(shop_id, secret),
        headers={"Idempotence-Key": idem, "Content-Type": "application/json"},
        json=payload,
        timeout=20,
    )
    if response.status_code not in (200, 201):
        raise IntegrationError(f"ЮKassa вернула HTTP {response.status_code}: {response.text[:300]}")
    data = response.json()
    confirmation = data.get("confirmation", {})
    confirmation_url = confirmation.get("confirmation_url")
    if not confirmation_url:
        raise IntegrationError("ЮKassa не вернула ссылку на оплату")
    return {
        "payment_id": data["id"],
        "status": data.get("status", "pending"),
        "confirmation_url": confirmation_url,
        "amount": data.get("amount", {}).get("value", _money(amount)),
    }


def get_yookassa_payment(payment_id):
    shop_id = os.getenv("YOOKASSA_SHOP_ID")
    secret = os.getenv("YOOKASSA_SECRET_KEY")
    if not shop_id or not secret:
        raise IntegrationError("ЮKassa не настроена")
    response = requests.get(
        f"https://api.yookassa.ru/v3/payments/{payment_id}",
        auth=(shop_id, secret),
        timeout=20,
    )
    if response.status_code != 200:
        raise IntegrationError(f"ЮKassa вернула HTTP {response.status_code}: {response.text[:300]}")
    return response.json()


def send_sms(phone, message):
    """Отправляет SMS через SMS.RU. Возвращает sms_id или None.

    Без SMSRU_API_ID приложение не ломается: сообщение просто не отправляется.
    """
    api_id = os.getenv("SMSRU_API_ID")
    if not api_id:
        return None
    normalized = "".join(ch for ch in str(phone) if ch.isdigit())
    if normalized.startswith("8") and len(normalized) == 11:
        normalized = "7" + normalized[1:]
    if normalized.startswith("+7"):
        normalized = normalized[1:]
    params = {
        "api_id": api_id,
        "to": normalized,
        "msg": message[:500],
        "json": 1,
    }
    response = requests.get("https://sms.ru/sms/send", params=params, timeout=20)
    if response.status_code != 200:
        raise IntegrationError(f"SMS.RU HTTP {response.status_code}")
    data = response.json()
    if data.get("status") != "OK":
        raise IntegrationError(data.get("status_text") or f"SMS.RU code {data.get('status_code')}")
    item = (data.get("sms") or {}).get(normalized, {})
    if item.get("status") != "OK":
        raise IntegrationError(item.get("status_text") or "SMS.RU не принял сообщение")
    return item.get("sms_id")


def public_base_url():
    return os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:5000").rstrip("/")
