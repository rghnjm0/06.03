from flask import Blueprint, current_app, redirect, url_for, flash, session, request
from datetime import datetime
from db import get_db
from auth import login_required
from hotel_logic import log_action
from integrations import create_yookassa_payment, get_yookassa_payment, IntegrationError, public_base_url, send_sms

payments_bp = Blueprint("payments", __name__)


def ensure_payment_schema():
    conn = get_db()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS Платежи (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                ID_Бронирования TEXT NOT NULL,
                Провайдер TEXT NOT NULL,
                ID_Платежа TEXT UNIQUE NOT NULL,
                Сумма REAL NOT NULL,
                Статус TEXT NOT NULL,
                Ссылка_на_оплату TEXT,
                Создано TEXT NOT NULL,
                Обновлено TEXT,
                FOREIGN KEY (ID_Бронирования) REFERENCES Бронирования(ID_Бронирования) ON DELETE CASCADE
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_payments_booking ON Платежи(ID_Бронирования)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_payments_status ON Платежи(Статус)")
        conn.commit()
    finally:
        conn.close()


def _send_payment_sms(conn, booking_id, text):
    row = conn.execute("""
        SELECT c.Телефон FROM Бронирования b JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента
        WHERE b.ID_Бронирования=?
    """, (booking_id,)).fetchone()
    if not row:
        return
    try:
        send_sms(row["Телефон"], text)
    except Exception as exc:
        current_app.logger.warning("SMS error for %s: %s", booking_id, exc)


def mark_payment_success(payment_id):
    conn = get_db()
    try:
        payment = conn.execute("SELECT * FROM Платежи WHERE ID_Платежа=?", (payment_id,)).fetchone()
        if not payment:
            return None
        data = get_yookassa_payment(payment_id)
        status = data.get("status", "unknown")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        conn.execute("UPDATE Платежи SET Статус=?, Обновлено=? WHERE ID_Платежа=?", (status, now, payment_id))
        if status == "succeeded" and data.get("paid"):
            conn.execute("UPDATE Счета SET Оплачено=1, Способ_оплаты='ЮKassa', Дата_оплаты=date('now') WHERE ID_Бронирования=?", (payment["ID_Бронирования"],))
            conn.execute("UPDATE Бронирования SET Предоплата=? WHERE ID_Бронирования=?", (payment["Сумма"], payment["ID_Бронирования"]))
            conn.commit()
            _send_payment_sms(conn, payment["ID_Бронирования"], f"Уют: оплата по брони {payment['ID_Бронирования']} получена. Спасибо!")
            log_action("Оплата получена", payment["ID_Бронирования"], f"ЮKassa, {payment['Сумма']:.2f} ₽")
        else:
            conn.commit()
        return status
    finally:
        conn.close()


@payments_bp.post("/payment/create/<string:booking_id>")
@login_required
def create_payment(booking_id):
    conn = get_db()
    try:
        booking = conn.execute("""
            SELECT b.*, n.Номер_Комнаты, c.Телефон FROM Бронирования b
            JOIN Номера n ON n.ID_Номера=b.ID_Номера
            JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента
            WHERE b.ID_Бронирования=? AND b.ID_Клиента=?
        """, (booking_id, session.get("client_id"))).fetchone()
        invoice = conn.execute("SELECT * FROM Счета WHERE ID_Бронирования=?", (booking_id,)).fetchone()
        if not booking or not invoice:
            flash("Бронирование или счёт не найден.", "danger")
            return redirect(url_for("profile"))
        if invoice["Оплачено"]:
            flash("Эта бронь уже оплачена.", "info")
            return redirect(url_for("booking_confirmation", booking_id=booking_id))
        amount = float(booking["Предоплата"] or round(float(invoice["Сумма_проживание"]) * 0.30, 2))
        if amount <= 0:
            flash("Сумма оплаты должна быть больше нуля.", "danger")
            return redirect(url_for("booking_confirmation", booking_id=booking_id))

        result = create_yookassa_payment(
            amount,
            f"Предоплата за бронь {booking_id}, номер {booking['Номер_Комнаты']}",
            public_base_url() + url_for("payments.payment_return", booking_id=booking_id),
            booking_id,
        )
        conn.execute("""
            INSERT INTO Платежи(ID_Бронирования,Провайдер,ID_Платежа,Сумма,Статус,Ссылка_на_оплату,Создано)
            VALUES(?,?,?,?,?,?,?)
        """, (booking_id, "ЮKassa", result["payment_id"], amount, result["status"], result["confirmation_url"], datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        return redirect(result["confirmation_url"])
    except IntegrationError as exc:
        conn.rollback()
        flash(str(exc), "warning")
        return redirect(url_for("booking_confirmation", booking_id=booking_id))
    except Exception as exc:
        conn.rollback()
        current_app.logger.exception("payment create error")
        flash("Не удалось создать платёж. Попробуйте ещё раз.", "danger")
        return redirect(url_for("booking_confirmation", booking_id=booking_id))
    finally:
        conn.close()


@payments_bp.get("/payment/return/<string:booking_id>")
@login_required
def payment_return(booking_id):
    conn = get_db()
    try:
        payment = conn.execute("SELECT * FROM Платежи WHERE ID_Бронирования=? ORDER BY ID DESC LIMIT 1", (booking_id,)).fetchone()
    finally:
        conn.close()
    if payment:
        try:
            status = mark_payment_success(payment["ID_Платежа"])
            if status == "succeeded":
                flash("Оплата успешно получена.", "success")
            elif status == "canceled":
                flash("Платёж отменён.", "warning")
            else:
                flash("Платёж ещё обрабатывается. Обновите личный кабинет позже.", "info")
        except IntegrationError:
            flash("Не удалось проверить статус платежа. Попробуйте обновить страницу позже.", "warning")
    return redirect(url_for("booking_confirmation", booking_id=booking_id))


@payments_bp.post("/payment/webhook")
def payment_webhook():
    payload = request.get_json(silent=True) or {}
    obj = payload.get("object") or {}
    payment_id = obj.get("id")
    if payment_id:
        try:
            mark_payment_success(payment_id)
        except Exception:
            current_app.logger.exception("payment webhook error")
    return "ok", 200
