# app.py
"""Точка входа в приложение отеля «Уют».

Маршруты и служебная логика вынесены в отдельные модули,
чтобы проект было проще поддерживать и расширять.
"""
import os
import secrets
from flask import Flask
from db import DB_NAME, get_db
from utils import init_uploads, sync_room_statuses, register_context_processors
from auth import hash_password
from routes.public import register_public_routes
from routes.auth import register_auth_routes
from routes.admin import register_admin_routes
from hotel_logic import ensure_extended_schema
from routes.payments import payments_bp, ensure_payment_schema

app = Flask(__name__)
app.secret_key = os.environ.get("UYUT_SECRET_KEY") or secrets.token_hex(32)
app.config["UPLOAD_FOLDER"] = "static/images/rooms"
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

init_uploads()
register_context_processors(app)
register_public_routes(app)
register_auth_routes(app)
register_admin_routes(app)
app.register_blueprint(payments_bp)
ensure_extended_schema()
ensure_payment_schema()


def migrate_passwords():
    """Однократно переводит старые открытые пароли из учебной БД в хэши."""
    if not os.path.exists(DB_NAME):
        return
    conn = get_db()
    try:
        rows = conn.execute("SELECT ID_Клиента, Пароль FROM Пользователи").fetchall()
        for row in rows:
            stored = row["Пароль"]
            if stored and not str(stored).startswith(("scrypt:", "pbkdf2:", "argon2:")):
                new_hash = hash_password(stored)
                conn.execute("UPDATE Пользователи SET Пароль=? WHERE ID_Клиента=?", (new_hash, row["ID_Клиента"]))
                conn.execute("UPDATE Сотрудники SET Пароль=? WHERE ID_Сотрудника=?", (new_hash, row["ID_Клиента"]))
        conn.commit()
    finally:
        conn.close()

migrate_passwords()

if __name__ == "__main__":
    if not os.path.exists(DB_NAME):
        print("База данных не найдена. Запустите: python db.py")
    else:
        sync_room_statuses()
        app.run(debug=True, host="0.0.0.0", port=5000)
