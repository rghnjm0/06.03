"""
Мониторинг производительности SQL и HTTP-маршрутов для Flask + SQLite.

Что умеет:
- На каждый HTTP-запрос фиксирует: метод, маршрут (rule), endpoint, статус,
  количество SQL-запросов, суммарное время SQL, общее время обработки.
- Хранит последние N событий в памяти процесса.
- Агрегирует статистику по паре (метод + маршрут).
- По кнопке «Проверить» запускает набор тестовых запросов к ключевым маршрутам
  и сразу показывает результаты.
"""
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime
from threading import Lock
from time import perf_counter
from typing import Any, Dict, List, Optional, Tuple

from flask import Flask, g, request, session


MAX_SAMPLES = 1000
MAX_SLOW_QUERIES = 30
_samples: deque = deque(maxlen=MAX_SAMPLES)
_lock = Lock()


# ---------------------------------------------------------------------------
# Внутренние структуры
# ---------------------------------------------------------------------------

@dataclass
class RequestSample:
    timestamp: str
    method: str
    route: str
    endpoint: str
    status: int
    duration_ms: float
    query_count: int
    query_time_ms: float
    path: str = ""
    is_benchmark: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SlowQuery:
    sql: str
    elapsed_ms: float
    route: str
    method: str
    timestamp: str


_slow_queries: deque = deque(maxlen=MAX_SLOW_QUERIES)


# ---------------------------------------------------------------------------
# Запись метрик из db.py (TimedCursor)
# ---------------------------------------------------------------------------

def record_query(elapsed: float, sql: Optional[str] = None) -> None:
    """Вызывается из _TimedCursor после каждого execute / executemany."""
    stats = getattr(g, "sql_perf", None)
    if stats is None:
        return

    elapsed_ms = elapsed * 1000.0
    stats["query_count"] += 1
    stats["query_time_ms"] += elapsed_ms

    # Сохраняем медленные запросы (> 5 мс) для диагностики
    if sql and elapsed_ms >= 5.0:
        try:
            route = request.url_rule.rule if request.url_rule else request.path
            method = request.method
        except RuntimeError:
            route, method = "?", "?"
        with _lock:
            _slow_queries.appendleft(
                SlowQuery(
                    sql=_normalize_sql(sql),
                    elapsed_ms=round(elapsed_ms, 3),
                    route=route,
                    method=method,
                    timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                )
            )


def _normalize_sql(sql: str, max_len: int = 280) -> str:
    text = " ".join(str(sql).split())
    if len(text) > max_len:
        return text[: max_len - 1] + "…"
    return text


# ---------------------------------------------------------------------------
# Установка хуков Flask
# ---------------------------------------------------------------------------

def install_sql_monitor(app: Flask) -> None:
    @app.before_request
    def _sql_perf_start():
        g.sql_perf = {
            "started": perf_counter(),
            "query_count": 0,
            "query_time_ms": 0.0,
            "is_benchmark": bool(getattr(g, "_sql_benchmark", False)),
        }

    @app.after_request
    def _sql_perf_finish(response):
        stats = getattr(g, "sql_perf", None)
        if stats is None:
            return response

        # Не шумим от самой страницы мониторинга (кроме явных бенчмарков)
        endpoint = request.endpoint or "unknown"
        is_benchmark = stats.get("is_benchmark") or endpoint == "admin_performance_run"

        if endpoint == "admin_performance" and not is_benchmark:
            return response

        elapsed_ms = (perf_counter() - stats["started"]) * 1000.0
        route = request.url_rule.rule if request.url_rule else request.path

        sample = RequestSample(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            method=request.method,
            route=route,
            endpoint=endpoint,
            status=response.status_code,
            duration_ms=round(elapsed_ms, 2),
            query_count=int(stats["query_count"]),
            query_time_ms=round(stats["query_time_ms"], 2),
            path=request.path,
            is_benchmark=bool(is_benchmark),
        )

        with _lock:
            _samples.appendleft(sample)
        return response


# ---------------------------------------------------------------------------
# Снимки и агрегация
# ---------------------------------------------------------------------------

def clear_samples() -> None:
    with _lock:
        _samples.clear()
        _slow_queries.clear()


def get_performance_snapshot(limit: int = 250) -> Dict[str, Any]:
    limit = max(1, min(int(limit), MAX_SAMPLES))
    with _lock:
        rows = [s.to_dict() for s in list(_samples)[:limit]]
        slow = [asdict(q) for q in list(_slow_queries)[:20]]

    counts = [r["query_count"] for r in rows]
    durations = [r["duration_ms"] for r in rows]
    query_times = [r["query_time_ms"] for r in rows]

    # Агрегация по (method, route)
    by_route: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for r in rows:
        key = (r["method"], r["route"])
        bucket = by_route.setdefault(
            key,
            {
                "method": r["method"],
                "route": r["route"],
                "hits": 0,
                "query_counts": [],
                "durations": [],
                "sql_times": [],
            },
        )
        bucket["hits"] += 1
        bucket["query_counts"].append(r["query_count"])
        bucket["durations"].append(r["duration_ms"])
        bucket["sql_times"].append(r["query_time_ms"])

    route_stats = []
    for bucket in by_route.values():
        qc = bucket["query_counts"]
        du = bucket["durations"]
        st = bucket["sql_times"]
        route_stats.append(
            {
                "method": bucket["method"],
                "route": bucket["route"],
                "hits": bucket["hits"],
                "avg_queries": round(sum(qc) / len(qc), 2),
                "max_queries": max(qc),
                "avg_duration_ms": round(sum(du) / len(du), 2),
                "max_duration_ms": round(max(du), 2),
                "avg_sql_ms": round(sum(st) / len(st), 2),
                "max_sql_ms": round(max(st), 2),
            }
        )
    route_stats.sort(key=lambda x: (-x["max_queries"], -x["avg_duration_ms"]))

    return {
        "samples": rows,
        "route_stats": route_stats,
        "slow_queries": slow,
        "total_requests": len(rows),
        "min_queries": min(counts) if counts else 0,
        "max_queries": max(counts) if counts else 0,
        "avg_queries": round(sum(counts) / len(counts), 2) if counts else 0,
        "min_duration_ms": round(min(durations), 2) if durations else 0,
        "max_duration_ms": round(max(durations), 2) if durations else 0,
        "avg_duration_ms": round(sum(durations) / len(durations), 2) if durations else 0,
        "max_sql_time_ms": round(max(query_times), 2) if query_times else 0,
        "avg_sql_time_ms": round(sum(query_times) / len(query_times), 2) if query_times else 0,
    }


# ---------------------------------------------------------------------------
# Бенчмарк по кнопке
# ---------------------------------------------------------------------------

# Ключевые маршруты для быстрой проверки (можно расширять)
DEFAULT_BENCHMARK_TARGETS: List[Dict[str, str]] = [
    {"method": "GET", "path": "/", "label": "Главная"},
    {"method": "GET", "path": "/rooms", "label": "Каталог номеров"},
    {"method": "GET", "path": "/admin/dashboard", "label": "Админ: дашборд"},
    {"method": "GET", "path": "/admin/rooms", "label": "Админ: номера"},
    {"method": "GET", "path": "/admin/bookings", "label": "Админ: бронирования"},
    {"method": "GET", "path": "/admin/clients", "label": "Админ: клиенты"},
    {"method": "GET", "path": "/admin/performance", "label": "Админ: производительность"},
]


def run_benchmark(app: Flask, targets: Optional[List[Dict[str, str]]] = None) -> List[Dict[str, Any]]:
    """
    Выполняет набор внутренних HTTP-запросов через test_client
    и возвращает результаты с точным маршрутом, методом и числом SQL.
    Сохраняет cookie/сессию текущего админа, чтобы админ-маршруты работали.
    """
    targets = targets or DEFAULT_BENCHMARK_TARGETS
    results: List[Dict[str, Any]] = []

    # Копируем сессию текущего пользователя в test_client
    with app.test_client() as client:
        with client.session_transaction() as sess:
            for key in ("user_id", "user_role", "user_name", "_csrf_token"):
                if key in session:
                    sess[key] = session[key]

        for item in targets:
            method = (item.get("method") or "GET").upper()
            path = item.get("path") or "/"
            label = item.get("label") or path

            started = perf_counter()
            try:
                if method == "GET":
                    resp = client.get(path, follow_redirects=False)
                elif method == "POST":
                    resp = client.post(path, data=item.get("data") or {}, follow_redirects=False)
                else:
                    resp = client.open(path, method=method, follow_redirects=False)
                status = resp.status_code
            except Exception as exc:  # noqa: BLE001
                status = 0
                results.append(
                    {
                        "label": label,
                        "method": method,
                        "path": path,
                        "route": path,
                        "status": status,
                        "duration_ms": round((perf_counter() - started) * 1000, 2),
                        "query_count": 0,
                        "query_time_ms": 0.0,
                        "error": str(exc),
                    }
                )
                continue

            # Последний sample, добавленный after_request, должен соответствовать этому запросу
            with _lock:
                match = None
                for s in _samples:
                    if s.path == path and s.method == method and abs(
                        (perf_counter() - started) * 1000 - s.duration_ms
                    ) < 5000:
                        match = s
                        break
                if match is None and _samples:
                    # берём самый свежий
                    match = _samples[0]

            results.append(
                {
                    "label": label,
                    "method": method,
                    "path": path,
                    "route": match.route if match else path,
                    "status": status,
                    "duration_ms": match.duration_ms if match else round((perf_counter() - started) * 1000, 2),
                    "query_count": match.query_count if match else 0,
                    "query_time_ms": match.query_time_ms if match else 0.0,
                    "error": None,
                }
            )

    return results
