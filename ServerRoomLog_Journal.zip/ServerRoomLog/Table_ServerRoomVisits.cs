// ============================================================
// Добавить этот класс в Program.cs (рядом с другими Table_*)
// ============================================================

internal static class Table_serverRoomVisits
{
    public static string main = "ServerRoomVisits";
    public static string id = "ID";
    public static string userFio = "UserFio";           // Кто зашёл
    public static string login = "Login";               // Логин для связи
    public static string entryDateTime = "EntryDateTime"; // Вход
    public static string exitDateTime = "ExitDateTime";   // Выход (null если ещё внутри)
    public static string reason = "Reason";             // Зачем (цель)
    public static string actions = "Actions";           // Что делал
    public static string note = "Note";                 // Примечание
    public static string status = "Status";             // "В серверной" / "Вышел"
}
