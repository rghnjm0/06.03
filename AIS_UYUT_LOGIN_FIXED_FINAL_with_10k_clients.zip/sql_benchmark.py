"""
Модуль проверки скорости выполнения SQL-запросов в БД отеля «Уют».

Использование:
    python sql_benchmark.py                  # полный прогон типовых запросов
    python sql_benchmark.py --runs 20        # больше повторов
    python sql_benchmark.py --query "SELECT COUNT(*) FROM Клиенты"
    python sql_benchmark.py --file queries.sql

Можно импортировать в код:

    from sql_benchmark import measure_query, run_benchmark_suite

    result = measure_query("SELECT * FROM Номера WHERE Статус = ?", ("Свободен",), runs=10)
    print(result["avg_ms"], "мс")
"""

from __future__ import annotations

import argparse
import statistics
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence, Union

# Подключаем БД проекта
try:
    from db import get_db, DB_NAME
except ImportError:
    import os
    import sqlite3

    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    DB_NAME = os.path.join(BASE_DIR, "hotel_management.db")

    def get_db():
        conn = sqlite3.connect(DB_NAME)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn


# ---------------------------------------------------------------------------
# Типовые запросы для этой БД (проверяют индексы и нагрузку после 10k клиентов)
# ---------------------------------------------------------------------------
DEFAULT_QUERIES: list[tuple[str, str, tuple]] = [
    (
        "COUNT клиентов",
        "SELECT COUNT(*) FROM Клиенты",
        (),
    ),
    (
        "Поиск клиента по телефону (индекс)",
        "SELECT * FROM Клиенты WHERE Телефон = ? LIMIT 1",
        ("+7(911)111-11-11",),
    ),
    (
        "Поиск клиентов по фамилии (LIKE)",
        "SELECT Код, ID_Клиента, Фамилия, Имя FROM Клиенты WHERE Фамилия LIKE ? LIMIT 50",
        ("Иванов%",),
    ),
    (
        "Все свободные номера",
        "SELECT * FROM Номера WHERE Статус = ?",
        ("Свободен",),
    ),
    (
        "Бронирования по датам (индекс)",
        """
        SELECT ID_Бронирования, ID_Клиента, ID_Номера, Дата_заезда, Дата_выезда, Статус
        FROM Бронирования
        WHERE Дата_заезда >= ? AND Дата_выезда <= ?
        """,
        ("2026-01-01", "2026-12-31"),
    ),
    (
        "Пересечение броней номера",
        """
        SELECT ID_Бронирования
        FROM Бронирования
        WHERE ID_Номера = ?
          AND Статус IN ('Подтверждено', 'Заселен')
          AND NOT (Дата_выезда <= ? OR Дата_заезда >= ?)
        """,
        ("RM001", "2026-04-10", "2026-04-15"),
    ),
    (
        "JOIN: брони + клиент + номер",
        """
        SELECT b.ID_Бронирования, c.Фамилия, c.Имя, n.Номер_Комнаты, b.Дата_заезда, b.Статус
        FROM Бронирования b
        JOIN Клиенты c ON c.ID_Клиента = b.ID_Клиента
        JOIN Номера n ON n.ID_Номера = b.ID_Номера
        ORDER BY b.Дата_заезда DESC
        LIMIT 100
        """,
        (),
    ),
    (
        "Счета по бронированию (индекс)",
        "SELECT * FROM Счета WHERE ID_Бронирования = ?",
        ("BR001",),
    ),
    (
        "Последние 50 записей журнала",
        "SELECT * FROM Журнал_действий ORDER BY ID DESC LIMIT 50",
        (),
    ),
    (
        "Агрегация: количество клиентов по городам (подстрока адреса)",
        """
        SELECT
            CASE
                WHEN Адрес LIKE 'Москва%' THEN 'Москва'
                WHEN Адрес LIKE 'Санкт-Петербург%' THEN 'Санкт-Петербург'
                WHEN Адрес LIKE 'Казань%' THEN 'Казань'
                ELSE 'Другие'
            END AS Город,
            COUNT(*) AS Колво
        FROM Клиенты
        GROUP BY Город
        ORDER BY Колво DESC
        """,
        (),
    ),
]


@dataclass
class QueryResult:
    name: str
    sql: str
    params: tuple
    runs: int
    times_ms: list[float] = field(default_factory=list)
    row_counts: list[int] = field(default_factory=list)
    error: Optional[str] = None

    @property
    def avg_ms(self) -> float:
        return statistics.mean(self.times_ms) if self.times_ms else 0.0

    @property
    def min_ms(self) -> float:
        return min(self.times_ms) if self.times_ms else 0.0

    @property
    def max_ms(self) -> float:
        return max(self.times_ms) if self.times_ms else 0.0

    @property
    def median_ms(self) -> float:
        return statistics.median(self.times_ms) if self.times_ms else 0.0

    @property
    def stdev_ms(self) -> float:
        if len(self.times_ms) < 2:
            return 0.0
        return statistics.stdev(self.times_ms)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "sql": self.sql.strip(),
            "params": self.params,
            "runs": self.runs,
            "avg_ms": round(self.avg_ms, 4),
            "min_ms": round(self.min_ms, 4),
            "max_ms": round(self.max_ms, 4),
            "median_ms": round(self.median_ms, 4),
            "stdev_ms": round(self.stdev_ms, 4),
            "rows": self.row_counts[-1] if self.row_counts else 0,
            "error": self.error,
        }


def measure_query(
    sql: str,
    params: Sequence[Any] = (),
    runs: int = 5,
    name: str = "",
    warmup: int = 1,
    fetch: bool = True,
) -> QueryResult:
    """
    Измеряет время выполнения одного SQL-запроса.

    :param sql: SQL-текст
    :param params: параметры запроса
    :param runs: сколько раз выполнить (для усреднения)
    :param name: человекочитаемое имя
    :param warmup: сколько прогонов «разогрева» (не учитываются)
    :param fetch: читать ли результат (True = fetchall)
    :return: QueryResult
    """
    result = QueryResult(
        name=name or sql.strip().split("\n")[0][:60],
        sql=sql,
        params=tuple(params),
        runs=runs,
    )

    conn = get_db()
    try:
        # Разогрев (кеш страниц SQLite и т.п.)
        for _ in range(max(0, warmup)):
            cur = conn.execute(sql, params)
            if fetch:
                cur.fetchall()

        for _ in range(runs):
            t0 = time.perf_counter()
            cur = conn.execute(sql, params)
            rows = cur.fetchall() if fetch else []
            t1 = time.perf_counter()
            result.times_ms.append((t1 - t0) * 1000.0)
            result.row_counts.append(len(rows) if fetch else -1)
    except Exception as exc:
        result.error = str(exc)
    finally:
        conn.close()

    return result


def run_benchmark_suite(
    queries: Optional[Iterable[tuple[str, str, tuple]]] = None,
    runs: int = 5,
    warmup: int = 1,
) -> list[QueryResult]:
    """Запускает набор типовых запросов и возвращает результаты."""
    suite = list(queries) if queries is not None else DEFAULT_QUERIES
    results: list[QueryResult] = []
    for name, sql, params in suite:
        results.append(measure_query(sql, params, runs=runs, name=name, warmup=warmup))
    return results


def format_report(results: list[QueryResult], title: str = "SQL Benchmark — отель «Уют»") -> str:
    """Красивый текстовый отчёт."""
    lines = [
        "=" * 72,
        f"  {title}",
        f"  БД: {DB_NAME}",
        "=" * 72,
        f"{'Запрос':<42} {'avg':>8} {'min':>8} {'max':>8} {'rows':>7}",
        f"{'':-<42} {'':->8} {'':->8} {'':->8} {'':->7}".replace(" ", "-"),
    ]

    for r in results:
        if r.error:
            lines.append(f"{r.name[:41]:<42}  ERROR: {r.error}")
        else:
            lines.append(
                f"{r.name[:41]:<42} {r.avg_ms:7.3f}ms {r.min_ms:7.3f}ms "
                f"{r.max_ms:7.3f}ms {r.row_counts[-1] if r.row_counts else 0:7d}"
            )

    ok = [r for r in results if not r.error]
    if ok:
        total_avg = sum(r.avg_ms for r in ok)
        slowest = max(ok, key=lambda x: x.avg_ms)
        fastest = min(ok, key=lambda x: x.avg_ms)
        lines += [
            "-" * 72,
            f"Всего запросов: {len(results)}  |  Успешно: {len(ok)}  |  Сумма avg: {total_avg:.2f} мс",
            f"Самый быстрый:  {fastest.name} ({fastest.avg_ms:.3f} мс)",
            f"Самый медленный: {slowest.name} ({slowest.avg_ms:.3f} мс)",
            "=" * 72,
        ]
    else:
        lines.append("Нет успешных измерений.")

    return "\n".join(lines)


def print_detailed(result: QueryResult) -> None:
    """Подробный вывод одного результата."""
    print(f"\n── {result.name}")
    print(f"SQL: {result.sql.strip()[:200]}{'…' if len(result.sql.strip()) > 200 else ''}")
    if result.params:
        print(f"Params: {result.params}")
    if result.error:
        print(f"ERROR: {result.error}")
        return
    print(
        f"runs={result.runs}  avg={result.avg_ms:.4f} ms  "
        f"min={result.min_ms:.4f}  max={result.max_ms:.4f}  "
        f"median={result.median_ms:.4f}  σ={result.stdev_ms:.4f}"
    )
    if result.row_counts:
        print(f"rows (last): {result.row_counts[-1]}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Проверка скорости SQL-запросов в hotel_management.db",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--runs", "-n", type=int, default=5, help="Число повторов каждого запроса (default: 5)")
    p.add_argument("--warmup", "-w", type=int, default=1, help="Прогревочные прогоны (default: 1)")
    p.add_argument("--query", "-q", type=str, help="Один произвольный SQL-запрос")
    p.add_argument("--params", type=str, nargs="*", default=[], help="Параметры для --query")
    p.add_argument("--file", "-f", type=str, help="Файл с SQL (запросы разделяются ';')")
    p.add_argument("--detail", "-d", action="store_true", help="Подробный вывод по каждому запросу")
    p.add_argument("--json", action="store_true", help="Вывод в JSON")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _parse_args(argv)

    if args.query:
        results = [
            measure_query(
                args.query,
                tuple(args.params),
                runs=args.runs,
                name="Пользовательский запрос",
                warmup=args.warmup,
            )
        ]
    elif args.file:
        text = Path(args.file).read_text(encoding="utf-8")
        statements = [s.strip() for s in text.split(";") if s.strip()]
        results = []
        for i, sql in enumerate(statements, 1):
            results.append(
                measure_query(sql, (), runs=args.runs, name=f"Запрос #{i}", warmup=args.warmup)
            )
    else:
        results = run_benchmark_suite(runs=args.runs, warmup=args.warmup)

    if args.json:
        import json
        print(json.dumps([r.to_dict() for r in results], ensure_ascii=False, indent=2))
    else:
        print(format_report(results))
        if args.detail:
            for r in results:
                print_detailed(r)

    return 0 if all(not r.error for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
