from flask import render_template, request, redirect, url_for, flash, session
from datetime import datetime, timedelta
from urllib.parse import urlparse
from uuid import uuid4
from werkzeug.security import generate_password_hash, check_password_hash

from db import get_db
from utils import sync_room_statuses
from auth import login_required, client_required


def _safe_next(default_endpoint="index"):
    """Разрешает только внутренние URL, чтобы не получить open redirect."""
    target = request.args.get("next") or request.form.get("next")
    if target:
        parsed = urlparse(target)
        if not parsed.scheme and not parsed.netloc and target.startswith("/"):
            return target
    return url_for(default_endpoint)


def _password_matches(stored, entered):
    if not stored:
        return False
    # Поддержка старой БД с обычными паролями + новых хешей.
    if stored.startswith(("scrypt:", "pbkdf2:", "argon2:")):
        try:
            return check_password_hash(stored, entered)
        except ValueError:
            return False
    return stored == entered


def register_auth_routes(app):

    # =========================
    # ГОСТЬ: регистрация
    # =========================
    @app.route("/register", methods=["GET", "POST"])
    @app.route("/guest/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            conn = None
            try:
                last_name = request.form.get("last_name", "").strip()
                first_name = request.form.get("first_name", "").strip()
                middle_name = request.form.get("middle_name", "").strip()
                phone = request.form.get("phone", "").strip()
                birth_date = request.form.get("birth_date", "").strip()
                address = request.form.get("address", "").strip()
                password = request.form.get("password", "")
                confirm_password = request.form.get("confirm_password", "")

                if not all([last_name, first_name, phone, password]):
                    flash("Заполните обязательные поля.", "danger")
                    return render_template("register.html")

                if password != confirm_password:
                    flash("Пароли не совпадают.", "danger")
                    return render_template("register.html")

                if len(password) < 6:
                    flash("Пароль должен содержать минимум 6 символов.", "danger")
                    return render_template("register.html")

                conn = get_db()
                cur = conn.cursor()

                cur.execute("SELECT ID_Клиента FROM Клиенты WHERE Телефон = ?", (phone,))
                if cur.fetchone():
                    flash("Гость с таким телефоном уже зарегистрирован.", "danger")
                    return render_template("register.html")

                cur.execute("SELECT 1 FROM Пользователи WHERE Логин = ?", (phone,))
                if cur.fetchone():
                    flash("Этот телефон уже используется для входа.", "danger")
                    return render_template("register.html")

                cur.execute("SELECT COUNT(*) FROM Клиенты")
                client_id = f"CL{cur.fetchone()[0] + 1:03d}"

                # Если ID уже существует (например, после ручного удаления), подбираем следующий.
                while cur.execute("SELECT 1 FROM Клиенты WHERE ID_Клиента = ?", (client_id,)).fetchone():
                    client_id = f"CL{int(client_id[2:]) + 1:03d}"

                cur.execute("""
                    INSERT INTO Клиенты
                    (ID_Клиента, Фамилия, Имя, Отчество, Телефон, Дата_рождения, Адрес)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (client_id, last_name, first_name, middle_name or None,
                      phone, birth_date or None, address or None))

                cur.execute("""
                    INSERT INTO Пользователи (ID_Клиента, Логин, Пароль, Роль)
                    VALUES (?, ?, ?, 'client')
                """, (client_id, phone, generate_password_hash(password)))

                conn.commit()
                flash("Регистрация завершена. Теперь войдите как гость.", "success")
                return redirect(url_for("login"))

            except Exception as e:
                if conn:
                    conn.rollback()
                flash(f"Не удалось зарегистрировать гостя: {e}", "danger")
                return render_template("register.html")
            finally:
                if conn:
                    conn.close()

        return render_template("register.html")

    # =========================
    # ГОСТЬ: вход
    # =========================
    @app.route("/login", methods=["GET", "POST"])
    @app.route("/guest/login", methods=["GET", "POST"])
    def login():
        next_url = request.args.get("next", "")

        if request.method == "POST":
            login_value = request.form.get("login", "").strip()
            password = request.form.get("password", "")
            next_url = request.form.get("next", next_url)

            conn = get_db()
            cur = conn.cursor()
            cur.execute("""
                SELECT u.ID_Клиента, u.Роль, u.Пароль,
                       c.Фамилия, c.Имя, c.Отчество
                FROM Пользователи u
                LEFT JOIN Клиенты c ON u.ID_Клиента = c.ID_Клиента
                WHERE u.Логин = ? AND u.Роль = 'client'
            """, (login_value,))
            user = cur.fetchone()

            if user and _password_matches(user["Пароль"], password):
                # Обновляем старый пароль в БД до хеша после успешного входа.
                if not str(user["Пароль"]).startswith(("scrypt:", "pbkdf2:", "argon2:")):
                    cur.execute(
                        "UPDATE Пользователи SET Пароль = ? WHERE ID_Клиента = ?",
                        (generate_password_hash(password), user["ID_Клиента"])
                    )
                    conn.commit()

                conn.close()
                session.clear()
                session["user_id"] = user["ID_Клиента"]
                session["client_id"] = user["ID_Клиента"]
                session["user_role"] = "client"
                session["user_name"] = f"{user['Фамилия'] or ''} {user['Имя'] or ''}".strip()
                session["client_name"] = session["user_name"]
                flash(f"Добро пожаловать, {user['Имя'] or 'гость'}!", "success")
                return _safe_redirect(next_url, "index")

            conn.close()
            flash("Неверный телефон или пароль.", "danger")

        return render_template("login.html", next=next_url)

    # =========================
    # АДМИН: отдельный вход
    # =========================
    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        """Надёжный вход администратора по логину или телефону."""
        if request.method == "POST":
            login_value = request.form.get("login", "").strip()
            password = request.form.get("password", "")

            conn = get_db()
            try:
                cur = conn.cursor()

                # Сначала ищем сотрудника напрямую. Это исключает зависимость
                # от связки таблиц Пользователи/Сотрудники.
                cur.execute("""
                    SELECT ID_Сотрудника, Логин, Телефон, Пароль, Фамилия, Имя, Отчество
                    FROM Сотрудники
                    WHERE Логин = ? OR Телефон = ?
                    LIMIT 1
                """, (login_value, login_value))
                staff = cur.fetchone()

                if staff and _password_matches(staff["Пароль"], password):
                    session.clear()
                    session["user_role"] = "admin"
                    session["admin_id"] = staff["ID_Сотрудника"]
                    session["admin_name"] = f"{staff['Имя'] or ''} {staff['Фамилия'] or ''}".strip() or "Администратор"
                    flash("Вы вошли в панель администратора.", "success")
                    return redirect(url_for("admin_dashboard"))

                # Резервный вариант для записей администратора в Пользователи.
                cur.execute("""
                    SELECT ID_Клиента, Логин, Пароль
                    FROM Пользователи
                    WHERE Роль = 'admin' AND Логин = ?
                    LIMIT 1
                """, (login_value,))
                user = cur.fetchone()
                if user and _password_matches(user["Пароль"], password):
                    session.clear()
                    session["user_role"] = "admin"
                    session["admin_id"] = user["ID_Клиента"]
                    session["admin_name"] = "Администратор"
                    flash("Вы вошли в панель администратора.", "success")
                    return redirect(url_for("admin_dashboard"))

                flash("Неверный логин или пароль администратора.", "danger")
            finally:
                conn.close()

        return render_template("admin/login.html")

    @app.route("/logout")
    @app.route("/guest/logout")
    def logout():
        session.clear()
        flash("Вы вышли из аккаунта.", "info")
        return redirect(url_for("index"))

    # =========================
    # ЛИЧНЫЙ КАБИНЕТ ГОСТЯ
    # =========================
    @app.route("/profile")
    @client_required
    def profile():
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM Клиенты WHERE ID_Клиента = ?", (session["client_id"],))
            client = cur.fetchone()
            if not client:
                flash("Профиль гостя не найден.", "danger")
                return redirect(url_for("index"))

            cur.execute("""
                SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,
                       CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) AS days_count
                FROM Бронирования b
                JOIN Номера n ON b.ID_Номера = n.ID_Номера
                WHERE b.ID_Клиента = ?
                ORDER BY b.Дата_заезда DESC
            """, (session["client_id"],))
            bookings = []
            for row in cur.fetchall():
                item = dict(row)
                days = max(int(item.get("days_count") or 1), 1)
                item["total_price"] = days * float(item.get("Цена_за_сутки") or 0)
                bookings.append(item)

            return render_template("profile.html", client=client, bookings=bookings)
        finally:
            conn.close()

    # =========================
    # БРОНИРОВАНИЕ
    # =========================
    @app.route("/booking/<string:room_id>", methods=["GET", "POST"])
    @client_required
    def create_booking(room_id):
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM Номера WHERE ID_Номера = ?", (room_id,))
            room = cur.fetchone()
            if not room:
                flash("Номер не найден.", "danger")
                return redirect(url_for("search_rooms"))

            today = datetime.now().date()
            default_in = today.strftime("%Y-%m-%d")
            default_out = (today + timedelta(days=1)).strftime("%Y-%m-%d")

            if request.method == "GET":
                check_in = request.args.get("check_in") or default_in
                check_out = request.args.get("check_out") or default_out
                guests = request.args.get("guests", 1, type=int)
                guests = max(1, min(guests, int(room["Вместимость"])))
                return render_template("booking.html", room=room,
                                       check_in=check_in, check_out=check_out,
                                       guests=guests, today=today)

            check_in = request.form.get("check_in", "")
            check_out = request.form.get("check_out", "")
            try:
                guests = int(request.form.get("guests", "1"))
                check_in_date = datetime.strptime(check_in, "%Y-%m-%d").date()
                check_out_date = datetime.strptime(check_out, "%Y-%m-%d").date()
            except (ValueError, TypeError):
                flash("Проверьте даты и количество гостей.", "danger")
                return render_template("booking.html", room=room,
                                       check_in=check_in, check_out=check_out,
                                       guests=1, today=today)

            if check_in_date < today:
                flash("Дата заезда не может быть в прошлом.", "danger")
                return render_template("booking.html", room=room,
                                       check_in=check_in, check_out=check_out,
                                       guests=guests, today=today)

            if check_out_date <= check_in_date:
                flash("Дата выезда должна быть позже даты заезда.", "danger")
                return render_template("booking.html", room=room,
                                       check_in=check_in, check_out=check_out,
                                       guests=guests, today=today)

            if guests < 1 or guests > int(room["Вместимость"]):
                flash(f"Максимальная вместимость номера: {room['Вместимость']} гостей.", "danger")
                return render_template("booking.html", room=room,
                                       check_in=check_in, check_out=check_out,
                                       guests=guests, today=today)

            # Важный момент: статус номера не используется как единственный
            # признак доступности. Номер может иметь бронь в декабре и быть
            # свободен в октябре. Проверяем именно пересечение дат.
            cur.execute("""
                SELECT ID_Бронирования
                FROM Бронирования
                WHERE ID_Номера = ?
                  AND Статус IN ('Подтверждено', 'Заселен')
                  AND NOT (Дата_выезда <= ? OR Дата_заезда >= ?)
                LIMIT 1
            """, (room_id, check_in, check_out))
            if cur.fetchone():
                flash("На выбранные даты этот номер уже забронирован. Выберите другие даты.", "danger")
                return render_template("booking.html", room=room,
                                       check_in=check_in, check_out=check_out,
                                       guests=guests, today=today)

            days = (check_out_date - check_in_date).days
            total_price = days * float(room["Цена_за_сутки"])
            prepayment = round(total_price * 0.30, 2)

            booking_id = _new_id(cur, "Бронирования", "ID_Бронирования", "BR")
            invoice_id = _new_id(cur, "Счета", "ID_Счета", "INV")

            cur.execute("""
                INSERT INTO Бронирования
                (ID_Бронирования, ID_Клиента, ID_Номера, Дата_бронирования,
                 Дата_заезда, Дата_выезда, Количество_гостей, Статус, Предоплата)
                VALUES (?, ?, ?, date('now'), ?, ?, ?, 'Подтверждено', ?)
            """, (booking_id, session["client_id"], room_id,
                  check_in, check_out, guests, prepayment))

            cur.execute("""
                INSERT INTO Счета
                (ID_Счета, ID_Бронирования, Дата_выставления,
                 Сумма_проживание, Способ_оплаты, Оплачено)
                VALUES (?, ?, date('now'), ?, 'Ожидает оплаты', 0)
            """, (invoice_id, booking_id, total_price))

            conn.commit()

            # После успешной записи пересчитываем статус номера.
            sync_room_statuses()

            flash(f"Бронирование {booking_id} успешно создано.", "success")
            return redirect(url_for("booking_confirmation", booking_id=booking_id))

        except Exception as e:
            conn.rollback()
            flash(f"Не удалось создать бронирование: {e}", "danger")
            return redirect(url_for("room_detail", room_id=room_id))
        finally:
            conn.close()

    # =========================
    # ПОДТВЕРЖДЕНИЕ
    # =========================
    @app.route("/booking/confirmation/<string:booking_id>")
    @client_required
    def booking_confirmation(booking_id):
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,
                       CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) AS days_count,
                       c.Фамилия, c.Имя, c.Отчество
                FROM Бронирования b
                JOIN Номера n ON b.ID_Номера = n.ID_Номера
                JOIN Клиенты c ON b.ID_Клиента = c.ID_Клиента
                WHERE b.ID_Бронирования = ? AND b.ID_Клиента = ?
            """, (booking_id, session["client_id"]))
            booking = cur.fetchone()

            if not booking:
                flash("Бронирование не найдено.", "danger")
                return redirect(url_for("profile"))

            item = dict(booking)
            days = max(int(item.get("days_count") or 1), 1)
            item["total_price"] = days * float(item.get("Цена_за_сутки") or 0)
            item["prepayment"] = round(item["total_price"] * 0.30, 2)
            return render_template("confirmation.html", booking=item)
        finally:
            conn.close()

    # =========================
    # ОТМЕНА
    # =========================
    @app.route("/booking/cancel/<string:booking_id>", methods=["POST", "GET"])
    @client_required
    def cancel_booking(booking_id):
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT Дата_заезда, ID_Номера
                FROM Бронирования
                WHERE ID_Бронирования = ? AND ID_Клиента = ?
            """, (booking_id, session["client_id"]))
            booking = cur.fetchone()

            if not booking:
                flash("Бронирование не найдено.", "danger")
                return redirect(url_for("profile"))

            check_in = datetime.strptime(booking["Дата_заезда"], "%Y-%m-%d").date()
            if check_in <= datetime.now().date():
                flash("Бронирование нельзя отменить в день заезда или позже.", "danger")
                return redirect(url_for("profile"))

            cur.execute("""
                UPDATE Бронирования
                SET Статус = 'Отменено'
                WHERE ID_Бронирования = ? AND ID_Клиента = ?
            """, (booking_id, session["client_id"]))
            conn.commit()
            sync_room_statuses()
            flash("Бронирование отменено.", "success")
            return redirect(url_for("profile"))
        except Exception as e:
            conn.rollback()
            flash(f"Не удалось отменить бронирование: {e}", "danger")
            return redirect(url_for("profile"))
        finally:
            conn.close()


def _new_id(cur, table, column, prefix):
    """Создаёт уникальный ID независимо от удалённых записей."""
    while True:
        value = f"{prefix}-{uuid4().hex[:8].upper()}"
        cur.execute(f"SELECT 1 FROM {table} WHERE {column} = ?", (value,))
        if not cur.fetchone():
            return value


def _safe_redirect(target, default_endpoint="index"):
    parsed = urlparse(target or "")
    if target and not parsed.scheme and not parsed.netloc and target.startswith("/"):
        return redirect(target)
    return redirect(url_for(default_endpoint))
