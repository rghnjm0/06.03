#!/usr/bin/env python3
"""
Инициализация базы данных информационной системы учёта техники в техникуме
"""

import sqlite3
from datetime import datetime, timedelta
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "uchet_tehniki.db")

def create_database():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Категории техники
    cur.execute("""
        CREATE TABLE categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE
        )
    """)

    # Кабинеты / места хранения
    cur.execute("""
        CREATE TABLE locations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            building TEXT DEFAULT 'Основной корпус'
        )
    """)

    # Материально-ответственные лица (МОЛ)
    cur.execute("""
        CREATE TABLE responsible (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            position TEXT,
            phone TEXT
        )
    """)

    # Основная таблица техники
    cur.execute("""
        CREATE TABLE equipment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inv_number TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            category_id INTEGER,
            serial_number TEXT,
            purchase_date DATE,
            cost REAL DEFAULT 0,
            location_id INTEGER,
            responsible_id INTEGER,
            status TEXT DEFAULT 'В эксплуатации' 
                CHECK(status IN ('На складе', 'В эксплуатации', 'В ремонте', 'Списано')),
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id),
            FOREIGN KEY (location_id) REFERENCES locations(id),
            FOREIGN KEY (responsible_id) REFERENCES responsible(id)
        )
    """)

    # Журнал перемещений
    cur.execute("""
        CREATE TABLE movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id INTEGER NOT NULL,
            from_location_id INTEGER,
            to_location_id INTEGER,
            from_responsible_id INTEGER,
            to_responsible_id INTEGER,
            move_date DATE NOT NULL,
            reason TEXT,
            FOREIGN KEY (equipment_id) REFERENCES equipment(id)
        )
    """)

    # Журнал ремонтов
    cur.execute("""
        CREATE TABLE repairs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id INTEGER NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE,
            description TEXT,
            cost REAL DEFAULT 0,
            status TEXT DEFAULT 'В работе' CHECK(status IN ('В работе', 'Завершён')),
            FOREIGN KEY (equipment_id) REFERENCES equipment(id)
        )
    """)

    # ===== Заполнение справочников =====
    categories = [
        "Компьютер", "Ноутбук", "Монитор", "Принтер", "МФУ",
        "Проектор", "Интерактивная доска", "Сетевое оборудование",
        "Мебель", "Прочее"
    ]
    cur.executemany("INSERT INTO categories (name) VALUES (?)", [(c,) for c in categories])

    locations = [
        ("Кабинет 101 (Информатика)", "Основной корпус"),
        ("Кабинет 102 (Программирование)", "Основной корпус"),
        ("Кабинет 201 (Лаборатория)", "Основной корпус"),
        ("Кабинет 305 (Администрация)", "Основной корпус"),
        ("Серверная", "Основной корпус"),
        ("Склад", "Хозяйственный корпус"),
        ("Актовый зал", "Основной корпус"),
    ]
    cur.executemany("INSERT INTO locations (name, building) VALUES (?, ?)", locations)

    responsible = [
        ("Иванов Пётр Сергеевич", "Зав. лабораторией", "+7-900-111-22-33"),
        ("Смирнова Анна Викторовна", "Преподаватель информатики", "+7-900-222-33-44"),
        ("Козлов Дмитрий Алексеевич", "Системный администратор", "+7-900-333-44-55"),
        ("Петрова Елена Ивановна", "Зав. хозяйством", "+7-900-444-55-66"),
        ("Сидоров Алексей Николаевич", "Директор", "+7-900-555-66-77"),
    ]
    cur.executemany("INSERT INTO responsible (full_name, position, phone) VALUES (?, ?, ?)", responsible)

    # ===== Пример техники =====
    today = datetime.now().date()
    equipment_data = [
        ("ТК-0001", "Системный блок Dell OptiPlex 7090", 1, "SN-DL-7090-001", 
         (today - timedelta(days=400)).isoformat(), 45000, 1, 1, "В эксплуатации", "Основной ПК преподавателя"),
        ("ТК-0002", "Монитор Samsung 24\"", 3, "SN-SM-24-002", 
         (today - timedelta(days=400)).isoformat(), 12000, 1, 1, "В эксплуатации", ""),
        ("ТК-0003", "Ноутбук Lenovo ThinkPad E14", 2, "SN-LN-E14-003", 
         (today - timedelta(days=200)).isoformat(), 55000, 2, 2, "В эксплуатации", "Для выездных занятий"),
        ("ТК-0004", "МФУ HP LaserJet Pro MFP", 5, "SN-HP-MFP-004", 
         (today - timedelta(days=300)).isoformat(), 28000, 3, 3, "В эксплуатации", ""),
        ("ТК-0005", "Проектор Epson EB-X06", 6, "SN-EP-X06-005", 
         (today - timedelta(days=500)).isoformat(), 32000, 7, 4, "В эксплуатации", "Актовый зал"),
        ("ТК-0006", "Интерактивная доска Smart Board", 7, "SN-SB-006", 
         (today - timedelta(days=600)).isoformat(), 85000, 1, 1, "В эксплуатации", ""),
        ("ТК-0007", "Коммутатор Cisco 24-port", 8, "SN-CS-24-007", 
         (today - timedelta(days=800)).isoformat(), 15000, 5, 3, "В эксплуатации", "Серверная"),
        ("ТК-0008", "Системный блок (старый)", 1, "SN-OLD-008", 
         (today - timedelta(days=1500)).isoformat(), 18000, 6, 4, "На складе", "Требует списания"),
        ("ТК-0009", "Принтер Canon LBP6030", 4, "SN-CN-6030-009", 
         (today - timedelta(days=100)).isoformat(), 9500, 4, 5, "В эксплуатации", ""),
        ("ТК-0010", "Ноутбук ASUS VivoBook", 2, "SN-AS-VB-010", 
         (today - timedelta(days=50)).isoformat(), 42000, 2, 2, "В ремонте", "Не включается"),
    ]
    
    cur.executemany("""
        INSERT INTO equipment 
        (inv_number, name, category_id, serial_number, purchase_date, cost, 
         location_id, responsible_id, status, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, equipment_data)

    # Пример перемещения
    cur.execute("""
        INSERT INTO movements (equipment_id, from_location_id, to_location_id, 
                               from_responsible_id, to_responsible_id, move_date, reason)
        VALUES (3, 6, 2, 4, 2, ?, 'Выдача для учебного процесса')
    """, ((today - timedelta(days=180)).isoformat(),))

    # Пример ремонта
    cur.execute("""
        INSERT INTO repairs (equipment_id, start_date, description, status)
        VALUES (10, ?, 'Не включается, диагностика блока питания', 'В работе')
    """, ((today - timedelta(days=5)).isoformat(),))

    conn.commit()
    conn.close()
    print(f"База данных успешно создана: {DB_PATH}")
    print("Добавлено: 10 единиц техники, 5 МОЛ, 7 локаций, 10 категорий.")

if __name__ == "__main__":
    create_database()
