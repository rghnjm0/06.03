#!/usr/bin/env python3
"""
Информационная система учёта техники в техникуме
Учебная практика ПМ 06
"""

import streamlit as st
import sqlite3
import pandas as pd
from datetime import datetime, date
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "uchet_tehniki.db")

st.set_page_config(
    page_title="Учёт техники — Техникум",
    page_icon="💻",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------- Работа с БД ----------
def get_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def run_query(query, params=None):
    conn = get_connection()
    if params:
        df = pd.read_sql_query(query, conn, params=params)
    else:
        df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def execute_sql(query, params=None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(query, params or ())
    conn.commit()
    last_id = cur.lastrowid
    conn.close()
    return last_id

# ---------- Справочники ----------
def get_categories():
    return run_query("SELECT id, name FROM categories ORDER BY name")

def get_locations():
    return run_query("SELECT id, name, building FROM locations ORDER BY name")

def get_responsible():
    return run_query("SELECT id, full_name, position FROM responsible ORDER BY full_name")

# ---------- Стили ----------
st.markdown("""
<style>
    .main-header {
        font-size: 1.8rem;
        font-weight: 700;
        color: #0D47A1;
        margin-bottom: 0.5rem;
    }
    .stat-card {
        background: #f0f4f8;
        padding: 1rem;
        border-radius: 8px;
        text-align: center;
        border-left: 4px solid #1565C0;
    }
    .stMetric { background: #f8fafc; padding: 0.5rem; border-radius: 6px; }
</style>
""", unsafe_allow_html=True)

# ---------- Проверка БД ----------
if not os.path.exists(DB_PATH):
    st.error("База данных не найдена. Запустите init_db.py")
    st.stop()

# ---------- Боковое меню ----------
st.sidebar.title("💻 Учёт техники")
st.sidebar.caption("Техникум · ПМ 06")

menu = st.sidebar.radio(
    "Разделы",
    [
        "📊 Главная",
        "📋 Список техники",
        "➕ Добавить технику",
        "🔄 Перемещение",
        "🔧 Ремонт",
        "📦 Списание",
        "📈 Отчёты",
        "⚙️ Справочники"
    ]
)

# =====================================================
# ГЛАВНАЯ
# =====================================================
if menu == "📊 Главная":
    st.markdown('<div class="main-header">Информационная система учёта техники</div>', unsafe_allow_html=True)
    st.write("Учебная практика · Специальность 09.02.07 · ПМ 06")

    col1, col2, col3, col4 = st.columns(4)
    
    total = run_query("SELECT COUNT(*) as cnt FROM equipment").iloc[0]['cnt']
    in_use = run_query("SELECT COUNT(*) as cnt FROM equipment WHERE status='В эксплуатации'").iloc[0]['cnt']
    in_repair = run_query("SELECT COUNT(*) as cnt FROM equipment WHERE status='В ремонте'").iloc[0]['cnt']
    on_stock = run_query("SELECT COUNT(*) as cnt FROM equipment WHERE status='На складе'").iloc[0]['cnt']
    written_off = run_query("SELECT COUNT(*) as cnt FROM equipment WHERE status='Списано'").iloc[0]['cnt']
    total_cost = run_query("SELECT COALESCE(SUM(cost),0) as s FROM equipment WHERE status != 'Списано'").iloc[0]['s']

    col1.metric("Всего единиц", total)
    col2.metric("В эксплуатации", in_use)
    col3.metric("В ремонте", in_repair)
    col4.metric("На складе", on_stock)

    st.divider()
    
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Распределение по статусам")
        status_df = run_query("""
            SELECT status as Статус, COUNT(*) as Количество 
            FROM equipment GROUP BY status ORDER BY Количество DESC
        """)
        st.dataframe(status_df, use_container_width=True, hide_index=True)
    
    with c2:
        st.subheader("По категориям")
        cat_df = run_query("""
            SELECT c.name as Категория, COUNT(e.id) as Количество
            FROM categories c
            LEFT JOIN equipment e ON e.category_id = c.id
            GROUP BY c.id ORDER BY Количество DESC
        """)
        st.dataframe(cat_df, use_container_width=True, hide_index=True)

    st.subheader("Последние добавленные")
    recent = run_query("""
        SELECT e.inv_number as "Инв. №", e.name as Наименование, 
               c.name as Категория, e.status as Статус, e.purchase_date as "Дата покупки"
        FROM equipment e
        LEFT JOIN categories c ON c.id = e.category_id
        ORDER BY e.id DESC LIMIT 5
    """)
    st.dataframe(recent, use_container_width=True, hide_index=True)

# =====================================================
# СПИСОК ТЕХНИКИ
# =====================================================
elif menu == "📋 Список техники":
    st.markdown('<div class="main-header">Список техники</div>', unsafe_allow_html=True)

    # Фильтры
    f1, f2, f3, f4 = st.columns(4)
    with f1:
        statuses = ["Все"] + list(run_query("SELECT DISTINCT status FROM equipment")['status'])
        status_filter = st.selectbox("Статус", statuses)
    with f2:
        cats = get_categories()
        cat_options = ["Все"] + list(cats['name'])
        cat_filter = st.selectbox("Категория", cat_options)
    with f3:
        locs = get_locations()
        loc_options = ["Все"] + list(locs['name'])
        loc_filter = st.selectbox("Местоположение", loc_options)
    with f4:
        search = st.text_input("Поиск (инв. № / название)")

    query = """
        SELECT e.id, e.inv_number as "Инв. №", e.name as Наименование,
               c.name as Категория, e.serial_number as "Серийный №",
               l.name as Местоположение, r.full_name as МОЛ,
               e.status as Статус, e.cost as "Стоимость, ₽", e.purchase_date as "Дата покупки"
        FROM equipment e
        LEFT JOIN categories c ON c.id = e.category_id
        LEFT JOIN locations l ON l.id = e.location_id
        LEFT JOIN responsible r ON r.id = e.responsible_id
        WHERE 1=1
    """
    params = []
    if status_filter != "Все":
        query += " AND e.status = ?"
        params.append(status_filter)
    if cat_filter != "Все":
        query += " AND c.name = ?"
        params.append(cat_filter)
    if loc_filter != "Все":
        query += " AND l.name = ?"
        params.append(loc_filter)
    if search:
        query += " AND (e.inv_number LIKE ? OR e.name LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    
    query += " ORDER BY e.inv_number"
    df = run_query(query, params if params else None)
    
    st.write(f"Найдено: **{len(df)}** единиц")
    st.dataframe(df.drop(columns=['id'], errors='ignore'), use_container_width=True, hide_index=True)

    # Редактирование / просмотр
    if not df.empty:
        st.subheader("Карточка единицы техники")
        selected_inv = st.selectbox("Выберите инвентарный номер", df["Инв. №"].tolist())
        row = df[df["Инв. №"] == selected_inv].iloc[0]
        
        c1, c2, c3 = st.columns(3)
        c1.write(f"**Наименование:** {row['Наименование']}")
        c1.write(f"**Категория:** {row['Категория']}")
        c1.write(f"**Серийный №:** {row['Серийный №'] or '—'}")
        c2.write(f"**Местоположение:** {row['Местоположение']}")
        c2.write(f"**МОЛ:** {row['МОЛ']}")
        c2.write(f"**Статус:** {row['Статус']}")
        c3.write(f"**Стоимость:** {row['Стоимость, ₽']:,.0f} ₽" if pd.notna(row['Стоимость, ₽']) else "**Стоимость:** —")
        c3.write(f"**Дата покупки:** {row['Дата покупки'] or '—'}")

# =====================================================
# ДОБАВИТЬ ТЕХНИКУ
# =====================================================
elif menu == "➕ Добавить технику":
    st.markdown('<div class="main-header">Добавление новой единицы техники</div>', unsafe_allow_html=True)

    with st.form("add_equipment", clear_on_submit=True):
        c1, c2 = st.columns(2)
        with c1:
            inv_number = st.text_input("Инвентарный номер *", placeholder="ТК-0011")
            name = st.text_input("Наименование *", placeholder="Системный блок ...")
            cats = get_categories()
            category = st.selectbox("Категория *", cats['name'].tolist())
            serial = st.text_input("Серийный номер")
            purchase_date = st.date_input("Дата покупки", value=date.today())
        with c2:
            cost = st.number_input("Стоимость, ₽", min_value=0.0, step=1000.0)
            locs = get_locations()
            location = st.selectbox("Местоположение *", locs['name'].tolist())
            resps = get_responsible()
            responsible = st.selectbox("МОЛ *", resps['full_name'].tolist())
            status = st.selectbox("Статус", ["На складе", "В эксплуатации", "В ремонте"])
            notes = st.text_area("Примечание")

        submitted = st.form_submit_button("💾 Сохранить", type="primary")
        if submitted:
            if not inv_number or not name:
                st.error("Заполните обязательные поля (отмечены *)")
            else:
                cat_id = int(cats[cats['name'] == category]['id'].iloc[0])
                loc_id = int(locs[locs['name'] == location]['id'].iloc[0])
                resp_id = int(resps[resps['full_name'] == responsible]['id'].iloc[0])
                try:
                    execute_sql("""
                        INSERT INTO equipment 
                        (inv_number, name, category_id, serial_number, purchase_date, cost,
                         location_id, responsible_id, status, notes)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (inv_number, name, cat_id, serial, purchase_date.isoformat(),
                          cost, loc_id, resp_id, status, notes))
                    st.success(f"Техника **{inv_number}** успешно добавлена!")
                except sqlite3.IntegrityError:
                    st.error("Инвентарный номер уже существует!")

# =====================================================
# ПЕРЕМЕЩЕНИЕ
# =====================================================
elif menu == "🔄 Перемещение":
    st.markdown('<div class="main-header">Перемещение техники</div>', unsafe_allow_html=True)

    eq_df = run_query("""
        SELECT id, inv_number || ' — ' || name as label, location_id, responsible_id
        FROM equipment WHERE status IN ('В эксплуатации', 'На складе')
        ORDER BY inv_number
    """)
    
    if eq_df.empty:
        st.warning("Нет техники для перемещения")
    else:
        with st.form("move_form"):
            selected = st.selectbox("Единица техники", eq_df['label'].tolist())
            eq_id = int(eq_df[eq_df['label'] == selected]['id'].iloc[0])
            
            locs = get_locations()
            resps = get_responsible()
            
            new_loc = st.selectbox("Новое местоположение", locs['name'].tolist())
            new_resp = st.selectbox("Новый МОЛ", resps['full_name'].tolist())
            move_date = st.date_input("Дата перемещения", value=date.today())
            reason = st.text_input("Основание / причина")

            if st.form_submit_button("Выполнить перемещение", type="primary"):
                old = eq_df[eq_df['id'] == eq_id].iloc[0]
                new_loc_id = int(locs[locs['name'] == new_loc]['id'].iloc[0])
                new_resp_id = int(resps[resps['full_name'] == new_resp]['id'].iloc[0])
                
                execute_sql("""
                    INSERT INTO movements 
                    (equipment_id, from_location_id, to_location_id, 
                     from_responsible_id, to_responsible_id, move_date, reason)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (eq_id, int(old['location_id']) if old['location_id'] else None,
                      new_loc_id, int(old['responsible_id']) if old['responsible_id'] else None,
                      new_resp_id, move_date.isoformat(), reason))
                
                execute_sql("""
                    UPDATE equipment SET location_id=?, responsible_id=?, status='В эксплуатации'
                    WHERE id=?
                """, (new_loc_id, new_resp_id, eq_id))
                
                st.success("Перемещение выполнено успешно!")

        st.subheader("История перемещений")
        hist = run_query("""
            SELECT e.inv_number as "Инв. №", e.name as Техника,
                   fl.name as Откуда, tl.name as Куда,
                   m.move_date as Дата, m.reason as Основание
            FROM movements m
            JOIN equipment e ON e.id = m.equipment_id
            LEFT JOIN locations fl ON fl.id = m.from_location_id
            LEFT JOIN locations tl ON tl.id = m.to_location_id
            ORDER BY m.move_date DESC LIMIT 20
        """)
        st.dataframe(hist, use_container_width=True, hide_index=True)

# =====================================================
# РЕМОНТ
# =====================================================
elif menu == "🔧 Ремонт":
    st.markdown('<div class="main-header">Учёт ремонтов</div>', unsafe_allow_html=True)

    tab1, tab2 = st.tabs(["Оформить ремонт", "Журнал ремонтов"])

    with tab1:
        eq_df = run_query("""
            SELECT id, inv_number || ' — ' || name as label
            FROM equipment WHERE status IN ('В эксплуатации', 'На складе')
            ORDER BY inv_number
        """)
        with st.form("repair_form"):
            selected = st.selectbox("Техника", eq_df['label'].tolist() if not eq_df.empty else ["Нет"])
            start_date = st.date_input("Дата начала", value=date.today())
            description = st.text_area("Описание неисправности")
            if st.form_submit_button("Отправить в ремонт", type="primary") and not eq_df.empty:
                eq_id = int(eq_df[eq_df['label'] == selected]['id'].iloc[0])
                execute_sql("""
                    INSERT INTO repairs (equipment_id, start_date, description, status)
                    VALUES (?, ?, ?, 'В работе')
                """, (eq_id, start_date.isoformat(), description))
                execute_sql("UPDATE equipment SET status='В ремонте' WHERE id=?", (eq_id,))
                st.success("Техника отправлена в ремонт")

    with tab2:
        repairs = run_query("""
            SELECT r.id, e.inv_number as "Инв. №", e.name as Техника,
                   r.start_date as "Начало", r.end_date as "Окончание",
                   r.description as Описание, r.cost as "Стоимость", r.status as Статус
            FROM repairs r
            JOIN equipment e ON e.id = r.equipment_id
            ORDER BY r.start_date DESC
        """)
        st.dataframe(repairs.drop(columns=['id'], errors='ignore'), use_container_width=True, hide_index=True)

        # Завершение ремонта
        open_repairs = repairs[repairs['Статус'] == 'В работе']
        if not open_repairs.empty:
            st.subheader("Завершить ремонт")
            sel = st.selectbox("Выберите ремонт", 
                               open_repairs.apply(lambda x: f"{x['Инв. №']} — {x['Описание'][:40]}", axis=1).tolist())
            idx = open_repairs.index[open_repairs.apply(lambda x: f"{x['Инв. №']} — {x['Описание'][:40]}" == sel, axis=1)][0]
            repair_id = int(open_repairs.loc[idx, 'id'])
            eq_inv = open_repairs.loc[idx, 'Инв. №']
            cost = st.number_input("Стоимость ремонта, ₽", min_value=0.0)
            if st.button("Завершить ремонт"):
                execute_sql("""
                    UPDATE repairs SET end_date=?, cost=?, status='Завершён' WHERE id=?
                """, (date.today().isoformat(), cost, repair_id))
                execute_sql("""
                    UPDATE equipment SET status='В эксплуатации' 
                    WHERE inv_number=?
                """, (eq_inv,))
                st.success("Ремонт завершён, техника возвращена в эксплуатацию")
                st.rerun()

# =====================================================
# СПИСАНИЕ
# =====================================================
elif menu == "📦 Списание":
    st.markdown('<div class="main-header">Списание техники</div>', unsafe_allow_html=True)

    eq_df = run_query("""
        SELECT id, inv_number || ' — ' || name || ' (' || status || ')' as label
        FROM equipment WHERE status != 'Списано'
        ORDER BY inv_number
    """)
    
    with st.form("writeoff_form"):
        selected = st.selectbox("Единица техники", eq_df['label'].tolist() if not eq_df.empty else ["Нет"])
        reason = st.text_area("Основание для списания *", placeholder="Износ, поломка, моральное устаревание...")
        writeoff_date = st.date_input("Дата списания", value=date.today())
        
        if st.form_submit_button("Списать", type="primary") and not eq_df.empty:
            if not reason.strip():
                st.error("Укажите основание")
            else:
                eq_id = int(eq_df[eq_df['label'] == selected]['id'].iloc[0])
                execute_sql("""
                    UPDATE equipment SET status='Списано', notes=COALESCE(notes,'') || ?
                    WHERE id=?
                """, (f"\n[Списано {writeoff_date}: {reason}]", eq_id))
                st.success("Техника списана")

    st.subheader("Списанная техника")
    written = run_query("""
        SELECT inv_number as "Инв. №", name as Наименование, 
               cost as "Стоимость", notes as Примечание
        FROM equipment WHERE status='Списано'
        ORDER BY inv_number
    """)
    st.dataframe(written, use_container_width=True, hide_index=True)

# =====================================================
# ОТЧЁТЫ
# =====================================================
elif menu == "📈 Отчёты":
    st.markdown('<div class="main-header">Отчёты</div>', unsafe_allow_html=True)

    report_type = st.selectbox("Тип отчёта", [
        "Ведомость по МОЛ",
        "Ведомость по кабинетам",
        "Сводка по стоимости",
        "Техника в ремонте",
        "Полный реестр"
    ])

    if report_type == "Ведомость по МОЛ":
        df = run_query("""
            SELECT r.full_name as МОЛ, r.position as Должность,
                   COUNT(e.id) as "Кол-во единиц",
                   COALESCE(SUM(e.cost),0) as "Сумма, ₽"
            FROM responsible r
            LEFT JOIN equipment e ON e.responsible_id = r.id AND e.status != 'Списано'
            GROUP BY r.id
            ORDER BY "Кол-во единиц" DESC
        """)
        st.dataframe(df, use_container_width=True, hide_index=True)

    elif report_type == "Ведомость по кабинетам":
        df = run_query("""
            SELECT l.name as Кабинет, l.building as Корпус,
                   COUNT(e.id) as "Кол-во единиц",
                   COALESCE(SUM(e.cost),0) as "Сумма, ₽"
            FROM locations l
            LEFT JOIN equipment e ON e.location_id = l.id AND e.status != 'Списано'
            GROUP BY l.id
            ORDER BY "Кол-во единиц" DESC
        """)
        st.dataframe(df, use_container_width=True, hide_index=True)

    elif report_type == "Сводка по стоимости":
        df = run_query("""
            SELECT c.name as Категория,
                   COUNT(e.id) as Количество,
                   COALESCE(SUM(e.cost),0) as "Общая стоимость, ₽",
                   COALESCE(AVG(e.cost),0) as "Средняя стоимость, ₽"
            FROM categories c
            LEFT JOIN equipment e ON e.category_id = c.id AND e.status != 'Списано'
            GROUP BY c.id
            HAVING Количество > 0
            ORDER BY "Общая стоимость, ₽" DESC
        """)
        st.dataframe(df, use_container_width=True, hide_index=True)
        total = df["Общая стоимость, ₽"].sum()
        st.metric("Общая стоимость активной техники", f"{total:,.0f} ₽")

    elif report_type == "Техника в ремонте":
        df = run_query("""
            SELECT e.inv_number as "Инв. №", e.name as Наименование,
                   r.start_date as "Дата начала", r.description as Описание
            FROM equipment e
            JOIN repairs r ON r.equipment_id = e.id AND r.status='В работе'
            WHERE e.status='В ремонте'
        """)
        st.dataframe(df, use_container_width=True, hide_index=True)

    else:  # Полный реестр
        df = run_query("""
            SELECT e.inv_number as "Инв. №", e.name as Наименование,
                   c.name as Категория, l.name as Местоположение,
                   r.full_name as МОЛ, e.status as Статус,
                   e.cost as "Стоимость, ₽", e.purchase_date as "Дата покупки"
            FROM equipment e
            LEFT JOIN categories c ON c.id = e.category_id
            LEFT JOIN locations l ON l.id = e.location_id
            LEFT JOIN responsible r ON r.id = e.responsible_id
            ORDER BY e.inv_number
        """)
        st.dataframe(df, use_container_width=True, hide_index=True)
        csv = df.to_csv(index=False).encode('utf-8-sig')
        st.download_button("📥 Скачать CSV", csv, "reestr_tehniki.csv", "text/csv")

# =====================================================
# СПРАВОЧНИКИ
# =====================================================
elif menu == "⚙️ Справочники":
    st.markdown('<div class="main-header">Справочники</div>', unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["Категории", "Местоположения", "МОЛ"])

    with tab1:
        st.dataframe(get_categories().rename(columns={'id':'ID', 'name':'Название'}), 
                     use_container_width=True, hide_index=True)
        with st.form("add_cat"):
            new_cat = st.text_input("Новая категория")
            if st.form_submit_button("Добавить"):
                if new_cat:
                    try:
                        execute_sql("INSERT INTO categories (name) VALUES (?)", (new_cat,))
                        st.success("Добавлено")
                        st.rerun()
                    except:
                        st.error("Такая категория уже есть")

    with tab2:
        st.dataframe(get_locations().rename(columns={'id':'ID', 'name':'Название', 'building':'Корпус'}),
                     use_container_width=True, hide_index=True)
        with st.form("add_loc"):
            c1, c2 = st.columns(2)
            new_loc = c1.text_input("Название кабинета/места")
            building = c2.text_input("Корпус", value="Основной корпус")
            if st.form_submit_button("Добавить"):
                if new_loc:
                    try:
                        execute_sql("INSERT INTO locations (name, building) VALUES (?, ?)", (new_loc, building))
                        st.success("Добавлено")
                        st.rerun()
                    except:
                        st.error("Уже существует")

    with tab3:
        st.dataframe(get_responsible().rename(columns={'id':'ID', 'full_name':'ФИО', 'position':'Должность'}),
                     use_container_width=True, hide_index=True)
        with st.form("add_resp"):
            c1, c2, c3 = st.columns(3)
            fio = c1.text_input("ФИО")
            pos = c2.text_input("Должность")
            phone = c3.text_input("Телефон")
            if st.form_submit_button("Добавить"):
                if fio:
                    execute_sql("INSERT INTO responsible (full_name, position, phone) VALUES (?, ?, ?)",
                                (fio, pos, phone))
                    st.success("Добавлено")
                    st.rerun()

# ---------- Подвал ----------
st.sidebar.divider()
st.sidebar.caption("ИС учёта техники v1.0\nУчебная практика 2026")
