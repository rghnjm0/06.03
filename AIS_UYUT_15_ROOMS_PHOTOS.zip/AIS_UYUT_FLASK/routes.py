from flask import Blueprint, render_template, request, redirect, url_for, flash, make_response, session
from data import ROOMS, BOOKINGS, GUESTS, USERS
from utils import today, parse_iso_date
from datetime import datetime
from functools import wraps
import csv, io
from werkzeug.security import check_password_hash, generate_password_hash

main = Blueprint("main", __name__)

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Войдите в панель администратора.", "error")
            return redirect(url_for("main.admin_login"))
        return view(*args, **kwargs)
    return wrapped

def guest_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "guest":
            flash("Войдите как гость, чтобы продолжить.", "error")
            return redirect(url_for("main.guest_login"))
        return view(*args, **kwargs)
    return wrapped

@main.app_context_processor
def globals():
    return {"now": today(), "free_rooms": sum(r["status"] == "Свободен" for r in ROOMS), "occupied_rooms": sum(r["status"] == "Занят" for r in ROOMS), "cleaning_rooms": sum(r["status"] == "Уборка" for r in ROOMS), "rooms_count": len(ROOMS), "current_user": session.get("name"), "role": session.get("role")}

@main.route("/")
def index():
    # Главная страница всегда остаётся публичным сайтом отеля.
    # Личные кабинеты открываются только через отдельные ссылки.
    return redirect(url_for("main.public_site"))

@main.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        login, password = request.form.get("login", "").strip(), request.form.get("password", "")
        user = next((u for u in USERS if u["role"] == "admin" and u["login"] == login), None)
        if user and check_password_hash(user["password"], password):
            session.clear(); session.update(role="admin", name=user["name"], login=user["login"])
            return redirect(url_for("main.dashboard"))
        flash("Неверный логин или пароль.", "error")
    return render_template("admin_login.html")

@main.route("/guest/login", methods=["GET", "POST"])
def guest_login():
    if request.method == "POST":
        login, password = request.form.get("login", "").strip().lower(), request.form.get("password", "")
        user = next((u for u in USERS if u["role"] == "guest" and u["login"] == login), None)
        if user and check_password_hash(user["password"], password):
            session.clear(); session.update(role="guest", name=user["name"], login=user["login"])
            return redirect(url_for("main.guest_home"))
        flash("Неверный email или пароль.", "error")
    return render_template("guest_login.html")

@main.route("/guest/register", methods=["GET", "POST"])
def guest_register():
    if request.method == "POST":
        name, login, password = request.form.get("name", "").strip(), request.form.get("login", "").strip().lower(), request.form.get("password", "")
        if not name or not login or len(password) < 6: flash("Заполните поля. Пароль — минимум 6 символов.", "error")
        elif any(u["login"] == login for u in USERS): flash("Этот email уже зарегистрирован.", "error")
        else:
            USERS.append({"login": login, "password": generate_password_hash(password), "role": "guest", "name": name})
            GUESTS.append({"name": name, "phone": "—", "visits": 0, "last": "—", "login": login})
            session.clear(); session.update(role="guest", name=name, login=login)
            flash("Аккаунт создан.", "success"); return redirect(url_for("main.guest_home"))
    return render_template("guest_register.html")

@main.route("/logout")
def logout():
    session.clear(); return redirect(url_for("main.public_site"))

@main.route("/site")
def public_site(): return render_template("site.html", active="site", rooms=ROOMS)

@main.route("/guest")
@guest_required
def guest_home():
    my = [b for b in BOOKINGS if b.get("guest_login") == session.get("login")]
    return render_template("guest_home.html", active="guest", bookings=my, rooms=ROOMS)

@main.route("/guest/book", methods=["GET", "POST"])
@guest_required
def guest_book():
    if request.method == "POST":
        room_number, checkin, checkout = request.form.get("room", ""), request.form.get("checkin", ""), request.form.get("checkout", "")
        try: start, end = parse_iso_date(checkin), parse_iso_date(checkout)
        except ValueError: flash("Проверьте даты.", "error"); return redirect(url_for("main.guest_book"))
        room = next((r for r in ROOMS if r["number"] == room_number), None)
        if not room or room["status"] != "Свободен": flash("Номер недоступен.", "error")
        elif end <= start: flash("Дата выезда должна быть позже заезда.", "error")
        else:
            nights=(end-start).days
            BOOKINGS.append({"id":max([b["id"] for b in BOOKINGS],default=0)+1,"guest":session["name"],"guest_login":session["login"],"room":room_number,"checkin":start.strftime("%d.%m.%Y"),"checkout":end.strftime("%d.%m.%Y"),"status":"Новое","amount":nights*room["price"]})
            flash("Заявка на бронирование отправлена администратору.", "success"); return redirect(url_for("main.guest_home"))
    return render_template("guest_book.html", rooms=ROOMS)

@main.route("/admin")
@admin_required
def dashboard(): return render_template("dashboard.html", active="dashboard", bookings=BOOKINGS, rooms=ROOMS)

@main.route("/bookings", methods=["GET", "POST"])
@admin_required
def bookings_page():
    if request.method == "POST":
        guest, room_number, checkin, checkout = [request.form.get(k, "").strip() for k in ("guest","room","checkin","checkout")]
        if not all([guest, room_number, checkin, checkout]): flash("Заполните все поля.", "error"); return redirect(url_for("main.bookings_page"))
        try: start, end = parse_iso_date(checkin), parse_iso_date(checkout)
        except ValueError: flash("Проверьте даты.", "error"); return redirect(url_for("main.bookings_page"))
        room=next((r for r in ROOMS if r["number"]==room_number),None)
        if end<=start: flash("Дата выезда должна быть позже даты заезда.","error")
        elif not room or room["status"]!="Свободен": flash("Выбранный номер недоступен.","error")
        else:
            nights=(end-start).days; BOOKINGS.append({"id":max([b["id"] for b in BOOKINGS],default=0)+1,"guest":guest,"room":room_number,"checkin":start.strftime("%d.%m.%Y"),"checkout":end.strftime("%d.%m.%Y"),"status":"Новое","amount":nights*room["price"]}); flash("Бронирование создано.","success")
        return redirect(url_for("main.bookings_page"))
    q=request.args.get("q","").strip().lower(); status=request.args.get("status","").strip(); filtered=[b for b in BOOKINGS if (not q or q in b["guest"].lower() or q in b["room"]) and (not status or b["status"]==status)]
    return render_template("bookings.html", active="bookings", bookings=filtered, rooms=ROOMS, q=q, status=status)

@main.route("/bookings/<int:booking_id>/cancel")
@admin_required
def cancel_booking(booking_id):
    booking=next((b for b in BOOKINGS if b["id"]==booking_id),None)
    if booking and booking["status"] not in ("Выселен","Отменено"): booking["status"]="Отменено"; flash("Бронирование отменено.","success")
    return redirect(url_for("main.bookings_page"))

@main.route("/rooms", methods=["GET","POST"])
@admin_required
def rooms_page():
    if request.method=="POST":
        number=request.form.get("number","").strip(); category=request.form.get("category","Стандарт").strip(); beds=int(request.form.get("beds",2) or 2); price=int(request.form.get("price",4500) or 4500)
        if any(r["number"]==number for r in ROOMS): flash("Номер уже существует.","error")
        elif number: ROOMS.append({"number":number,"category":category,"beds":beds,"price":price,"status":"Свободен"}); flash("Номер добавлен.","success")
        return redirect(url_for("main.rooms_page"))
    q=request.args.get("q","").strip().lower(); status=request.args.get("status","").strip(); rooms=[r for r in ROOMS if (not q or q in r["number"] or q in r["category"].lower()) and (not status or r["status"]==status)]
    return render_template("rooms.html", active="rooms", rooms=rooms, q=q, status=status)

@main.route("/rooms/<room_number>/status/<new_status>")
@admin_required
def room_status(room_number,new_status):
    if new_status in {"Свободен","Занят","Уборка"}:
        room=next((r for r in ROOMS if r["number"]==room_number),None)
        if room: room["status"]=new_status; flash(f"Статус номера №{room_number}: {new_status}.","success")
    return redirect(url_for("main.rooms_page"))

@main.route("/guests", methods=["GET","POST"])
@admin_required
def guests_page():
    if request.method=="POST":
        name=request.form.get("name","").strip(); phone=request.form.get("phone","").strip()
        if name: GUESTS.append({"name":name,"phone":phone or "—","visits":0,"last":"—"}); flash("Гость добавлен в базу.","success")
        return redirect(url_for("main.guests_page"))
    q=request.args.get("q","").strip().lower(); guests=[g for g in GUESTS if not q or q in g["name"].lower() or q in g["phone"].lower()]
    return render_template("guests.html",active="guests",guests=guests,q=q)

@main.route("/reports")
@admin_required
def reports():
    revenue=sum(b["amount"] for b in BOOKINGS if b["status"]!="Отменено"); avg=round(sum(r["price"] for r in ROOMS)/len(ROOMS)) if ROOMS else 0
    return render_template("reports.html",active="reports",bookings=BOOKINGS,rooms=ROOMS,revenue=revenue,avg=avg)

@main.route("/reports/export")
@admin_required
def export_report():
    output=io.StringIO(); writer=csv.writer(output); writer.writerow(["ID","Гость","Номер","Заезд","Выезд","Сумма","Статус"])
    for b in BOOKINGS: writer.writerow([b["id"],b["guest"],b["room"],b["checkin"],b["checkout"],b["amount"],b["status"]])
    response=make_response("\ufeff"+output.getvalue()); response.headers["Content-Type"]="text/csv; charset=utf-8"; response.headers["Content-Disposition"]="attachment; filename=uyut_bookings.csv"; return response

@main.route("/settings")
@admin_required
def settings(): return render_template("settings.html",active="settings")

@main.route("/checkin/<int:booking_id>")
@admin_required
def checkin(booking_id):
    booking=next((b for b in BOOKINGS if b["id"]==booking_id),None)
    if booking: booking["status"]="Проживает"; [r.update(status="Занят") for r in ROOMS if r["number"]==booking["room"]]; flash("Гость успешно зарегистрирован.","success")
    return redirect(url_for("main.bookings_page"))

@main.route("/checkout/<int:booking_id>")
@admin_required
def checkout(booking_id):
    booking=next((b for b in BOOKINGS if b["id"]==booking_id),None)
    if booking: booking["status"]="Выселен"; [r.update(status="Уборка") for r in ROOMS if r["number"]==booking["room"]]; flash("Выселение оформлено.","success")
    return redirect(url_for("main.bookings_page"))
