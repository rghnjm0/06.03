from flask import Blueprint, render_template, request, redirect, url_for, flash, make_response
from data import ROOMS, BOOKINGS, GUESTS
from utils import today, parse_iso_date
from datetime import datetime
import csv, io

main = Blueprint("main", __name__)

@main.app_context_processor
def globals():
    return {
        "now": today(),
        "free_rooms": sum(r["status"] == "Свободен" for r in ROOMS),
        "occupied_rooms": sum(r["status"] == "Занят" for r in ROOMS),
        "cleaning_rooms": sum(r["status"] == "Уборка" for r in ROOMS),
        "rooms_count": len(ROOMS),
    }

@main.route("/")
def dashboard():
    return render_template("dashboard.html", active="dashboard", bookings=BOOKINGS, rooms=ROOMS)

@main.route("/site")
def public_site():
    return render_template("site.html", active="site", rooms=ROOMS)

@main.route("/bookings", methods=["GET", "POST"])
def bookings_page():
    if request.method == "POST":
        guest = request.form.get("guest", "").strip()
        room_number = request.form.get("room", "").strip()
        checkin = request.form.get("checkin", "")
        checkout = request.form.get("checkout", "")
        if not all([guest, room_number, checkin, checkout]):
            flash("Заполните все поля.", "error")
            return redirect(url_for("main.bookings_page"))
        try:
            start, end = parse_iso_date(checkin), parse_iso_date(checkout)
        except ValueError:
            flash("Проверьте даты.", "error")
            return redirect(url_for("main.bookings_page"))
        if end <= start:
            flash("Дата выезда должна быть позже даты заезда.", "error")
            return redirect(url_for("main.bookings_page"))
        room = next((r for r in ROOMS if r["number"] == room_number), None)
        if room is None or room["status"] != "Свободен":
            flash("Выбранный номер недоступен.", "error")
            return redirect(url_for("main.bookings_page"))
        nights = (end - start).days
        BOOKINGS.append({
            "id": max([b["id"] for b in BOOKINGS], default=0) + 1,
            "guest": guest, "room": room_number,
            "checkin": start.strftime("%d.%m.%Y"),
            "checkout": end.strftime("%d.%m.%Y"),
            "status": "Новое", "amount": nights * room["price"],
        })
        if not any(g["name"].lower() == guest.lower() for g in GUESTS):
            GUESTS.append({"name": guest, "phone": "—", "visits": 0, "last": "—"})
        flash("Бронирование создано.", "success")
        return redirect(url_for("main.bookings_page"))
    q = request.args.get("q", "").strip().lower()
    status = request.args.get("status", "").strip()
    filtered = [b for b in BOOKINGS if (not q or q in b["guest"].lower() or q in b["room"]) and (not status or b["status"] == status)]
    return render_template("bookings.html", active="bookings", bookings=filtered, rooms=ROOMS, q=q, status=status)

@main.route("/bookings/<int:booking_id>/cancel")
def cancel_booking(booking_id):
    booking = next((b for b in BOOKINGS if b["id"] == booking_id), None)
    if booking and booking["status"] not in ("Выселен", "Отменено"):
        booking["status"] = "Отменено"
        flash("Бронирование отменено.", "success")
    return redirect(url_for("main.bookings_page"))

@main.route("/rooms", methods=["GET", "POST"])
def rooms_page():
    if request.method == "POST":
        number = request.form.get("number", "").strip()
        category = request.form.get("category", "Стандарт").strip()
        beds = int(request.form.get("beds", 2) or 2)
        price = int(request.form.get("price", 4500) or 4500)
        if any(r["number"] == number for r in ROOMS):
            flash("Номер с таким номером уже существует.", "error")
        elif number:
            ROOMS.append({"number": number, "category": category, "beds": beds, "price": price, "status": "Свободен"})
            flash("Номер добавлен.", "success")
        return redirect(url_for("main.rooms_page"))
    q = request.args.get("q", "").strip().lower()
    status = request.args.get("status", "").strip()
    rooms = [r for r in ROOMS if (not q or q in r["number"] or q in r["category"].lower()) and (not status or r["status"] == status)]
    return render_template("rooms.html", active="rooms", rooms=rooms, q=q, status=status)

@main.route("/rooms/<room_number>/status/<new_status>")
def room_status(room_number, new_status):
    allowed = {"Свободен", "Занят", "Уборка"}
    if new_status in allowed:
        room = next((r for r in ROOMS if r["number"] == room_number), None)
        if room:
            room["status"] = new_status
            flash(f"Статус номера №{room_number}: {new_status}.", "success")
    return redirect(url_for("main.rooms_page"))

@main.route("/guests", methods=["GET", "POST"])
def guests_page():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        if name:
            GUESTS.append({"name": name, "phone": phone or "—", "visits": 0, "last": "—"})
            flash("Гость добавлен в базу.", "success")
        return redirect(url_for("main.guests_page"))
    q = request.args.get("q", "").strip().lower()
    guests = [g for g in GUESTS if not q or q in g["name"].lower() or q in g["phone"].lower()]
    return render_template("guests.html", active="guests", guests=guests, q=q)

@main.route("/reports")
def reports():
    revenue = sum(b["amount"] for b in BOOKINGS if b["status"] != "Отменено")
    avg = round(sum(r["price"] for r in ROOMS) / len(ROOMS)) if ROOMS else 0
    return render_template("reports.html", active="reports", bookings=BOOKINGS, rooms=ROOMS, revenue=revenue, avg=avg)

@main.route("/reports/export")
def export_report():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Гость", "Номер", "Заезд", "Выезд", "Сумма", "Статус"])
    for b in BOOKINGS:
        writer.writerow([b["id"], b["guest"], b["room"], b["checkin"], b["checkout"], b["amount"], b["status"]])
    response = make_response("\ufeff" + output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = "attachment; filename=uyut_bookings.csv"
    return response

@main.route("/settings")
def settings():
    return render_template("settings.html", active="settings")

@main.route("/checkin/<int:booking_id>")
def checkin(booking_id):
    booking = next((b for b in BOOKINGS if b["id"] == booking_id), None)
    if booking:
        booking["status"] = "Проживает"
        for room in ROOMS:
            if room["number"] == booking["room"]: room["status"] = "Занят"
        flash("Гость успешно зарегистрирован.", "success")
    return redirect(url_for("main.bookings_page"))

@main.route("/checkout/<int:booking_id>")
def checkout(booking_id):
    booking = next((b for b in BOOKINGS if b["id"] == booking_id), None)
    if booking:
        booking["status"] = "Выселен"
        for room in ROOMS:
            if room["number"] == booking["room"]: room["status"] = "Уборка"
        flash("Выселение оформлено. Номер передан в уборку.", "success")
    return redirect(url_for("main.bookings_page"))
