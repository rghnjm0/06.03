import os

class Config:
    # ... существующие настройки ...

    BUS_ROOT = os.environ.get(
        "BUS_ROOT",
        r"\\192.168.3.250\Veda\4 Курс\ИСП 44\06 03\Team1",
    )
    BUS_SNAPSHOT_INTERVAL = 120     # раз в 2 минуты
    BUS_REQUEST_TIMEOUT = 30        # секунд ожидания ответа
    HOTEL_NAME = "Гостиница «Уют»"