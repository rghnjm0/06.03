import json
import os
import sqlite3
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

from flask import current_app


MY_CODE = "hotel"
_thread = None
_stop = threading.Event()


def _log(msg: str) -> None:
    try:
        current_app.logger.info("[bus] %s", msg)
    except Exception:
        pass


def _atomic_write(target: Path, data: dict) -> None:
    tmp_dir = target.parent.parent.parent / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = tmp_dir / f"{target.name}.{uuid.uuid4().hex}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)


def _db_query(sql: str, params=()) -> list[dict]:
    """Заменить на свою БД. Сейчас — пример с SQLite."""
    db = current_app.config.get("DATABASE")
    if not db:
        return []
    conn = sqlite3.connect(str(db), timeout=5.0)
    conn.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Обработчики входящих
# ---------------------------------------------------------------------------
def _h_ping(req):
    return {"status": "ok", "service": MY_CODE,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}


def _h_guest_lookup(req):
    """Поиск гостя по ФИО. Заменить на свою БД."""
    name = (req.get("payload", {}).get("guest_name") or "").strip()
    if not name:
        return {"found": False, "error": "guest_name обязателен"}

    # ПРИМЕР. Замени на реальную таблицу своей БД.
    rows = _db_query(
        "SELECT room, full_name, vip FROM guests "
        "WHERE full_name LIKE ? LIMIT 1",
        (f"%{name}%",),
    )
    if not rows:
        return {"found": False, "guest_name": name}
    g = rows[0]
    return {
        "found": True,
        "guest_name": g["full_name"],
        "room": g["room"],
        "vip": bool(g.get("vip", 0)),
    }


_HANDLERS = {
    "ping": _h_ping,
    "guest_lookup": _h_guest_lookup,
}


# ---------------------------------------------------------------------------
# Обработка одного запроса
# ---------------------------------------------------------------------------
def _process_request(root: Path, req_file: Path) -> None:
    try:
        with open(req_file, "r", encoding="utf-8") as f:
            req = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        _log(f"не смог прочитать {req_file.name}: {e}")
        return

    rid = req.get("request_id") or req_file.stem
    req_type = req.get("type", "")
    sender = req.get("from", "?")
    _log(f"вход ← {sender}/{req_type} id={rid}")

    handler = _HANDLERS.get(req_type)
    try:
        if handler:
            payload = handler(req)
            status = "error" if payload.get("status") == "error" else "ok"
        else:
            payload = {"error": f"Неизвестный тип: {req_type}"}
            status = "error"
    except Exception as e:
        _log(f"ошибка {req_type}: {e}")
        payload = {"error": str(e)}
        status = "error"

    resp = {
        "request_id": rid,
        "from": MY_CODE,
        "to": sender,
        "status": status,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload,
    }
    _atomic_write(root / "responses" / sender / f"{rid}.json", resp)
    _log(f"ответ → {sender}/{status} id={rid}")

    proc = root / "processed" / MY_CODE
    proc.mkdir(parents=True, exist_ok=True)
    try:
        os.replace(req_file, proc / req_file.name)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Публикация snapshot
# ---------------------------------------------------------------------------
def _publish_snapshot(root: Path) -> None:
    # ПРИМЕР. Замени на свои таблицы.
    rooms = _db_query(
        "SELECT status, COUNT(*) AS cnt FROM rooms GROUP BY status"
    )
    counts = {r["status"]: r["cnt"] for r in rooms}

    today_checkouts = _db_query(
        "SELECT COUNT(*) AS c FROM bookings "
        "WHERE date(checkout) = date('now')"
    )
    today_guests = _db_query(
        "SELECT COUNT(*) AS c FROM bookings "
        "WHERE date(checkin) <= date('now') AND date(checkout) >= date('now')"
    )

    payload = {
        "hotel_name": current_app.config.get("HOTEL_NAME", "Гостиница"),
        "rooms_total": sum(counts.values()),
        "rooms_free": counts.get("free", 0),
        "rooms_occupied": counts.get("occupied", 0),
        "guests_today": today_guests[0]["c"] if today_guests else 0,
        "checkouts_today": today_checkouts[0]["c"] if today_checkouts else 0,
    }
    _atomic_write(root / "snapshots" / f"{MY_CODE}.json", {
        "service": MY_CODE,
        "published_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload,
    })
    _log("snapshot опубликован")


# ---------------------------------------------------------------------------
# Основной цикл
# ---------------------------------------------------------------------------
def _loop(app, root: Path) -> None:
    req_dir = root / "requests" / MY_CODE
    last_snap = 0.0
    seen: set[str] = set()

    with app.app_context():
        for d in (req_dir, root / "responses" / MY_CODE,
                  root / "snapshots", root / "processed" / MY_CODE,
                  root / "tmp"):
            d.mkdir(parents=True, exist_ok=True)
        _log(f"агент запущен. Слежу за {req_dir}")

    while not _stop.is_set():
        try:
            with app.app_context():
                if req_dir.exists():
                    for f in req_dir.iterdir():
                        if (f.is_file() and f.suffix == ".json"
                                and f.name not in seen):
                            seen.add(f.name)
                            try:
                                _process_request(root, f)
                            except Exception as e:
                                _log(f"process: {e}")

                now = time.time()
                if now - last_snap >= app.config["BUS_SNAPSHOT_INTERVAL"]:
                    try:
                        _publish_snapshot(root)
                    except Exception as e:
                        _log(f"publish: {e}")
                    last_snap = now
        except Exception as e:
            _log(f"loop: {e}")
        _stop.wait(1.0)

    _log("агент остановлен")


def start(app) -> None:
    global _thread
    root = Path(app.config["BUS_ROOT"])
    if not root.exists():
        app.logger.warning("[bus] папка шины не найдена: %s", root)
        return
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(
        target=_loop, args=(app, root),
        name="bus-hotel", daemon=True,
    )
    _thread.start()


def stop() -> None:
    _stop.set()
    if _thread:
        _thread.join(timeout=3)