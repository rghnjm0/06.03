"""Клиент «QuestEvent» (код в шине: quests): запросы из гостиницы через file-bus.

Протокол тот же, что и у ресторана:
  requests/quests/<id>.json  ->  responses/hotel/<id>.json

Поддерживаемые запросы QuestEvent: ping, quest_availability, quest_lookup, book_quest.
"""
import json
import os
import re
import time
import uuid
from datetime import datetime

from flask import current_app

from services.integrations.hotel_client import BusError, _atomic_write, _root

QUESTS_CODE = "quests"
MY_CODE = "hotel"
_RID_RE = re.compile(r"^[A-Za-z0-9._-]{1,100}$")


def new_request_id(prefix: str = "q") -> str:
    return f"{prefix}-{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}-{uuid.uuid4().hex[:6]}"


def send_request(req_type: str, payload: dict | None = None, *,
                 request_id: str | None = None,
                 timeout_sec: float | None = None) -> dict:
    """Отправить запрос в QuestEvent и дождаться ответа. Возвращает payload ответа.

    request_id — для book_quest передавайте стабильный ID: при повторе (потерян ответ,
    таймаут) QuestEvent вернёт прежний результат, а не создаст вторую бронь.
    """
    if timeout_sec is None:
        timeout_sec = current_app.config.get("BUS_REQUEST_TIMEOUT", 30)
    rid = request_id or new_request_id(req_type.split("_")[0])
    if not _RID_RE.match(rid):
        raise BusError("Недопустимый request_id")

    root = _root()
    req = {
        "request_id": rid,
        "from": MY_CODE,
        "to": QUESTS_CODE,
        "type": req_type,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload or {},
    }
    (root / "responses" / MY_CODE).mkdir(parents=True, exist_ok=True)
    resp_path = root / "responses" / MY_CODE / f"{rid}.json"
    # Ответ на повтор с тем же ID мог прийти раньше — тогда не пишем запрос заново.
    if not resp_path.exists():
        _atomic_write(root / "requests" / QUESTS_CODE / f"{rid}.json", req)

    deadline = time.monotonic() + timeout_sec
    while time.monotonic() < deadline:
        if resp_path.exists():
            try:
                with open(resp_path, "r", encoding="utf-8") as f:
                    resp = json.load(f)
            except (json.JSONDecodeError, OSError):
                time.sleep(0.3)
                continue
            proc = root / "processed" / MY_CODE
            try:
                proc.mkdir(parents=True, exist_ok=True)
                os.replace(resp_path, proc / resp_path.name)
            except OSError:
                pass
            body = resp.get("payload") or {}
            if resp.get("status") == "error":
                raise BusError(body.get("error") or body.get("message") or "ошибка QuestEvent")
            return body
        time.sleep(0.4)

    raise BusError(
        f"QuestEvent не ответил за {timeout_sec} с (id={rid}). Результат неизвестен — "
        "не создавайте новую заявку, пока не проверите; повтор с тем же ID безопасен."
    )


def ping(timeout_sec: float | None = None) -> dict:
    return send_request("ping", {}, timeout_sec=timeout_sec)


def quest_availability(date: str = "", quest_id=None) -> dict:
    payload = {}
    if date:
        payload["date"] = date
    if quest_id not in (None, ""):
        payload["quest_id"] = int(quest_id)
    return send_request("quest_availability", payload)


def quest_lookup(quest_id) -> dict:
    return send_request("quest_lookup", {"quest_id": int(quest_id)})


def book_quest(*, quest_id, date: str, time_str: str, guest_name: str, phone: str,
               players_count=None, slot_id=None, request_id: str | None = None) -> dict:
    payload = {
        "quest_id": int(quest_id),
        "date": date,
        "time": time_str,
        "guest_name": guest_name,
        "phone": phone,
    }
    if players_count not in (None, ""):
        payload["players_count"] = int(players_count)
    if slot_id not in (None, ""):
        payload["slot_id"] = int(slot_id)
    return send_request("book_quest", payload, request_id=request_id)


def get_quests_snapshot() -> dict | None:
    """Снимок QuestEvent (snapshots/quests.json): активные квесты, сеансы сегодня."""
    path = _root() / "snapshots" / f"{QUESTS_CODE}.json"
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
