# Безопасность и эксплуатация АИС «Уют»

## Перед запуском

- Не публикуйте рабочую `hotel_management.db`, `.env` и реальные персональные данные.
- В Git база исключена правилами `*.db`, `*.db-wal`, `*.db-shm`, `*.db-journal`.
- Для production задайте уникальный `UYUT_SECRET_KEY`, `UYUT_ENV=production` и используйте HTTPS.
- Делайте резервную копию БД перед миграциями и проверяйте восстановление.

## Авторизация

- Пароли хранятся в виде хэшей; открытые пароли обычным входом не принимаются.
- Единая политика пароля: 12–256 символов.
- После входа сессия обновляется и становится permanent на заданный срок.
- POST-действия защищены CSRF-токеном; выход из гостевой и админской зоны выполняется через POST.
- Админская и гостевая зоны разделены по роли.
- `reset_access.py` меняет только пароль выбранной учётной записи; перед использованием рекомендуется резервная копия.

## Бронирования

- При подтверждении бронь повторно проверяет конфликт дат внутри `BEGIN IMMEDIATE`.
- Промокод и его лимит проверяются и резервируются внутри той же транзакции.
- Итоговая сумма пересчитывается на сервере; значения из браузера не считаются доверенными.

## Файлы

- Загружаемые изображения проходят проверку Pillow и сохраняются под случайным именем после перекодирования.
- Не храните `.venv`, `__pycache__` и `.pyc` в архиве/репозитории.

## Ограничения

SQLite подходит для небольшого локального проекта. Для серьёзной многопользовательской нагрузки рекомендуется PostgreSQL. Демо-оплата не должна использоваться для реальных платежей без отдельной интеграции с провайдером и проверки webhook-подписей.

## A03 / A05 (Part 8 readiness)

- **XSS (admin delete confirm):** удаление гостя/номера использует `data-confirm` + обработчик в JS,
  без интерполяции ФИО в JS-литерал `confirm(...)`.
- **SRI:** Bootstrap 5.3.3 и Font Awesome 6.5.2 подключены с `integrity` + `crossorigin="anonymous"`.
- **CSP:** без `unsafe-inline` / `unsafe-eval`; инлайн-скрипты только с nonce.
- **Зависимости:** `requirements.txt` фиксирует точные версии Flask/Pillow/Werkzeug.
  Для полной цепочки поставки в CI рекомендуется `pip install --require-hashes` после генерации
  `pip-compile --generate-hashes` (сеть/PyPI).

## A06 / A07 (Part 8 readiness)

- **find_user_by_login:** убран shortcut «login=admin → первый admin»; поиск только по
  точному/case-insensitive логину или нормализованному телефону.
- **User enumeration:** единые сообщения при ошибке входа и блокировке без счётчика
  оставшихся попыток и без минут в тексте.
- **Инвалидация сессий:** при логине пишется `session['pwd_sig']` (префикс хэша пароля);
  `before_request` сверяет с БД; смена пароля обновляет sig текущей сессии и
  завершает остальные.
- **CSV export:** лимит 5000 строк для отчётов и списка гостей (formula-injection по-прежнему
  через `safe_csv_value`).

## До пятёрки (Part 8)

- **Модули:** доменная логика бронирования/промо — `services/booking.py`
  (`parse_stay_dates`, `create_confirmed_booking`, `resolve_promo`).
- **Rate-limit /search:** SQLite-таблица `rate_limit_hits` (общая для worker-процессов
  одного хоста). За reverse-proxy с несколькими инстансами нужен Redis/nginx limit_req.
- **Alembic:** `0001_baseline` + `0002_extended` (услуги, журнал, избранное, отзывы,
  промо, галерея, rate_limit). `ensure_*_schema()` на старте остаётся как
  идемпотентный safety-net для учебных БД.
- **Тесты:** `test_routes_smoke`, `test_admin_routes`, `test_services_booking`,
  `test_payments_routes`, security/booking/utils.
- **Health:** `GET /healthz`. Логи: stdout + RotatingFileHandler.
- **HTTPS / Redis / alerting:** зона ответственности reverse-proxy и ops; в приложении
  не дублируются.



## Старт схемы (финал)

- При старте приложения вызывается только `alembic upgrade head` (`run_alembic_upgrade` в `app.py`).
- `ensure_*_schema()` из runtime убраны; DDL — в `migrations/versions/0002_extended_schema.py`.
- Учебные данные: `python scripts/seed.py` (запрещено в production).
- CI: `.github/workflows/ci.yml` — pytest, ruff, compileall, pip-audit.
