#!/usr/bin/env python3
"""Однократное наполнение учебной БД (не вызывается при UYUT_ENV=production).

  python scripts/seed.py

Сначала: alembic upgrade head  (или запуск app.py один раз).
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from db import get_db, insert_test_data, DB_NAME  # noqa: E402
from hotel_logic import ensure_extra_rooms  # noqa: E402


def main():
    if os.environ.get("UYUT_ENV", "development").lower() == "production":
        raise SystemExit("seed.py запрещён при UYUT_ENV=production")
    if not os.path.isfile(DB_NAME):
        raise SystemExit(
            f"Нет БД: {DB_NAME}. Запустите app один раз или: alembic upgrade head"
        )
    conn = get_db()
    try:
        ensure_extra_rooms(conn)
        conn.commit()
        cur = conn.cursor()
        insert_test_data(cur)
        conn.commit()
        print("Seed завершён.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
