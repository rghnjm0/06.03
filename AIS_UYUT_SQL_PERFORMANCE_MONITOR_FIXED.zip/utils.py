"""Общие вспомогательные функции бронирования и экспорта."""
from datetime import date, datetime
import re

ACTIVE_BOOKING_STATUSES = ("Подтверждено", "Заселен")


def sync_room_statuses():
    """Синхронизирует статус номера с текущими активными проживаниями."""
    from db import get_db
    today = date.today().isoformat()
    conn = get_db()
    try:
        conn.execute("""
            UPDATE Номера
            SET Статус = CASE
                WHEN EXISTS (
                    SELECT 1 FROM Бронирования b
                    WHERE b.ID_Номера = Номера.ID_Номера
                      AND b.Статус = 'Заселен'
                      AND date(b.Дата_заезда) <= date(?)
                      AND date(b.Дата_выезда) > date(?)
                ) THEN 'Занят'
                ELSE 'Свободен'
            END
        """, (today, today))
        conn.commit()
    finally:
        conn.close()


def booking_conflicts(conn, room_id, check_in, check_out, exclude_booking_id=None):
    """Проверяет пересечение дат с другими активными бронированиями."""
    sql = """
        SELECT 1 FROM Бронирования
        WHERE ID_Номера = ?
          AND Статус IN (?, ?)
          AND date(Дата_заезда) < date(?)
          AND date(Дата_выезда) > date(?)
    """
    params = [room_id, *ACTIVE_BOOKING_STATUSES, check_out, check_in]
    if exclude_booking_id is not None:
        sql += " AND ID_Бронирования <> ?"
        params.append(exclude_booking_id)
    return conn.execute(sql + " LIMIT 1", params).fetchone() is not None


def next_id(conn, table, prefix, id_column):
    """Генерирует следующий строковый ID вида BR000001; имена таблиц — из кода приложения."""
    if not re.fullmatch(r"[A-Za-zА-Яа-яЁё_]+", table) or not re.fullmatch(r"[A-Za-zА-Яа-яЁё_]+", id_column):
        raise ValueError("Недопустимое имя таблицы или столбца")
    rows = conn.execute(f'SELECT "{id_column}" FROM "{table}"').fetchall()
    max_num = 0
    for row in rows:
        value = str(row[0] or "")
        match = re.search(r"(\d+)$", value)
        if match:
            max_num = max(max_num, int(match.group(1)))
    return f"{prefix}{max_num + 1:06d}"


def booking_total(conn, room_id, check_in, check_out):
    """Возвращает стоимость проживания и количество ночей."""
    start = datetime.strptime(str(check_in)[:10], "%Y-%m-%d").date()
    end = datetime.strptime(str(check_out)[:10], "%Y-%m-%d").date()
    nights = (end - start).days
    if nights <= 0:
        raise ValueError("Дата выезда должна быть позже даты заезда.")
    room = conn.execute(
        "SELECT Цена_за_сутки FROM Номера WHERE ID_Номера = ?", (room_id,)
    ).fetchone()
    if room is None:
        raise ValueError("Номер не найден.")
    return round(float(room[0] or 0) * nights, 2), nights


def safe_csv_value(value):
    """Защищает CSV от формул при открытии в табличных редакторах."""
    if value is None:
        return ""
    text = str(value)
    if text.startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + text
    return text
