# Legacy App (refactored)

Flask + SQLite приложение каталога товаров и заказов.

## Запуск

```bash
pip install -r requirements.txt
python seed.py
python app.py --port 5001
```

Открыть: http://127.0.0.1:5001

## API

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/` | HTML-список товаров |
| GET | `/api/items` | JSON: товары + число заказов |
| POST | `/api/orders` | Создать заказ `{"item_id": int, "qty": int}` → `{"ok": true/false}` |
| GET | `/api/report?from=&to=` | Сумма qty и разбивка по item_id за период |

## Тесты

```bash
pytest --cov=app --cov-report=term-missing
```

## Что улучшено

- Параметризованные SQL-запросы (без injection)
- Один запрос вместо N+1 в `/api/items`
- Индексы на `orders(item_id)`, `orders(created_at)`
- WAL, context manager для соединений
- Тесты с coverage
