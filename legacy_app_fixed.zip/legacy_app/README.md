# Legacy App (refactored)

Flask + SQLite. Публичный API совместим с эталоном.

## Запуск

```bash
pip install -r requirements.txt
python seed.py
python app.py --port 5001
```

БД всегда лежит рядом с `app.py` (`legacy_app/app.db`), даже если процесс
запущен из другой директории.

## API

| Метод | Путь | Ответ |
|-------|------|--------|
| GET | `/` | HTML |
| GET | `/api/items` | `[{id, name, price, qty, orders}, …]` |
| POST | `/api/orders` | `{"item_id", "qty"}` → 201 `{"ok": true}` |
| GET | `/api/report?from=&to=` | `{"total", "by_item"}` |

## Тесты

```bash
pytest --cov=app --cov-report=term-missing
```

## Улучшения

- Абсолютный путь к `app.db` (seed и сервер всегда видят одну БД)
- Нет N+1: один `LEFT JOIN` + `GROUP BY`
- Параметризованный SQL
- Индексы на `orders(item_id)`, `orders(created_at)`
- WAL, busy_timeout
- `created_at` у новых заказов (попадают в report)
- Секрет не захардкожен (случайный / из env)
