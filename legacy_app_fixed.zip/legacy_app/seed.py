import sqlite3
import random
import datetime
import os

DB = os.environ.get("DB_PATH", "app.db")

conn = sqlite3.connect(DB)
cur = conn.cursor()
cur.executescript("""
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS items;
CREATE TABLE items (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    qty INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER NOT NULL,
    qty INTEGER NOT NULL,
    created_at TEXT,
    FOREIGN KEY (item_id) REFERENCES items(id)
);
CREATE INDEX IF NOT EXISTS idx_orders_item_id ON orders(item_id);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
""")

items = [
    ("Товар %d" % i, round(random.uniform(10, 1000), 2), random.randint(0, 500))
    for i in range(1, 501)
]
cur.executemany("INSERT INTO items (name, price, qty) VALUES (?, ?, ?)", items)

start = datetime.date(2024, 1, 1)
orders = []
for _ in range(5000):
    d = start + datetime.timedelta(days=random.randint(0, 700))
    orders.append((random.randint(1, 500), random.randint(1, 10), d.isoformat()))
cur.executemany(
    "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)", orders
)

conn.commit()
conn.close()
print("seeded: 500 items, 5000 orders")
