import os
import sqlite3
from contextlib import contextmanager
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")
DB = os.environ.get("DB_PATH", "app.db")


@contextmanager
def get_db():
    conn = sqlite3.connect(DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def ensure_indexes():
    with get_db() as conn:
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_orders_item_id ON orders(item_id)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)"
        )


@app.route("/")
def index():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, name, price, qty FROM items ORDER BY id"
        ).fetchall()
        items = [dict(r) for r in rows]
    return render_template("index.html", items=items)


@app.route("/api/items")
def api_items():
    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT i.id, i.name, i.price, i.qty,
                   COUNT(o.id) AS orders
            FROM items i
            LEFT JOIN orders o ON o.item_id = i.id
            GROUP BY i.id
            ORDER BY i.id
            """
        ).fetchall()
        result = [dict(r) for r in rows]
    return jsonify(result)


@app.route("/api/orders", methods=["POST"])
def create_order():
    # Контракт как в оригинале: любая ошибка -> 500 + {"ok": false}
    try:
        data = request.get_json()
        item_id = int(data["item_id"])
        qty = int(data["qty"])
        with get_db() as conn:
            row = conn.execute(
                "SELECT id FROM items WHERE id = ?", (item_id,)
            ).fetchone()
            if not row:
                raise ValueError("item not found")
            # created_at как в seed (ISO date), чтобы report работал
            conn.execute(
                "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, date('now'))",
                (item_id, qty),
            )
        return jsonify({"ok": True}), 201
    except Exception:
        return jsonify({"ok": False}), 500


@app.route("/api/report")
def report():
    frm = request.args.get("from", "2000-01-01")
    to = request.args.get("to", "2100-01-01")
    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT item_id, qty
            FROM orders
            WHERE created_at BETWEEN ? AND ?
            """,
            (frm, to),
        ).fetchall()
    total = 0
    by_item = {}
    for o in rows:
        total += o["qty"]
        key = o["item_id"]
        by_item[key] = by_item.get(key, 0) + o["qty"]
    return jsonify({"total": total, "by_item": by_item})


if __name__ == "__main__":
    import sys
    ensure_indexes()
    port = 5001
    if "--port" in sys.argv:
        idx = sys.argv.index("--port")
        if idx + 1 < len(sys.argv):
            port = int(sys.argv[idx + 1])
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="127.0.0.1", port=port, debug=debug, threaded=True)
