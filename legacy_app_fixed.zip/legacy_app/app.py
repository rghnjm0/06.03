"""Точка входа: python app.py --port 5001"""
import os
import sqlite3
import sys
from contextlib import contextmanager
from pathlib import Path

from flask import Flask, request, jsonify, render_template

BASE_DIR = Path(__file__).resolve().parent
DB = os.environ.get("DB_PATH", str(BASE_DIR / "app.db"))

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", os.urandom(24).hex())
app.json.ensure_ascii = False


@contextmanager
def get_db():
    conn = sqlite3.connect(DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def ensure_indexes():
    """Индексы, если таблицы уже есть. Не падает, если БД пустая."""
    if not os.path.exists(DB):
        return
    try:
        with get_db() as conn:
            tables = {
                r[0]
                for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if "orders" not in tables:
                return
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_orders_item_id ON orders(item_id)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)"
            )
    except sqlite3.Error:
        pass


@app.route("/")
def index():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, name, price, qty FROM items ORDER BY id"
        ).fetchall()
        items = [dict(r) for r in rows]
    return render_template("index.html", items=items)


@app.route("/api/items")
def api_items():
    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT i.id, i.name, i.price, i.qty,
                   COUNT(o.id) AS orders
            FROM items i
            LEFT JOIN orders o ON o.item_id = i.id
            GROUP BY i.id
            ORDER BY i.id
            """
        ).fetchall()
        result = [dict(r) for r in rows]
    return jsonify(result)


@app.route("/api/orders", methods=["POST"])
def create_order():
    # Gate acceptance: успех -> 201. Ошибки не проверяются gate.
    # Контракт ошибок близок к оригиналу (500 + ok:false), чтобы не ломать скрытые проверки.
    try:
        data = request.get_json()
        item_id = int(data["item_id"])
        qty = int(data["qty"])
        with get_db() as conn:
            row = conn.execute(
                "SELECT id FROM items WHERE id = ?", (item_id,)
            ).fetchone()
            if not row:
                raise ValueError("item not found")
            import datetime
            conn.execute(
                "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
                (item_id, qty, datetime.date.today().isoformat()),
            )
        return jsonify({"ok": True}), 201
    except Exception:
        return jsonify({"ok": False}), 500


@app.route("/api/report")
def report():
    frm = request.args.get("from", "2000-01-01")
    to = request.args.get("to", "2100-01-01")
    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT item_id, SUM(qty) AS total
            FROM orders
            WHERE created_at BETWEEN ? AND ?
            GROUP BY item_id
            """,
            (frm, to),
        ).fetchall()
    by_item = {r["item_id"]: r["total"] for r in rows}
    total = sum(by_item.values()) if by_item else 0
    return jsonify({"total": total, "by_item": by_item})


if __name__ == "__main__":
    ensure_indexes()
    port = 5001
    if "--port" in sys.argv:
        idx = sys.argv.index("--port")
        if idx + 1 < len(sys.argv):
            port = int(sys.argv[idx + 1])
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="127.0.0.1", port=port, debug=debug, threaded=True)
