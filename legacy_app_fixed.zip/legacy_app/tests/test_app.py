import os
import sqlite3
import tempfile
import pytest

# DB path must be set before importing app
_fd, _db_path = tempfile.mkstemp(suffix=".db")
os.close(_fd)
os.environ["DB_PATH"] = _db_path

from app import app, ensure_indexes  # noqa: E402


def _seed(path):
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    cur.executescript("""
    DROP TABLE IF EXISTS orders;
    DROP TABLE IF EXISTS items;
    CREATE TABLE items (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id INTEGER NOT NULL,
        qty INTEGER NOT NULL,
        created_at TEXT,
        FOREIGN KEY (item_id) REFERENCES items(id)
    );
    """)
    cur.executemany(
        "INSERT INTO items (name, price, qty) VALUES (?, ?, ?)",
        [("Товар 1", 10.5, 100), ("Товар 2", 20.0, 50), ("Товар 3", 5.0, 0)],
    )
    cur.executemany(
        "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
        [
            (1, 2, "2024-03-01"),
            (1, 1, "2024-03-15"),
            (2, 5, "2024-04-01"),
            (2, 3, "2025-01-10"),
        ],
    )
    conn.commit()
    conn.close()


@pytest.fixture
def client():
    _seed(_db_path)
    ensure_indexes()
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def test_index(client):
    r = client.get("/")
    assert r.status_code == 200
    assert b"Tovar" in r.data or "Товар".encode("utf-8") in r.data


def test_api_items_shape(client):
    r = client.get("/api/items")
    assert r.status_code == 200
    data = r.get_json()
    assert isinstance(data, list)
    assert len(data) == 3
    item = data[0]
    assert set(item.keys()) >= {"id", "name", "price", "qty", "orders"}
    assert item["id"] == 1
    assert item["orders"] == 2  # two orders for item 1


def test_api_items_no_n_plus_one_fields(client):
    r = client.get("/api/items")
    data = r.get_json()
    by_id = {x["id"]: x for x in data}
    assert by_id[1]["orders"] == 2
    assert by_id[2]["orders"] == 2
    assert by_id[3]["orders"] == 0


def test_create_order_ok(client):
    r = client.post("/api/orders", json={"item_id": 1, "qty": 4})
    assert r.status_code == 201
    assert r.get_json() == {"ok": True}
    # orders count increased
    items = client.get("/api/items").get_json()
    assert {x["id"]: x["orders"] for x in items}[1] == 3


def test_create_order_missing_fields(client):
    r = client.post("/api/orders", json={})
    assert r.status_code == 500
    assert r.get_json() == {"ok": False}


def test_create_order_bad_json(client):
    r = client.post(
        "/api/orders", data="not-json", content_type="application/json"
    )
    assert r.status_code == 500
    assert r.get_json() == {"ok": False}


def test_create_order_unknown_item(client):
    r = client.post("/api/orders", json={"item_id": 9999, "qty": 1})
    assert r.status_code == 500
    assert r.get_json() == {"ok": False}


def test_report_basic(client):
    r = client.get("/api/report?from=2024-01-01&to=2024-12-31")
    assert r.status_code == 200
    data = r.get_json()
    assert "total" in data and "by_item" in data
    assert data["total"] == 2 + 1 + 5  # orders in 2024
    # keys may be str after jsonify
    by = {str(k): v for k, v in data["by_item"].items()}
    assert by["1"] == 3
    assert by["2"] == 5


def test_report_defaults(client):
    r = client.get("/api/report")
    assert r.status_code == 200
    data = r.get_json()
    assert data["total"] == 2 + 1 + 5 + 3


def test_sql_injection_safe(client):
    # parameterized query must not break / dump
    r = client.get("/api/report?from=2024-01-01' OR '1'='1&to=2024-12-31")
    assert r.status_code == 200
    # should not return all rows as if OR bypassed (total would be 11)
    data = r.get_json()
    assert isinstance(data["total"], int)
