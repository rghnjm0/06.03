import os
import sqlite3
import tempfile
from pathlib import Path

import pytest

_fd, _db_path = tempfile.mkstemp(suffix=".db")
os.close(_fd)
os.environ["DB_PATH"] = _db_path

from app import app, ensure_indexes, DB  # noqa: E402


def _seed(path):
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    cur.executescript("""
    DROP TABLE IF EXISTS orders;
    DROP TABLE IF EXISTS items;
    CREATE TABLE items (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id INTEGER NOT NULL,
        qty INTEGER NOT NULL,
        created_at TEXT,
        FOREIGN KEY (item_id) REFERENCES items(id)
    );
    """)
    cur.executemany(
        "INSERT INTO items (name, price, qty) VALUES (?, ?, ?)",
        [("Товар 1", 10.5, 100), ("Товар 2", 20.0, 50), ("Товар 3", 5.0, 0)],
    )
    cur.executemany(
        "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
        [
            (1, 2, "2024-03-01"),
            (1, 1, "2024-03-15"),
            (2, 5, "2024-04-01"),
            (2, 3, "2025-01-10"),
        ],
    )
    conn.commit()
    conn.close()


@pytest.fixture
def client():
    _seed(_db_path)
    ensure_indexes()
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def test_db_path_is_absolute():
    assert Path(DB).is_absolute() or DB == _db_path


def test_index(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "Товар".encode("utf-8") in r.data


def test_api_items_shape(client):
    r = client.get("/api/items")
    assert r.status_code == 200
    data = r.get_json()
    assert isinstance(data, list)
    assert len(data) == 3
    assert {"id", "name", "price", "qty"}.issubset(data[0].keys())
    assert data[0]["orders"] == 2


def test_create_order_ok(client):
    r = client.post("/api/orders", json={"item_id": 1, "qty": 2})
    assert r.status_code == 201
    assert r.get_json() == {"ok": True}


def test_create_order_errors(client):
    assert client.post("/api/orders", json={}).status_code == 500
    assert client.post("/api/orders", json={"item_id": 99999, "qty": 1}).status_code == 500


def test_report_schema(client):
    r = client.get("/api/report?from=2024-01-01&to=2025-12-31")
    assert r.status_code == 200
    data = r.get_json()
    assert "total" in data and "by_item" in data
    assert data["total"] == sum(data["by_item"].values())


def test_report_new_order_counted(client):
    before = client.get("/api/report").get_json()["total"]
    client.post("/api/orders", json={"item_id": 1, "qty": 7})
    after = client.get("/api/report").get_json()["total"]
    assert after == before + 7


def test_sql_injection_safe(client):
    r = client.get("/api/report?from=2024-01-01';DROP TABLE orders;--&to=2024-12-31")
    assert r.status_code == 200
    assert client.get("/api/report").get_json()["total"] > 0
