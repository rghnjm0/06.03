# АИС «Уют» — Flask MVP

## Быстрый запуск Windows

Самый простой вариант — дважды нажать `start.bat`.

Скрипт сам:
1. создаст виртуальное окружение `.venv`;
2. установит зависимости из `requirements.txt`;
3. запустит приложение.

После запуска открыть:

http://127.0.0.1:5000

## Запуск вручную

В терминале, находясь в корне проекта (папка, где лежат `main.py` и `requirements.txt`):

```text
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

### Важно

**Не запускай `app/main.py` напрямую.**

Именно это вызывает ошибку:
`ImportError: attempted relative import with no known parent package`.

Запускай корневой `main.py`:

```text
python main.py
```

## Демо-доступы

- admin / admin123
- manager / manager123
- receptionist / reception123
- accountant / account123

## Структура

```text
uyut_flask/
├── main.py              # запускать этот файл
├── start.bat            # автоматический запуск Windows
├── requirements.txt
├── .env.example
└── app/
    ├── __init__.py
    ├── models.py
    ├── auth.py
    ├── main.py
    ├── bookings.py
    ├── rooms.py
    ├── guests.py
    ├── reports.py
    ├── seed.py
    ├── utils.py
    ├── templates/
    └── static/
```
