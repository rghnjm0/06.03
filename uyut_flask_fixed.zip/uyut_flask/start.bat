@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Создаю виртуальное окружение...
    py -m venv .venv
    if errorlevel 1 (
        echo Не удалось создать виртуальное окружение. Установи Python 3.11+.
        pause
        exit /b 1
    )
)

echo Устанавливаю зависимости...
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
    echo Ошибка установки зависимостей.
    pause
    exit /b 1
)

echo.
echo Запускаю АИС "Уют"...
echo Открой http://127.0.0.1:5000
.venv\Scripts\python.exe main.py
pause
