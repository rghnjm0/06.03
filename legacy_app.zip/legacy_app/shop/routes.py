"""HTTP-маршруты (blueprint). Публичный API не менять."""
from flask import Blueprint, jsonify, render_template, request

from . import services
from .db import get_db

bp = Blueprint("shop", __name__)


@bp.route("/")
def index():
    """HTML-список товаров."""
    items = services.list_items_plain(get_db())
    return render_template("index.html", items=items)


@bp.route("/api/items")
def api_items():
    """JSON-список товаров с числом заказов."""
    return jsonify(services.list_items(get_db()))


@bp.route("/api/orders", methods=["POST"])
def create_order():
    """Создание заказа."""
    data = request.get_json(silent=True)
    try:
        services.create_order(get_db(), data)
    except services.ValidationError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except services.NotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    return jsonify({"ok": True}), 201


@bp.route("/api/report")
def report():
    """Отчёт за период: from / to в формате YYYY-MM-DD."""
    date_from = request.args.get("from", services.DEFAULT_FROM)
    date_to = request.args.get("to", services.DEFAULT_TO)
    return jsonify(services.build_report(get_db(), date_from, date_to))
