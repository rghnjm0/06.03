"""Настройка логирования в app.log и stderr."""
import logging
from logging.handlers import RotatingFileHandler

FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"


def setup_logging(app) -> None:
    """Подключает файловый и консольный обработчики к логгеру приложения."""
    level = getattr(logging, str(app.config["LOG_LEVEL"]).upper(), logging.INFO)
    app.logger.setLevel(level)
    app.logger.handlers.clear()
    formatter = logging.Formatter(FORMAT)

    file_handler = RotatingFileHandler(
        app.config["LOG_FILE"], maxBytes=5_000_000, backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    app.logger.addHandler(file_handler)

    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    app.logger.addHandler(stream)
    app.logger.propagate = False
