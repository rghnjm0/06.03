"""Фабрика приложения."""
import time

from flask import Flask, g, jsonify, request
from werkzeug.exceptions import HTTPException

from config import Config

from .db import close_db
from .logging_conf import setup_logging
from .routes import bp


def create_app(overrides: dict | None = None) -> Flask:
    """Создаёт и настраивает Flask-приложение."""
    app = Flask(__name__, template_folder="../templates")
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)
    app.json.ensure_ascii = False
    app.json.sort_keys = False

    setup_logging(app)
    app.teardown_appcontext(close_db)
    app.register_blueprint(bp)
    _register_hooks(app)
    _register_error_handlers(app)
    return app


def _register_hooks(app: Flask) -> None:
    @app.before_request
    def _start_timer():
        g.started = time.perf_counter()

    @app.after_request
    def _log_request(response):
        elapsed = (time.perf_counter() - g.get("started", time.perf_counter())) * 1000
        app.logger.info(
            "%s %s -> %s (%.1f ms)",
            request.method, request.path, response.status_code, elapsed,
        )
        return response


def _register_error_handlers(app: Flask) -> None:
    @app.errorhandler(HTTPException)
    def _http_error(exc):
        app.logger.warning("HTTP %s: %s", exc.code, request.path)
        return jsonify({"ok": False, "error": exc.description}), exc.code

    @app.errorhandler(Exception)
    def _unhandled(exc):
        app.logger.exception("Необработанная ошибка: %s", exc)
        return jsonify({"ok": False}), 500
