"""Бизнес-логика: товары, заказы, отчёт. Только параметризованный SQL."""
import datetime
import sqlite3
from typing import Any

DEFAULT_FROM = "2000-01-01"
DEFAULT_TO = "2100-01-01"


class ValidationError(ValueError):
    """Некорректные входные данные (ответ 400)."""


class NotFoundError(LookupError):
    """Сущность не найдена (ответ 404)."""


def list_items(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    """Все товары с числом заказов одним запросом (без N+1)."""
    rows = conn.execute(
        """
        SELECT i.id, i.name, i.price, i.qty, COUNT(o.id) AS orders
        FROM items AS i
        LEFT JOIN orders AS o ON o.item_id = i.id
        GROUP BY i.id
        ORDER BY i.id
        """
    ).fetchall()
    return [dict(r) for r in rows]


def list_items_plain(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    """Товары для HTML-страницы."""
    rows = conn.execute("SELECT id, name, price, qty FROM items ORDER BY id")
    return [dict(r) for r in rows.fetchall()]


def _as_int(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ValidationError(f"{field} должно быть целым числом")
    try:
        return int(value)
    except ValueError as exc:
        raise ValidationError(f"{field} должно быть целым числом") from exc


def validate_order(data: Any) -> tuple[int, int]:
    """Проверяет тело запроса и возвращает (item_id, qty)."""
    if not isinstance(data, dict):
        raise ValidationError("ожидается JSON-объект")
    if "item_id" not in data or "qty" not in data:
        raise ValidationError("нужны поля item_id и qty")
    item_id = _as_int(data["item_id"], "item_id")
    qty = _as_int(data["qty"], "qty")
    if qty <= 0:
        raise ValidationError("qty должно быть больше нуля")
    return item_id, qty


def create_order(conn: sqlite3.Connection, data: Any) -> int:
    """Создаёт заказ и возвращает его id."""
    item_id, qty = validate_order(data)
    exists = conn.execute(
        "SELECT 1 FROM items WHERE id = ?", (item_id,)
    ).fetchone()
    if exists is None:
        raise NotFoundError(f"товар {item_id} не найден")
    cur = conn.execute(
        "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
        (item_id, qty, datetime.date.today().isoformat()),
    )
    conn.commit()
    return cur.lastrowid


def build_report(
    conn: sqlite3.Connection, date_from: str, date_to: str
) -> dict[str, Any]:
    """Сумма и разбивка по товарам за период одним агрегирующим запросом."""
    rows = conn.execute(
        """
        SELECT item_id, SUM(qty) AS total
        FROM orders
        WHERE created_at BETWEEN ? AND ?
        GROUP BY item_id
        """,
        (date_from, date_to),
    ).fetchall()
    by_item = {r["item_id"]: r["total"] for r in rows}
    return {"total": sum(by_item.values()), "by_item": by_item}
