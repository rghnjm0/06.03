"""Работа с SQLite: соединение на запрос, WAL, индексы."""
import sqlite3

from flask import current_app, g

SCHEMA_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_orders_item_id ON orders(item_id)",
    "CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)",
)


def connect(path: str) -> sqlite3.Connection:
    """Открывает соединение с WAL и разумным таймаутом блокировки."""
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")
    return conn


def ensure_indexes(conn: sqlite3.Connection) -> None:
    """Создаёт индексы, если таблицы уже существуют."""
    tables = {
        r[0]
        for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
    }
    if "orders" not in tables:
        return
    for stmt in SCHEMA_INDEXES:
        conn.execute(stmt)
    conn.commit()


def get_db() -> sqlite3.Connection:
    """Соединение, привязанное к текущему запросу."""
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
        ensure_indexes(g.db)
    return g.db


def close_db(_exc=None) -> None:
    """Закрывает соединение в конце запроса."""
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()
