"""Точка входа: python app.py --port 5010."""
import argparse

from config import Config
from shop import create_app

app = create_app()


def parse_args(argv=None) -> argparse.Namespace:
    """Разбор аргументов командной строки."""
    parser = argparse.ArgumentParser(description="Сервис товаров и заказов")
    parser.add_argument("--port", type=int, default=Config.DEFAULT_PORT)
    parser.add_argument("--host", default=Config.HOST)
    return parser.parse_args(argv)


def main(argv=None) -> None:
    """Запуск dev-сервера (многопоточный, без debug/reloader)."""
    args = parse_args(argv)
    app.logger.info("Запуск на %s:%s", args.host, args.port)
    app.run(host=args.host, port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
