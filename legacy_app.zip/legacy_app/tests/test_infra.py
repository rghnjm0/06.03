import sqlite3
import sys

import pytest

import app as app_module
import seed as seed_module
from shop import create_app, services
from shop.db import connect, ensure_indexes


def test_indexes_created_by_seed(tmp_path):
    db = str(tmp_path / "s.db")
    assert seed_module.seed(db, 5, 10) == (5, 10)
    names = {r[1] for r in sqlite3.connect(db).execute("PRAGMA index_list(orders)")}
    assert {"idx_orders_item_id", "idx_orders_created_at"} <= names


def test_ensure_indexes_on_legacy_db(tmp_path):
    db = str(tmp_path / "legacy.db")
    raw = sqlite3.connect(db)
    raw.executescript(
        "CREATE TABLE items (id INTEGER PRIMARY KEY, name TEXT, price REAL,"
        " qty INTEGER);"
        "CREATE TABLE orders (id INTEGER PRIMARY KEY, item_id INTEGER, qty INTEGER,"
        " created_at TEXT);"
    )
    raw.close()
    conn = connect(db)
    ensure_indexes(conn)
    names = {r[1] for r in conn.execute("PRAGMA index_list(orders)")}
    assert "idx_orders_created_at" in names
    assert conn.execute("PRAGMA journal_mode").fetchone()[0] == "wal"


def test_ensure_indexes_without_tables(tmp_path):
    conn = connect(str(tmp_path / "empty.db"))
    ensure_indexes(conn)  # не падает


def test_seed_main(tmp_path, capsys):
    seed_module.main([str(tmp_path / "m.db")])
    assert "seeded: 500 items, 5000 orders" in capsys.readouterr().out


def test_seed_main_default_path(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(seed_module.Config, "DATABASE", str(tmp_path / "d.db"))
    monkeypatch.setattr(sys, "argv", ["seed.py"])
    seed_module.main()
    assert "seeded" in capsys.readouterr().out


def test_unhandled_error_logged_as_error(tmp_path):
    log = tmp_path / "app.log"
    app = create_app(
        {"TESTING": False, "DATABASE": str(tmp_path / "missing.db"),
         "LOG_FILE": str(log)}
    )
    resp = app.test_client().get("/api/items")
    assert resp.status_code == 500
    assert resp.get_json() == {"ok": False}
    assert " ERROR " in log.read_text(encoding="utf-8")


def test_requests_are_logged_without_errors(client, app):
    client.get("/api/items")
    client.post("/api/orders", json={"item_id": 1})  # 400 — не ERROR
    for h in app.logger.handlers:
        h.flush()
    text = open(app.config["LOG_FILE"], encoding="utf-8").read()
    assert "GET /api/items -> 200" in text
    assert " ERROR " not in text


def test_parse_args_defaults_and_port():
    assert app_module.parse_args([]).port == app_module.Config.DEFAULT_PORT
    assert app_module.parse_args(["--port", "5555"]).port == 5555


def test_main_runs_server(monkeypatch):
    calls = {}
    monkeypatch.setattr(
        app_module.app, "run", lambda **kw: calls.update(kw)
    )
    app_module.main(["--port", "5999"])
    assert calls["port"] == 5999
    assert calls["debug"] is False


@pytest.mark.parametrize("value", [None, 1.5, "x"])
def test_as_int_rejects(value):
    with pytest.raises(services.ValidationError):
        services._as_int(value, "f")
