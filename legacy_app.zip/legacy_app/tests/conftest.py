import pytest

import seed as seed_module
from shop import create_app


@pytest.fixture()
def app(tmp_path):
    db = str(tmp_path / "test.db")
    seed_module.seed(db, n_items=20, n_orders=200)
    return create_app(
        {
            "TESTING": True,
            "DATABASE": db,
            "LOG_FILE": str(tmp_path / "app.log"),
        }
    )


@pytest.fixture()
def client(app):
    return app.test_client()
