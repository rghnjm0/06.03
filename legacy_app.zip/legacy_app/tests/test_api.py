def test_index_html(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "Товар 1" in resp.get_data(as_text=True)


def test_items_schema(client):
    resp = client.get("/api/items")
    data = resp.get_json()
    assert resp.status_code == 200
    assert len(data) == 20
    assert {"id", "name", "price", "qty", "orders"} <= set(data[0])


def test_items_orders_count_matches_report(client):
    items = client.get("/api/items").get_json()
    assert sum(i["orders"] for i in items) == 200


def test_create_order_ok_and_visible(client):
    before = client.get("/api/items").get_json()[0]["orders"]
    resp = client.post("/api/orders", json={"item_id": 1, "qty": 2})
    assert resp.status_code == 201
    assert resp.get_json() == {"ok": True}
    after = client.get("/api/items").get_json()[0]["orders"]
    assert after == before + 1


def test_create_order_accepts_numeric_strings(client):
    resp = client.post("/api/orders", json={"item_id": "1", "qty": "3"})
    assert resp.status_code == 201


def test_create_order_validation(client):
    for body in (
        {},
        {"item_id": 1},
        {"item_id": "abc", "qty": 1},
        {"item_id": 1, "qty": 0},
        {"item_id": 1, "qty": True},
        {"item_id": [1], "qty": 1},
        [1, 2],
    ):
        resp = client.post("/api/orders", json=body)
        assert resp.status_code == 400, body
        assert resp.get_json()["ok"] is False


def test_create_order_not_json(client):
    resp = client.post("/api/orders", data="garbage")
    assert resp.status_code == 400


def test_create_order_unknown_item(client):
    resp = client.post("/api/orders", json={"item_id": 99999, "qty": 1})
    assert resp.status_code == 404


def test_report_schema_and_total(client):
    data = client.get("/api/report?from=2024-01-01&to=2025-12-31").get_json()
    assert set(data) == {"total", "by_item"}
    assert data["total"] == sum(data["by_item"].values())


def test_report_defaults_cover_everything(client):
    full = client.get("/api/report").get_json()
    part = client.get("/api/report?from=2024-01-01&to=2024-03-31").get_json()
    assert full["total"] >= part["total"] > 0


def test_report_empty_period(client):
    data = client.get("/api/report?from=1990-01-01&to=1990-12-31").get_json()
    assert data == {"total": 0, "by_item": {}}


def test_report_sql_injection_is_harmless(client):
    payload = "/api/report?from=2024-01-01';DROP TABLE orders;--&to=2024-12-31"
    resp = client.get(payload)
    assert resp.status_code == 200
    # строка воспринята как значение, таблица не удалена
    assert client.get("/api/report").get_json()["total"] > 0


def test_new_order_goes_into_report(client):
    before = client.get("/api/report").get_json()["total"]
    client.post("/api/orders", json={"item_id": 2, "qty": 5})
    after = client.get("/api/report").get_json()["total"]
    assert after == before + 5


def test_404_is_json(client):
    resp = client.get("/nope")
    assert resp.status_code == 404
    assert resp.get_json()["ok"] is False
