"""Заполнение app.db тестовыми данными: 500 товаров, 5000 заказов."""
import datetime
import random
import sqlite3
import sys

from config import Config

SCHEMA = """
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS orders;
CREATE TABLE items (id INTEGER PRIMARY KEY, name TEXT, price REAL, qty INTEGER);
CREATE TABLE orders (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     item_id INTEGER, qty INTEGER, created_at TEXT);
CREATE INDEX idx_orders_item_id ON orders(item_id);
CREATE INDEX idx_orders_created_at ON orders(created_at);
"""


def seed(path: str, n_items: int = 500, n_orders: int = 5000) -> tuple[int, int]:
    """Пересоздаёт таблицы и наполняет их."""
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA)

    items = [
        (f"Товар {i}", round(random.uniform(10, 1000), 2), random.randint(0, 500))
        for i in range(1, n_items + 1)
    ]
    conn.executemany("INSERT INTO items (name, price, qty) VALUES (?, ?, ?)", items)

    start = datetime.date(2024, 1, 1)
    orders = [
        (
            random.randint(1, n_items),
            random.randint(1, 10),
            (start + datetime.timedelta(days=random.randint(0, 700))).isoformat(),
        )
        for _ in range(n_orders)
    ]
    conn.executemany(
        "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)", orders
    )
    conn.commit()
    conn.close()
    return n_items, n_orders


def main(argv=None) -> None:
    """CLI: python seed.py [путь_к_БД]."""
    argv = sys.argv[1:] if argv is None else argv
    path = argv[0] if argv else Config.DATABASE
    n_items, n_orders = seed(path)
    print(f"seeded: {n_items} items, {n_orders} orders")


if __name__ == "__main__":
    main()
