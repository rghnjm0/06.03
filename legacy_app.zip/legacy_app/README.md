# Сервис товаров и заказов (team10)

Отрефакторенная версия legacy-приложения: Flask + SQLite, без внешних зависимостей
кроме Flask. Публичный API не изменён.

## Запуск

```bash
pip install -r requirements.txt
python seed.py                 # создаст app.db (500 товаров, 5000 заказов)
python app.py --port 5010
```

Открыть http://localhost:5010

## API

| Метод | Путь | Описание |
|---|---|---|
| GET | `/` | HTML-список товаров |
| GET | `/api/items` | JSON: `id, name, price, qty, orders` |
| POST | `/api/orders` | Тело `{"item_id": int, "qty": int>0}` → 201 `{"ok": true}`; 400 при невалидных данных; 404 если товара нет |
| GET | `/api/report?from=YYYY-MM-DD&to=YYYY-MM-DD` | `{"total": int, "by_item": {item_id: qty}}` |

## Структура

```
app.py            точка входа (--port, --host)
config.py         настройки (переменные окружения APP_*)
seed.py           наполнение БД + индексы
shop/
  __init__.py     create_app, логирование запросов, обработчики ошибок
  db.py           соединение на запрос, WAL, индексы
  routes.py       blueprint с маршрутами
  services.py     SQL и бизнес-логика (параметризованные запросы)
  logging_conf.py app.log с ротацией
templates/        index.html
tests/            pytest
```

## Конфигурация

| Переменная | По умолчанию |
|---|---|
| `APP_SECRET_KEY` | случайный при старте |
| `APP_DB` | `./app.db` |
| `APP_LOG` | `./app.log` |
| `APP_LOG_LEVEL` | `INFO` |
| `APP_PORT` | `5010` |

## Что изменено

- Устранён N+1 в `/api/items`: один `LEFT JOIN ... GROUP BY`.
- `/api/report` считается агрегирующим SQL, а не в Python.
- Индексы `orders(item_id)`, `orders(created_at)`: в `seed.py` и при старте (`CREATE INDEX IF NOT EXISTS`).
- SQLite: WAL, `busy_timeout`, соединение на запрос (`flask.g`).
- Весь SQL параметризован (нет f-string SQL).
- `except: pass` убран; ошибки логируются через `logging` (`ERROR` с трейсом только для реальных сбоев, ошибки ввода — 400/404 без `ERROR`).
- Секрет не хранится в коде; `debug=False`, `threaded=True`.
- Новые заказы получают `created_at` (сегодняшняя дата) и попадают в отчёт.

## Проверка

```bash
pip install -r requirements-dev.txt
pytest --cov=. --cov-report=term-missing
ruff check .
radon cc . -s
bandit -r . -x ./tests
python ../../../tools/bench.py --port 5010
python ../../../tools/acceptance_tests.py --port 5010
python ../../../tools/check_logs.py --file app.log
```
