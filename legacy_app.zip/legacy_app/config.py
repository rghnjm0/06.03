"""Конфигурация приложения. Значения можно переопределить переменными окружения."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


class Config:
    """Базовые настройки."""

    SECRET_KEY = os.environ.get("APP_SECRET_KEY", os.urandom(24).hex())
    DATABASE = os.environ.get("APP_DB", str(BASE_DIR / "app.db"))
    LOG_FILE = os.environ.get("APP_LOG", str(BASE_DIR / "app.log"))
    LOG_LEVEL = os.environ.get("APP_LOG_LEVEL", "INFO")
    HOST = os.environ.get("APP_HOST", "127.0.0.1")
    DEFAULT_PORT = int(os.environ.get("APP_PORT", "5010"))
