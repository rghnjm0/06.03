import argparse
import json
import os
import re


def analyze(path: str) -> dict:
    if not os.path.exists(path):
        return {"errors": 0, "warnings": 0, "lines": 0}
    err = warn = lines = 0
    with open(path, "r", errors="ignore") as f:
        for line in f:
            lines += 1
            if re.search(r"\bERROR\b", line):
                err += 1
            elif re.search(r"\bWARNING\b", line):
                warn += 1
    return {"errors": err, "warnings": warn, "lines": lines}


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--file", required=True)
    p.add_argument("--out", default=None)
    a = p.parse_args()
    res = analyze(a.file)
    print(json.dumps(res, ensure_ascii=False))
    if a.out:
        with open(a.out, "w") as f:
            json.dump(res, f)