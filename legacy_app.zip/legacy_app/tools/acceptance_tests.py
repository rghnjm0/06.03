import argparse
import json
import sys
import urllib.error
import urllib.request


def post(url: str, body: dict):
    req = urllib.request.Request(url, method="POST")
    req.add_header("Content-Type", "application/json")
    req.data = json.dumps(body).encode()
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, None


def get(url: str):
    try:
        with urllib.request.urlopen(url, timeout=15) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, None


def run(port: int) -> list:
    base = f"http://127.0.0.1:{port}"
    results = []

    st, body = get(f"{base}/api/items")
    results.append({"name": "items_list", "ok": st == 200 and isinstance(body, list)})

    ok = False
    if isinstance(body, list) and body:
        keys = {"id", "name", "price", "qty"}
        ok = keys.issubset(body[0].keys())
    results.append({"name": "items_schema", "ok": ok})

    st, _ = post(f"{base}/api/orders", {"item_id": 1, "qty": 2})
    results.append({"name": "order_create", "ok": st == 201})

    st, body = get(f"{base}/api/report?from=2024-01-01&to=2025-12-31")
    ok = st == 200 and isinstance(body, dict) and "total" in body and "by_item" in body
    results.append({"name": "report_schema", "ok": ok})

    try:
        with urllib.request.urlopen(f"{base}/", timeout=10) as r:
            results.append({"name": "index_html", "ok": r.status == 200})
    except Exception:
        results.append({"name": "index_html", "ok": False})

    return results


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--port", type=int, required=True)
    p.add_argument("--out", default=None)
    a = p.parse_args()
    res = run(a.port)
    passed = all(r["ok"] for r in res)
    out = {"passed": passed, "cases": res}
    print(json.dumps(out, ensure_ascii=False, indent=2))
    if a.out:
        with open(a.out, "w") as f:
            json.dump(out, f)
    sys.exit(0 if passed else 1)