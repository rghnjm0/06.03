import argparse
import json
import statistics
import time
import urllib.request


def call(url: str, method: str = "GET", data=None) -> float:
    req = urllib.request.Request(url, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
        req.data = json.dumps(data).encode()
    t0 = time.perf_counter()
    with urllib.request.urlopen(req, timeout=30) as r:
        r.read()
    return (time.perf_counter() - t0) * 1000  # ms


def bench(port: int, n: int = 50) -> dict:
    base = f"http://127.0.0.1:{port}"
    out = {}

    # прогрев
    call(f"{base}/api/items")

    items_t = [call(f"{base}/api/items") for _ in range(n)]
    report_t = [
        call(f"{base}/api/report?from=2024-01-01&to=2025-01-01")
        for _ in range(n)
    ]

    for name, times in [("items", items_t), ("report", report_t)]:
        s = sorted(times)
        out[name] = {
            "p50": round(statistics.median(s), 1),
            "p95": round(s[int(0.95 * len(s)) - 1], 1),
            "mean": round(statistics.mean(s), 1),
        }
    return out


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--port", type=int, required=True)
    p.add_argument("--out", default=None)
    p.add_argument("-n", type=int, default=50)
    a = p.parse_args()
    res = bench(a.port, a.n)
    print(json.dumps(res, ensure_ascii=False))
    if a.out:
        with open(a.out, "w") as f:
            json.dump(res, f)