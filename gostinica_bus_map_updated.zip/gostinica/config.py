import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


class Config:
    # Секрет и сессия
    SECRET_KEY = os.environ.get("UYUT_SECRET_KEY") or "dev-secret-change-in-production"

    # БД
    DATABASE = str(BASE_DIR / "hotel_management.db")

    # Шина обмена (file-bus с рестораном «Гурман»)
    BUS_ROOT = os.environ.get(
        "BUS_ROOT",
        r"\\192.168.3.250\Veda\4 Курс\ИСП 44\06 03\exchange",
    )
    BUS_SNAPSHOT_INTERVAL = int(os.environ.get("BUS_SNAPSHOT_INTERVAL", "120"))  # раз в 2 минуты
    BUS_REQUEST_TIMEOUT = int(os.environ.get("BUS_REQUEST_TIMEOUT", "30"))      # секунд ожидания ответа
    HOTEL_NAME = os.environ.get("HOTEL_NAME", "Гостиница «Уют»")
    # Расположение отеля для карты на странице «Контакты»
    HOTEL_ADDRESS = os.environ.get("HOTEL_ADDRESS", "г. Москва, ул. Тверская, д. 1")
    HOTEL_LAT = float(os.environ.get("HOTEL_LAT", "55.7571"))
    HOTEL_LON = float(os.environ.get("HOTEL_LON", "37.6145"))
