# Security and deployment notes

- Never deploy with the development environment or demo data.
- Production startup refuses to create a missing database. Provision and migrate it explicitly.
- Set a unique `UYUT_SECRET_KEY`, enable HTTPS, and set `UYUT_ENV=production`.
- Back up the database before any schema/data migration; test restoration.
- Do not distribute a production database or `.env` file.
- Demo/test data is intended only for development. Generated credentials are printed once during initial development seeding; store them securely.
- The bootstrap administrator is created only during first-time local database initialization. Existing admin credentials are not overwritten.
- This hardening pass is not a guarantee of security. Before production, run dynamic authorization, payment-webhook, concurrency, dependency, and restore tests.

## Восстановление доступа

Для установки новых паролей администратора и/или гостя используйте `python reset_access.py` из корня проекта. Утилита меняет только хэши паролей выбранных учётных записей и не удаляет бронирования или другие данные. Перед запуском рекомендуется сделать резервную копию БД. При нестандартном расположении базы задайте переменную `UYUT_DB_PATH`.

## Удаление гостя

В списке гостей админ-панели добавлена кнопка удаления (POST с CSRF-защитой и подтверждением). Гости, у которых есть история бронирований, намеренно не удаляются: это сохраняет целостность истории, счетов и отчётности. Для таких случаев следует использовать деактивацию/анонимизацию по отдельной политике хранения данных.
