"""
Модуль профилирования SQL-запросов для Flask + SQLite.

Для каждого HTTP-запроса фиксирует:
  - маршрут (endpoint / path)
  - HTTP-метод
  - количество SQL-запросов
  - суммарное и максимальное время выполнения SQL
  - список медленных запросов

Использование:
  from sql_profiler import init_sql_profiler
  init_sql_profiler(app)          # в app.py один раз

  get_db() из db.py автоматически возвращает инструментированное соединение.

В логах будет строка вида:
  [SQL] GET    /admin/dashboard                       queries= 12  sql=  45.2ms  max= 12.1ms  req=  89.0ms  endpoint=admin_dashboard

В каждом HTTP-ответе появляются заголовки:
  X-SQL-Queries: 12
  X-SQL-Time-Ms: 45.2

Env:
  SQL_PROFILER=1|0           — вкл/выкл (по умолчанию 1)
  SQL_PROFILER_LOG=1|0       — писать сводку в лог
  SQL_PROFILER_SLOW_MS=20    — порог «медленного» запроса (мс)
  SQL_PROFILER_MAX_QUERIES=15
"""

from __future__ import annotations

import os
import time
import logging
import sqlite3
import threading
from dataclasses import dataclass, field
from typing import Any, List, Optional, Sequence

logger = logging.getLogger("sql_profiler")

# ---------------------------------------------------------------------------
# Конфигурация
# ---------------------------------------------------------------------------
ENABLED = os.environ.get("SQL_PROFILER", "1") != "0"
LOG_SUMMARY = os.environ.get("SQL_PROFILER_LOG", "1") != "0"
LOG_SLOW_MS = float(os.environ.get("SQL_PROFILER_SLOW_MS", "20"))
MAX_QUERIES_IN_LOG = int(os.environ.get("SQL_PROFILER_MAX_QUERIES", "15"))
HEADER_NAME = "X-SQL-Queries"
HEADER_TIME = "X-SQL-Time-Ms"


@dataclass
class QueryRecord:
    sql: str
    duration_ms: float
    args_preview: str = ""
    is_executemany: bool = False
    rowcount: int = -1


@dataclass
class RequestStats:
    route: str = ""
    endpoint: str = ""
    method: str = ""
    path: str = ""
    queries: List[QueryRecord] = field(default_factory=list)
    request_start: float = 0.0

    @property
    def query_count(self) -> int:
        return len(self.queries)

    @property
    def total_sql_ms(self) -> float:
        return sum(q.duration_ms for q in self.queries)

    @property
    def max_sql_ms(self) -> float:
        return max((q.duration_ms for q in self.queries), default=0.0)

    def summary_line(self) -> str:
        req_ms = (time.perf_counter() - self.request_start) * 1000 if self.request_start else 0
        return (
            f"[SQL] {self.method:6} {self.path or self.route:40} "
            f"queries={self.query_count:3d}  "
            f"sql={self.total_sql_ms:7.1f}ms  "
            f"max={self.max_sql_ms:6.1f}ms  "
            f"req={req_ms:7.1f}ms  "
            f"endpoint={self.endpoint or '-'}"
        )


# Потокобезопасное хранилище (работает и вне request context)
_local = threading.local()

# Кольцевой буфер последних N запросов (для админ-панели)
_HISTORY_LOCK = threading.Lock()
_HISTORY_MAX = int(os.environ.get("SQL_PROFILER_HISTORY", "100"))
_HISTORY: list = []  # list of dict snapshots


def _push_history(snapshot: dict) -> None:
    with _HISTORY_LOCK:
        _HISTORY.append(snapshot)
        if len(_HISTORY) > _HISTORY_MAX:
            del _HISTORY[: len(_HISTORY) - _HISTORY_MAX]


def get_history(limit: int = 50) -> list:
    """Последние профилированные HTTP-запросы (новые сверху)."""
    with _HISTORY_LOCK:
        return list(reversed(_HISTORY[-limit:]))


def clear_history() -> None:
    with _HISTORY_LOCK:
        _HISTORY.clear()



def _has_request_context() -> bool:
    try:
        from flask import has_request_context
        return has_request_context()
    except ImportError:
        return False


def _current_stats() -> Optional[RequestStats]:
    if _has_request_context():
        from flask import g
        return getattr(g, "_sql_stats", None)
    return getattr(_local, "stats", None)


def _set_stats(stats: Optional[RequestStats]) -> None:
    if _has_request_context():
        from flask import g
        g._sql_stats = stats
    _local.stats = stats


def _truncate_sql(sql: str, limit: int = 200) -> str:
    sql = " ".join(sql.split())
    if len(sql) > limit:
        return sql[: limit - 3] + "..."
    return sql


def _preview_args(args: Any, limit: int = 80) -> str:
    if args is None:
        return ""
    try:
        s = repr(args)
        if len(s) > limit:
            return s[: limit - 3] + "..."
        return s
    except Exception:
        return "<args>"


# ---------------------------------------------------------------------------
# Инструментированное соединение
# ---------------------------------------------------------------------------
class ProfiledConnection:
    """Обёртка над sqlite3.Connection — считает и замеряет все execute*."""

    def __init__(self, conn: sqlite3.Connection):
        object.__setattr__(self, "_conn", conn)

    def __getattr__(self, name: str):
        return getattr(self._conn, name)

    def __setattr__(self, name: str, value):
        if name == "_conn":
            object.__setattr__(self, name, value)
        else:
            setattr(self._conn, name, value)

    def __enter__(self):
        self._conn.__enter__()
        return self

    def __exit__(self, *args):
        return self._conn.__exit__(*args)

    def close(self):
        return self._conn.close()

    def commit(self):
        return self._conn.commit()

    def rollback(self):
        return self._conn.rollback()

    def cursor(self, *args, **kwargs):
        cur = self._conn.cursor(*args, **kwargs)
        return ProfiledCursor(cur, self)

    def _record(self, sql: str, duration_ms: float, args=None, is_many: bool = False, rowcount: int = -1):
        stats = _current_stats()
        if stats is None:
            return
        rec = QueryRecord(
            sql=_truncate_sql(sql),
            duration_ms=duration_ms,
            args_preview=_preview_args(args),
            is_executemany=is_many,
            rowcount=rowcount,
        )
        stats.queries.append(rec)

    def execute(self, sql: str, parameters: Sequence = ()) -> sqlite3.Cursor:
        t0 = time.perf_counter()
        cur = self._conn.execute(sql, parameters)
        dt = (time.perf_counter() - t0) * 1000
        self._record(sql, dt, parameters, rowcount=getattr(cur, "rowcount", -1))
        return cur

    def executemany(self, sql: str, parameters: Sequence) -> sqlite3.Cursor:
        t0 = time.perf_counter()
        cur = self._conn.executemany(sql, parameters)
        dt = (time.perf_counter() - t0) * 1000
        try:
            n = len(parameters)  # type: ignore
        except TypeError:
            n = "?"
        self._record(sql, dt, f"<{n} rows>", is_many=True, rowcount=getattr(cur, "rowcount", -1))
        return cur

    def executescript(self, sql_script: str):
        t0 = time.perf_counter()
        result = self._conn.executescript(sql_script)
        dt = (time.perf_counter() - t0) * 1000
        preview = sql_script[:120] + ("..." if len(sql_script) > 120 else "")
        self._record(preview, dt)
        return result


class ProfiledCursor:
    """Обёртка курсора — тоже считает execute*."""

    def __init__(self, cursor: sqlite3.Cursor, parent: ProfiledConnection):
        object.__setattr__(self, "_cur", cursor)
        object.__setattr__(self, "_parent", parent)

    def __getattr__(self, name: str):
        return getattr(self._cur, name)

    def __iter__(self):
        return iter(self._cur)

    def execute(self, sql: str, parameters: Sequence = ()):
        t0 = time.perf_counter()
        result = self._cur.execute(sql, parameters)
        dt = (time.perf_counter() - t0) * 1000
        self._parent._record(sql, dt, parameters, rowcount=self._cur.rowcount)
        return result

    def executemany(self, sql: str, parameters: Sequence):
        t0 = time.perf_counter()
        result = self._cur.executemany(sql, parameters)
        dt = (time.perf_counter() - t0) * 1000
        try:
            n = len(parameters)  # type: ignore
        except TypeError:
            n = "?"
        self._parent._record(sql, dt, f"<{n} rows>", is_many=True, rowcount=self._cur.rowcount)
        return result

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()

    def fetchmany(self, size=None):
        return self._cur.fetchmany(size) if size is not None else self._cur.fetchmany()

    def close(self):
        return self._cur.close()


# ---------------------------------------------------------------------------
# Публичный API
# ---------------------------------------------------------------------------
def wrap_connection(conn: sqlite3.Connection):
    """Оборачивает обычное соединение в профилируемое (если ENABLED)."""
    if not ENABLED:
        return conn
    return ProfiledConnection(conn)


def get_request_stats() -> Optional[RequestStats]:
    """Статистика текущего HTTP-запроса (или None)."""
    return _current_stats()


def init_sql_profiler(app, enabled: Optional[bool] = None) -> None:
    """
    Подключает middleware к Flask-приложению.
    Вызывать один раз при старте: init_sql_profiler(app)
    """
    global ENABLED
    if enabled is not None:
        ENABLED = enabled
    if not ENABLED:
        logger.info("SQL profiler disabled")
        return

    from flask import g, request

    @app.before_request
    def _sql_profiler_before():
        stats = RequestStats(
            route=request.url_rule.rule if request.url_rule else request.path,
            endpoint=request.endpoint or "",
            method=request.method,
            path=request.path,
            request_start=time.perf_counter(),
        )
        _set_stats(stats)

    @app.after_request
    def _sql_profiler_after(response):
        stats = _current_stats()
        if stats is None:
            return response

        response.headers[HEADER_NAME] = str(stats.query_count)
        response.headers[HEADER_TIME] = f"{stats.total_sql_ms:.1f}"

        if LOG_SUMMARY and stats.query_count > 0:
            logger.info(stats.summary_line())
            slow = [q for q in stats.queries if q.duration_ms >= LOG_SLOW_MS]
            if slow:
                for i, q in enumerate(slow[:MAX_QUERIES_IN_LOG], 1):
                    many = " [many]" if q.is_executemany else ""
                    logger.warning(
                        "  SLOW #%d %.1fms%s  %s  %s",
                        i, q.duration_ms, many, q.sql, q.args_preview,
                    )
            elif stats.query_count > MAX_QUERIES_IN_LOG:
                top = sorted(stats.queries, key=lambda x: -x.duration_ms)[:5]
                for i, q in enumerate(top, 1):
                    logger.info("  TOP #%d %.1fms  %s", i, q.duration_ms, q.sql)

        g.sql_profiler_stats = {
            "route": stats.route,
            "endpoint": stats.endpoint,
            "method": stats.method,
            "path": stats.path,
            "query_count": stats.query_count,
            "total_sql_ms": round(stats.total_sql_ms, 2),
            "max_sql_ms": round(stats.max_sql_ms, 2),
            "queries": [
                {
                    "sql": q.sql,
                    "ms": round(q.duration_ms, 2),
                    "args": q.args_preview,
                    "many": q.is_executemany,
                }
                for q in stats.queries
            ],
        }
        _push_history(dict(g.sql_profiler_stats))
        return response

    @app.teardown_request
    def _sql_profiler_teardown(exc=None):
        _set_stats(None)

    @app.route("/__sql_stats")
    def _sql_stats_endpoint():
        from flask import jsonify
        return jsonify({
            "info": "Статистика SQL пишется в логи сервера и в заголовки каждого ответа: X-SQL-Queries, X-SQL-Time-Ms",
            "enable": "SQL_PROFILER=1 (по умолчанию)",
            "disable": "SQL_PROFILER=0",
            "slow_threshold_ms": LOG_SLOW_MS,
            "example_log": "[SQL] GET    /admin/dashboard    queries=12  sql=45.2ms  max=12.1ms  req=89.0ms  endpoint=admin_dashboard",
        })

    logger.info("SQL profiler enabled (slow ≥ %.0f ms, log=%s)", LOG_SLOW_MS, LOG_SUMMARY)


def format_stats_for_console(stats: RequestStats) -> str:
    """Красивый текстовый отчёт."""
    lines = ["=" * 72, stats.summary_line(), "-" * 72]
    for i, q in enumerate(stats.queries, 1):
        flag = " *SLOW*" if q.duration_ms >= LOG_SLOW_MS else ""
        many = " [executemany]" if q.is_executemany else ""
        lines.append(f"  {i:3d}. {q.duration_ms:7.1f}ms{flag}{many}")
        lines.append(f"       {q.sql}")
        if q.args_preview:
            lines.append(f"       args: {q.args_preview}")
    lines.append("=" * 72)
    return "\n".join(lines)
