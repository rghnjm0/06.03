"""
Вспомогательные функции АИС «Уют».
"""
from __future__ import annotations

import os
import re
from datetime import datetime, date
from typing import Optional, Tuple, Any

from db import get_db, DB_NAME

# Активные статусы бронирований (номер считается занятым)
ACTIVE_BOOKING_STATUSES = ("Подтверждено", "Заселен")


def init_uploads() -> None:
    """Создаёт папки для загрузок изображений номеров."""
    upload_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "images", "rooms")
    os.makedirs(upload_dir, exist_ok=True)


def register_context_processors(app) -> None:
    """Общие переменные для всех шаблонов."""
    @app.context_processor
    def inject_globals():
        return {
            "ACTIVE_BOOKING_STATUSES": ACTIVE_BOOKING_STATUSES,
            "now": datetime.now,
        }


def next_id(conn, table: str, prefix: str, column: str) -> str:
    """
    Генерирует следующий ID вида PREFIX + номер (например BR00042).
    Берёт максимальный числовой суффикс из существующих записей.
    """
    row = conn.execute(
        f"SELECT {column} FROM {table} WHERE {column} LIKE ? ORDER BY LENGTH({column}) DESC, {column} DESC LIMIT 1",
        (f"{prefix}%",),
    ).fetchone()
    if row is None:
        return f"{prefix}00001"
    val = row[0] if not hasattr(row, "keys") else row[column]
    m = re.search(r"(\d+)$", str(val))
    n = int(m.group(1)) + 1 if m else 1
    return f"{prefix}{n:05d}"


def booking_total(conn, room_id: str, check_in: str, check_out: str) -> Tuple[float, int]:
    """
    Считает стоимость проживания и количество ночей.
    Возвращает (total, nights).
    """
    room = conn.execute(
        "SELECT Цена_за_сутки FROM Номера WHERE ID_Номера=?", (room_id,)
    ).fetchone()
    if not room:
        return 0.0, 0
    price = float(room[0] if not hasattr(room, "keys") else room["Цена_за_сутки"])
    start = datetime.strptime(check_in, "%Y-%m-%d").date()
    end = datetime.strptime(check_out, "%Y-%m-%d").date()
    nights = max((end - start).days, 0)
    return price * nights, nights


def booking_conflicts(
    conn,
    room_id: str,
    check_in: str,
    check_out: str,
    exclude_booking_id: Optional[str] = None,
) -> bool:
    """
    True, если на указанный период уже есть активная бронь этого номера.
    Пересечения: NOT (existing.out <= new.in OR existing.in >= new.out)
    """
    sql = """
        SELECT 1 FROM Бронирования
        WHERE ID_Номера = ?
          AND Статус IN ('Подтверждено', 'Заселен')
          AND NOT (Дата_выезда <= ? OR Дата_заезда >= ?)
    """
    params: list = [room_id, check_in, check_out]
    if exclude_booking_id:
        sql += " AND ID_Бронирования != ?"
        params.append(exclude_booking_id)
    sql += " LIMIT 1"
    row = conn.execute(sql, params).fetchone()
    return row is not None


def sync_room_statuses() -> None:
    """
    Пересчитывает статусы номеров на основе текущих активных бронирований.
      Занят      — есть бронь со статусом «Заселен» и сегодня внутри периода
      Будет занят — есть будущая подтверждённая бронь
      Свободен   — иначе
    """
    today = datetime.now().strftime("%Y-%m-%d")
    conn = get_db()
    try:
        rooms = conn.execute("SELECT ID_Номера FROM Номера").fetchall()
        for r in rooms:
            rid = r[0] if not hasattr(r, "keys") else r["ID_Номера"]

            occupied = conn.execute(
                """
                SELECT 1 FROM Бронирования
                WHERE ID_Номера=? AND Статус='Заселен'
                  AND Дата_заезда <= ? AND Дата_выезда > ?
                LIMIT 1
                """,
                (rid, today, today),
            ).fetchone()

            if occupied:
                status = "Занят"
            else:
                future = conn.execute(
                    """
                    SELECT 1 FROM Бронирования
                    WHERE ID_Номера=? AND Статус IN ('Подтверждено','Заселен')
                      AND Дата_заезда > ?
                    LIMIT 1
                    """,
                    (rid, today),
                ).fetchone()
                status = "Будет занят" if future else "Свободен"

            conn.execute(
                "UPDATE Номера SET Статус=? WHERE ID_Номера=?",
                (status, rid),
            )
        conn.commit()
    finally:
        conn.close()


def safe_csv_value(value: Any) -> str:
    """
    Защита от CSV formula injection.
    Если значение начинается с =, +, -, @ — префиксируем апострофом.
    """
    if value is None:
        return ""
    s = str(value)
    if s and s[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + s
    return s
