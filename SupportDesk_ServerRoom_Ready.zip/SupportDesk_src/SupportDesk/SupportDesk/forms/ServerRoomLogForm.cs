using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    /// <summary>
    /// Журнал посещений серверной (отдельный учёт доступа, не заявка).
    /// Автоматически подставляет текущего пользователя и время входа.
    /// </summary>
    public partial class ServerRoomLogForm : Form
    {
        #region Настройки формы (перетаскивание)
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion

        #region Локальные переменные
        private SQLiteConnection DB;
        private readonly DateTime thisDay = DateTime.Now;
        #endregion

        public ServerRoomLogForm()
        {
            InitializeComponent();
        }

        private async void ServerRoomLogForm_Load(object sender, EventArgs e)
        {
            DB = new SQLiteConnection(Database.connectionString);
            await DB.OpenAsync();

            // Автоматическое создание таблицы, если её ещё нет
            await EnsureTableExistsAsync();

            // Автозаполнение текущего пользователя
            textBoxUser.Text = DataUsers.Initials ?? "";
            textBoxUser.ReadOnly = true;
            dateTimePickerEntry.Value = DateTime.Now;
            dateTimePickerEntry.Enabled = false; // время входа всегда текущее при создании

            FullList();
        }

        #region Создание таблицы (автоматизация)
        private async System.Threading.Tasks.Task EnsureTableExistsAsync()
        {
            string sql = $@"
                CREATE TABLE IF NOT EXISTS [{Table_serverRoomVisits.main}] (
                    [{Table_serverRoomVisits.id}] INTEGER PRIMARY KEY AUTOINCREMENT,
                    [{Table_serverRoomVisits.userFio}] TEXT NOT NULL,
                    [{Table_serverRoomVisits.login}] TEXT,
                    [{Table_serverRoomVisits.entryDateTime}] TEXT NOT NULL,
                    [{Table_serverRoomVisits.exitDateTime}] TEXT,
                    [{Table_serverRoomVisits.reason}] TEXT NOT NULL,
                    [{Table_serverRoomVisits.actions}] TEXT NOT NULL,
                    [{Table_serverRoomVisits.note}] TEXT,
                    [{Table_serverRoomVisits.status}] TEXT NOT NULL DEFAULT 'В серверной'
                );";

            using (var cmd = new SQLiteCommand(sql, DB))
            {
                await cmd.ExecuteNonQueryAsync();
            }
        }
        #endregion

        #region Загрузка журнала
        private async void FullList()
        {
            dataGridViewVisits.Rows.Clear();
            SQLiteDataReader sqlReader = null;
            var command = new SQLiteCommand(
                $"SELECT * FROM [{Table_serverRoomVisits.main}] ORDER BY [{Table_serverRoomVisits.id}] DESC", DB);

            var data = new List<string[]>();
            try
            {
                sqlReader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                while (await sqlReader.ReadAsync())
                {
                    data.Add(new string[8]
                    {
                        Convert.ToString(sqlReader[Table_serverRoomVisits.id]),
                        Convert.ToString(sqlReader[Table_serverRoomVisits.userFio]),
                        Convert.ToString(sqlReader[Table_serverRoomVisits.entryDateTime]),
                        Convert.ToString(sqlReader[Table_serverRoomVisits.exitDateTime]),
                        Convert.ToString(sqlReader[Table_serverRoomVisits.reason]),
                        Convert.ToString(sqlReader[Table_serverRoomVisits.actions]),
                        Convert.ToString(sqlReader[Table_serverRoomVisits.note]),
                        Convert.ToString(sqlReader[Table_serverRoomVisits.status])
                    });
                }

                foreach (string[] s in data)
                {
                    dataGridViewVisits.Rows.Add(s);
                }
                dataGridViewVisits.ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
            finally
            {
                sqlReader?.Close();
            }
        }
        #endregion

        #region Управление формой
        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void ButtonClose_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion

        #region Добавить запись о входе (автоматизировано)
        private async void ButtonAdd_Click(object sender, EventArgs e)
        {
            string reason = textBoxReason.Text.Trim();
            string actions = textBoxActions.Text.Trim();
            string note = textBoxNote.Text.Trim();

            if (string.IsNullOrEmpty(reason) || string.IsNullOrEmpty(actions))
            {
                MessageBoxUI.Show("Заполните поля «Зачем» и «Что делал»", "Журнал серверной", "Error");
                return;
            }

            string entry = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            string fio = DataUsers.Initials ?? textBoxUser.Text;
            string login = DataUsers.Login ?? "";

            try
            {
                var cmd = new SQLiteCommand(
                    $@"INSERT INTO [{Table_serverRoomVisits.main}] 
                       ([{Table_serverRoomVisits.userFio}], [{Table_serverRoomVisits.login}], 
                        [{Table_serverRoomVisits.entryDateTime}], [{Table_serverRoomVisits.reason}], 
                        [{Table_serverRoomVisits.actions}], [{Table_serverRoomVisits.note}], 
                        [{Table_serverRoomVisits.status}])
                       VALUES (@fio, @login, @entry, @reason, @actions, @note, @status)", DB);

                cmd.Parameters.AddWithValue("@fio", fio);
                cmd.Parameters.AddWithValue("@login", login);
                cmd.Parameters.AddWithValue("@entry", entry);
                cmd.Parameters.AddWithValue("@reason", reason);
                cmd.Parameters.AddWithValue("@actions", actions);
                cmd.Parameters.AddWithValue("@note", note);
                cmd.Parameters.AddWithValue("@status", "В серверной");

                await cmd.ExecuteNonQueryAsync();

                // Лог в файл (как во всём проекте)
                File.AppendAllText(Logs.file,
                    $"[Серверная] {fio} зашёл в серверную. Цель: {reason}. Что делал: {actions} ({entry})");
                File.AppendAllText(Logs.file, Environment.NewLine);

                MessageBoxUI.Show("Запись о входе добавлена", "Журнал серверной", "Accept");

                // Очистка полей для следующей записи
                textBoxReason.Clear();
                textBoxActions.Clear();
                textBoxNote.Clear();
                dateTimePickerEntry.Value = DateTime.Now;

                FullList();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }
        #endregion

        #region Отметить выход
        private async void ButtonExitVisit_Click(object sender, EventArgs e)
        {
            if (dataGridViewVisits.SelectedCells.Count == 0)
            {
                MessageBoxUI.Show("Выберите запись, для которой нужно отметить выход", "Журнал серверной", "Error");
                return;
            }

            int rowIndex = dataGridViewVisits.SelectedCells[0].RowIndex;
            DataGridViewRow row = dataGridViewVisits.Rows[rowIndex];

            string id = Convert.ToString(row.Cells["ColumnId"].Value);
            string status = Convert.ToString(row.Cells["ColumnStatus"].Value);

            if (status == "Вышел")
            {
                MessageBoxUI.Show("Эта запись уже закрыта (выход отмечен)", "Журнал серверной", "Error");
                return;
            }

            string exitTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");

            try
            {
                var cmd = new SQLiteCommand(
                    $@"UPDATE [{Table_serverRoomVisits.main}] 
                       SET [{Table_serverRoomVisits.exitDateTime}] = @exit,
                           [{Table_serverRoomVisits.status}] = @status
                       WHERE [{Table_serverRoomVisits.id}] = @id", DB);

                cmd.Parameters.AddWithValue("@exit", exitTime);
                cmd.Parameters.AddWithValue("@status", "Вышел");
                cmd.Parameters.AddWithValue("@id", id);

                await cmd.ExecuteNonQueryAsync();

                string fio = Convert.ToString(row.Cells["ColumnUser"].Value);
                File.AppendAllText(Logs.file,
                    $"[Серверная] {fio} вышел из серверной ({exitTime})");
                File.AppendAllText(Logs.file, Environment.NewLine);

                MessageBoxUI.Show("Выход отмечен", "Журнал серверной", "Accept");
                FullList();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }
        #endregion

        #region Обновить список
        private void ButtonRefresh_Click(object sender, EventArgs e)
        {
            FullList();
        }
        #endregion

        #region Удаление (только для админа)
        private async void ButtonDelete_Click(object sender, EventArgs e)
        {
            // Можно ограничить только ADMIN
            if (DataUsers.GroupUser != "ADMIN" && DataUsers.GroupUser != "ROOT")
            {
                MessageBoxUI.Show("Удалять записи может только администратор", "Журнал серверной", "Error");
                return;
            }

            if (dataGridViewVisits.SelectedCells.Count == 0) return;

            int rowIndex = dataGridViewVisits.SelectedCells[0].RowIndex;
            string id = Convert.ToString(dataGridViewVisits.Rows[rowIndex].Cells["ColumnId"].Value);

            var cmd = new SQLiteCommand(
                $"DELETE FROM [{Table_serverRoomVisits.main}] WHERE [{Table_serverRoomVisits.id}] = @id", DB);
            cmd.Parameters.AddWithValue("@id", id);
            await cmd.ExecuteNonQueryAsync();

            File.AppendAllText(Logs.file,
                $"[Серверная] {DataUsers.Initials} удалил запись ID={id} ({DateTime.Now:dd.MM.yyyy HH:mm})");
            File.AppendAllText(Logs.file, Environment.NewLine);

            FullList();
        }
        #endregion
    }
}
