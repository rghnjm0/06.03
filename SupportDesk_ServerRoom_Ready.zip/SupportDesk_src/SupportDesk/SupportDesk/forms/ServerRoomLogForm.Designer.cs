namespace SupportDesk.forms
{
    partial class ServerRoomLogForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.buttonClose = new System.Windows.Forms.Button();
            this.panelAdd = new System.Windows.Forms.Panel();
            this.labelUser = new System.Windows.Forms.Label();
            this.textBoxUser = new System.Windows.Forms.TextBox();
            this.labelEntry = new System.Windows.Forms.Label();
            this.dateTimePickerEntry = new System.Windows.Forms.DateTimePicker();
            this.labelReason = new System.Windows.Forms.Label();
            this.textBoxReason = new System.Windows.Forms.TextBox();
            this.labelActions = new System.Windows.Forms.Label();
            this.textBoxActions = new System.Windows.Forms.TextBox();
            this.labelNote = new System.Windows.Forms.Label();
            this.textBoxNote = new System.Windows.Forms.TextBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonExitVisit = new System.Windows.Forms.Button();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.dataGridViewVisits = new System.Windows.Forms.DataGridView();
            this.ColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnUser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnEntry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnExit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReason = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnActions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelTop.SuspendLayout();
            this.panelAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisits)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelTop.Controls.Add(this.labelTitle);
            this.panelTop.Controls.Add(this.buttonClose);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1100, 40);
            this.panelTop.TabIndex = 0;
            this.panelTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormControl);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(12, 10);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(280, 20);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Журнал посещений серверной";
            this.labelTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormControl);
            // 
            // buttonClose
            // 
            this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.buttonClose.ForeColor = System.Drawing.Color.White;
            this.buttonClose.Location = new System.Drawing.Point(1055, 5);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(35, 30);
            this.buttonClose.TabIndex = 1;
            this.buttonClose.Text = "✕";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.ButtonClose_Click);
            // 
            // panelAdd
            // 
            this.panelAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.panelAdd.Controls.Add(this.labelUser);
            this.panelAdd.Controls.Add(this.textBoxUser);
            this.panelAdd.Controls.Add(this.labelEntry);
            this.panelAdd.Controls.Add(this.dateTimePickerEntry);
            this.panelAdd.Controls.Add(this.labelReason);
            this.panelAdd.Controls.Add(this.textBoxReason);
            this.panelAdd.Controls.Add(this.labelActions);
            this.panelAdd.Controls.Add(this.textBoxActions);
            this.panelAdd.Controls.Add(this.labelNote);
            this.panelAdd.Controls.Add(this.textBoxNote);
            this.panelAdd.Controls.Add(this.buttonAdd);
            this.panelAdd.Controls.Add(this.buttonExitVisit);
            this.panelAdd.Controls.Add(this.buttonRefresh);
            this.panelAdd.Controls.Add(this.buttonDelete);
            this.panelAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAdd.Location = new System.Drawing.Point(0, 40);
            this.panelAdd.Name = "panelAdd";
            this.panelAdd.Size = new System.Drawing.Size(1100, 160);
            this.panelAdd.TabIndex = 1;
            // 
            // labelUser
            // 
            this.labelUser.AutoSize = true;
            this.labelUser.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelUser.Location = new System.Drawing.Point(15, 15);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new System.Drawing.Size(28, 15);
            this.labelUser.TabIndex = 0;
            this.labelUser.Text = "Кто:";
            // 
            // textBoxUser
            // 
            this.textBoxUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.textBoxUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxUser.ForeColor = System.Drawing.Color.White;
            this.textBoxUser.Location = new System.Drawing.Point(70, 12);
            this.textBoxUser.Name = "textBoxUser";
            this.textBoxUser.Size = new System.Drawing.Size(200, 23);
            this.textBoxUser.TabIndex = 1;
            // 
            // labelEntry
            // 
            this.labelEntry.AutoSize = true;
            this.labelEntry.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelEntry.Location = new System.Drawing.Point(290, 15);
            this.labelEntry.Name = "labelEntry";
            this.labelEntry.Size = new System.Drawing.Size(75, 15);
            this.labelEntry.TabIndex = 2;
            this.labelEntry.Text = "Время входа:";
            // 
            // dateTimePickerEntry
            // 
            this.dateTimePickerEntry.CustomFormat = "dd.MM.yyyy HH:mm:ss";
            this.dateTimePickerEntry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerEntry.Location = new System.Drawing.Point(375, 12);
            this.dateTimePickerEntry.Name = "dateTimePickerEntry";
            this.dateTimePickerEntry.Size = new System.Drawing.Size(180, 23);
            this.dateTimePickerEntry.TabIndex = 3;
            // 
            // labelReason
            // 
            this.labelReason.AutoSize = true;
            this.labelReason.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelReason.Location = new System.Drawing.Point(15, 50);
            this.labelReason.Name = "labelReason";
            this.labelReason.Size = new System.Drawing.Size(48, 15);
            this.labelReason.TabIndex = 4;
            this.labelReason.Text = "Зачем:";
            // 
            // textBoxReason
            // 
            this.textBoxReason.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.textBoxReason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxReason.ForeColor = System.Drawing.Color.White;
            this.textBoxReason.Location = new System.Drawing.Point(70, 47);
            this.textBoxReason.Name = "textBoxReason";
            this.textBoxReason.Size = new System.Drawing.Size(485, 23);
            this.textBoxReason.TabIndex = 5;
            // 
            // labelActions
            // 
            this.labelActions.AutoSize = true;
            this.labelActions.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelActions.Location = new System.Drawing.Point(15, 85);
            this.labelActions.Name = "labelActions";
            this.labelActions.Size = new System.Drawing.Size(68, 15);
            this.labelActions.TabIndex = 6;
            this.labelActions.Text = "Что делал:";
            // 
            // textBoxActions
            // 
            this.textBoxActions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.textBoxActions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxActions.ForeColor = System.Drawing.Color.White;
            this.textBoxActions.Location = new System.Drawing.Point(90, 82);
            this.textBoxActions.Name = "textBoxActions";
            this.textBoxActions.Size = new System.Drawing.Size(465, 23);
            this.textBoxActions.TabIndex = 7;
            // 
            // labelNote
            // 
            this.labelNote.AutoSize = true;
            this.labelNote.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelNote.Location = new System.Drawing.Point(15, 120);
            this.labelNote.Name = "labelNote";
            this.labelNote.Size = new System.Drawing.Size(80, 15);
            this.labelNote.TabIndex = 8;
            this.labelNote.Text = "Примечание:";
            // 
            // textBoxNote
            // 
            this.textBoxNote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.textBoxNote.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNote.ForeColor = System.Drawing.Color.White;
            this.textBoxNote.Location = new System.Drawing.Point(100, 117);
            this.textBoxNote.Name = "textBoxNote";
            this.textBoxNote.Size = new System.Drawing.Size(455, 23);
            this.textBoxNote.TabIndex = 9;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.buttonAdd.FlatAppearance.BorderSize = 0;
            this.buttonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdd.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonAdd.ForeColor = System.Drawing.Color.White;
            this.buttonAdd.Location = new System.Drawing.Point(600, 12);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(150, 35);
            this.buttonAdd.TabIndex = 10;
            this.buttonAdd.Text = "Зафиксировать вход";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.ButtonAdd_Click);
            // 
            // buttonExitVisit
            // 
            this.buttonExitVisit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(80)))));
            this.buttonExitVisit.FlatAppearance.BorderSize = 0;
            this.buttonExitVisit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExitVisit.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonExitVisit.ForeColor = System.Drawing.Color.White;
            this.buttonExitVisit.Location = new System.Drawing.Point(760, 12);
            this.buttonExitVisit.Name = "buttonExitVisit";
            this.buttonExitVisit.Size = new System.Drawing.Size(150, 35);
            this.buttonExitVisit.TabIndex = 11;
            this.buttonExitVisit.Text = "Отметить выход";
            this.buttonExitVisit.UseVisualStyleBackColor = false;
            this.buttonExitVisit.Click += new System.EventHandler(this.ButtonExitVisit_Click);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.buttonRefresh.FlatAppearance.BorderSize = 0;
            this.buttonRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRefresh.ForeColor = System.Drawing.Color.White;
            this.buttonRefresh.Location = new System.Drawing.Point(920, 12);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(80, 35);
            this.buttonRefresh.TabIndex = 12;
            this.buttonRefresh.Text = "Обновить";
            this.buttonRefresh.UseVisualStyleBackColor = false;
            this.buttonRefresh.Click += new System.EventHandler(this.ButtonRefresh_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.buttonDelete.FlatAppearance.BorderSize = 0;
            this.buttonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDelete.ForeColor = System.Drawing.Color.White;
            this.buttonDelete.Location = new System.Drawing.Point(1005, 12);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(80, 35);
            this.buttonDelete.TabIndex = 13;
            this.buttonDelete.Text = "Удалить";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.ButtonDelete_Click);
            // 
            // dataGridViewVisits
            // 
            this.dataGridViewVisits.AllowUserToAddRows = false;
            this.dataGridViewVisits.AllowUserToDeleteRows = false;
            this.dataGridViewVisits.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.dataGridViewVisits.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewVisits.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVisits.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnId,
            this.ColumnUser,
            this.ColumnEntry,
            this.ColumnExit,
            this.ColumnReason,
            this.ColumnActions,
            this.ColumnNote,
            this.ColumnStatus});
            this.dataGridViewVisits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVisits.EnableHeadersVisualStyles = false;
            this.dataGridViewVisits.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.dataGridViewVisits.Location = new System.Drawing.Point(0, 200);
            this.dataGridViewVisits.MultiSelect = false;
            this.dataGridViewVisits.Name = "dataGridViewVisits";
            this.dataGridViewVisits.ReadOnly = true;
            this.dataGridViewVisits.RowHeadersVisible = false;
            this.dataGridViewVisits.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVisits.Size = new System.Drawing.Size(1100, 450);
            this.dataGridViewVisits.TabIndex = 2;
            // 
            // ColumnId
            // 
            this.ColumnId.HeaderText = "ID";
            this.ColumnId.Name = "ColumnId";
            this.ColumnId.ReadOnly = true;
            this.ColumnId.Width = 50;
            // 
            // ColumnUser
            // 
            this.ColumnUser.HeaderText = "Кто";
            this.ColumnUser.Name = "ColumnUser";
            this.ColumnUser.ReadOnly = true;
            this.ColumnUser.Width = 150;
            // 
            // ColumnEntry
            // 
            this.ColumnEntry.HeaderText = "Вход";
            this.ColumnEntry.Name = "ColumnEntry";
            this.ColumnEntry.ReadOnly = true;
            this.ColumnEntry.Width = 140;
            // 
            // ColumnExit
            // 
            this.ColumnExit.HeaderText = "Выход";
            this.ColumnExit.Name = "ColumnExit";
            this.ColumnExit.ReadOnly = true;
            this.ColumnExit.Width = 140;
            // 
            // ColumnReason
            // 
            this.ColumnReason.HeaderText = "Зачем";
            this.ColumnReason.Name = "ColumnReason";
            this.ColumnReason.ReadOnly = true;
            this.ColumnReason.Width = 180;
            // 
            // ColumnActions
            // 
            this.ColumnActions.HeaderText = "Что делал";
            this.ColumnActions.Name = "ColumnActions";
            this.ColumnActions.ReadOnly = true;
            this.ColumnActions.Width = 200;
            // 
            // ColumnNote
            // 
            this.ColumnNote.HeaderText = "Примечание";
            this.ColumnNote.Name = "ColumnNote";
            this.ColumnNote.ReadOnly = true;
            this.ColumnNote.Width = 140;
            // 
            // ColumnStatus
            // 
            this.ColumnStatus.HeaderText = "Статус";
            this.ColumnStatus.Name = "ColumnStatus";
            this.ColumnStatus.ReadOnly = true;
            this.ColumnStatus.Width = 100;
            // 
            // ServerRoomLogForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(1100, 650);
            this.Controls.Add(this.dataGridViewVisits);
            this.Controls.Add(this.panelAdd);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ServerRoomLogForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Журнал посещений серверной";
            this.Load += new System.EventHandler(this.ServerRoomLogForm_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelAdd.ResumeLayout(false);
            this.panelAdd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisits)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Panel panelAdd;
        private System.Windows.Forms.Label labelUser;
        private System.Windows.Forms.TextBox textBoxUser;
        private System.Windows.Forms.Label labelEntry;
        private System.Windows.Forms.DateTimePicker dateTimePickerEntry;
        private System.Windows.Forms.Label labelReason;
        private System.Windows.Forms.TextBox textBoxReason;
        private System.Windows.Forms.Label labelActions;
        private System.Windows.Forms.TextBox textBoxActions;
        private System.Windows.Forms.Label labelNote;
        private System.Windows.Forms.TextBox textBoxNote;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonExitVisit;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.DataGridView dataGridViewVisits;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnEntry;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReason;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnActions;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNote;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnStatus;
    }
}
