"""Лёгкий мониторинг SQL и HTTP-маршрутов для Flask/SQLite."""
from collections import deque
from threading import Lock
from time import perf_counter
from flask import g, request

MAX_SAMPLES = 1000
_samples = deque(maxlen=MAX_SAMPLES)
_lock = Lock()


def record_query(elapsed):
    stats = getattr(g, "sql_perf", None)
    if stats is not None:
        stats["query_count"] += 1
        stats["query_time_ms"] += elapsed * 1000.0


def install_sql_monitor(app):
    @app.before_request
    def _sql_perf_start():
        g.sql_perf = {
            "started": perf_counter(),
            "query_count": 0,
            "query_time_ms": 0.0,
        }

    @app.after_request
    def _sql_perf_finish(response):
        stats = getattr(g, "sql_perf", None)
        if stats is not None:
            elapsed_ms = (perf_counter() - stats["started"]) * 1000.0
            sample = {
                "timestamp": __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "method": request.method,
                "route": request.url_rule.rule if request.url_rule else request.path,
                "endpoint": request.endpoint or "unknown",
                "status": response.status_code,
                "duration_ms": round(elapsed_ms, 2),
                "query_count": stats["query_count"],
                "query_time_ms": round(stats["query_time_ms"], 2),
            }
            # Don't record the monitoring page itself to avoid self-noise.
            if sample["endpoint"] != "admin_performance":
                with _lock:
                    _samples.appendleft(sample)
        return response


def get_performance_snapshot(limit=250):
    with _lock:
        rows = list(_samples)[:max(1, min(int(limit), MAX_SAMPLES))]
    counts = [row["query_count"] for row in rows]
    durations = [row["duration_ms"] for row in rows]
    query_times = [row["query_time_ms"] for row in rows]
    return {
        "samples": rows,
        "total_requests": len(rows),
        "min_queries": min(counts) if counts else 0,
        "max_queries": max(counts) if counts else 0,
        "avg_queries": round(sum(counts) / len(counts), 2) if counts else 0,
        "min_duration_ms": round(min(durations), 2) if durations else 0,
        "max_duration_ms": round(max(durations), 2) if durations else 0,
        "avg_duration_ms": round(sum(durations) / len(durations), 2) if durations else 0,
        "max_sql_time_ms": round(max(query_times), 2) if query_times else 0,
    }
