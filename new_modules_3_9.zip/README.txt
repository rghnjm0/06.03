Остался только модуль п.9 — журнал серверной (авто вход/выход).

Файлы в forms\:
  ServerAccessLogForm.cs
  ServerAccessLogForm.Designer.cs
  NewModulesDb.cs

Кнопки: snippet_buttons_MainAdmin.txt / snippet_buttons_MainWorker.txt
  — одна кнопка «Серверная» после «Отчет по задачам» (ADMIN).

УДАЛИТЬ из проекта, если были:
  WarrantyContractsForm.*
  ContractsForm.*
  ModulesSchema.*
  NewModulesSchema.*
  любые ссылки на WarrantyContractsForm / Договоры
