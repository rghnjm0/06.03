Пункты 3 и 9 — новые модули с ДРУГИМИ именами (не путать со старыми формами).

ФАЙЛЫ (положить в forms\ проекта):
  WarrantyContractsForm.cs          — п.3 Договоры и гарантии
  WarrantyContractsForm.Designer.cs
  ServerAccessLogForm.cs            — п.9 Журнал посещений серверной
  ServerAccessLogForm.Designer.cs
  NewModulesDb.cs                   — таблицы WarrantyContracts и ServerAccessLog

НЕ ПУТАТЬ:
  ContactsForm     = старые КОНТАКТЫ (уже было)
  WarrantyContractsForm = НОВЫЕ договоры/гарантии
  ContractsForm / ModulesSchema / ServerRoomLogForm = старые попытки, можно удалить

В SupportDesk.csproj добавить:
  <Compile Include="forms\WarrantyContractsForm.cs"><SubType>Form</SubType></Compile>
  <Compile Include="forms\WarrantyContractsForm.Designer.cs"><DependentUpon>WarrantyContractsForm.cs</DependentUpon></Compile>
  <Compile Include="forms\ServerAccessLogForm.cs"><SubType>Form</SubType></Compile>
  <Compile Include="forms\ServerAccessLogForm.Designer.cs"><DependentUpon>ServerAccessLogForm.cs</DependentUpon></Compile>
  <Compile Include="forms\NewModulesDb.cs" />

КНОПКИ (MainAdminForm + MainWorkerForm) — см. snippet_buttons.txt

Удалить при конфликте: ContractsForm.*, ServerRoomLogForm.*, ModulesSchema.*, NewModulesSchema.*
