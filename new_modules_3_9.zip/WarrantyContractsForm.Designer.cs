namespace SupportDesk.forms
{
    partial class WarrantyContractsForm
    {
        private void InitializeComponent()
        {
        }
    }
}
