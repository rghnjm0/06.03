using System.Data.SQLite;
using System.Threading.Tasks;

namespace SupportDesk.forms
{
    // Таблицы только для пунктов 3 и 9 — имена не пересекаются со старыми Contacts / Inventory
    internal static class Table_warrantyContracts
    {
        public static string main = "WarrantyContracts";
        public static string equipment = "equipment";
        public static string invNum = "invNum";
        public static string supplier = "supplier";
        public static string contractNumber = "contractNumber";
        public static string contractDate = "contractDate";
        public static string warrantyUntil = "warrantyUntil";
        public static string supportUntil = "supportUntil";
        public static string comment = "comment";
    }

    internal static class Table_serverAccess
    {
        public static string main = "ServerAccessLog";
        public static string visitDate = "visitDate";
        public static string visitTime = "visitTime";
        public static string visitor = "visitor";
        public static string purpose = "purpose";
        public static string actions = "actions";
        public static string accompaniedBy = "accompaniedBy";
    }

    public static class NewModulesDb
    {
        public static async Task EnsureAsync(SQLiteConnection db)
        {
            if (db == null)
            {
                return;
            }
            using (SQLiteCommand command = new SQLiteCommand(@"
CREATE TABLE IF NOT EXISTS WarrantyContracts (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    equipment TEXT NOT NULL,
    invNum TEXT,
    supplier TEXT NOT NULL,
    contractNumber TEXT NOT NULL,
    contractDate TEXT,
    warrantyUntil TEXT,
    supportUntil TEXT,
    comment TEXT
);
CREATE TABLE IF NOT EXISTS ServerAccessLog (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    visitDate TEXT NOT NULL,
    visitTime TEXT NOT NULL,
    visitor TEXT NOT NULL,
    purpose TEXT NOT NULL,
    actions TEXT,
    accompaniedBy TEXT
);", db))
            {
                await command.ExecuteNonQueryAsync();
            }
        }
    }
}
