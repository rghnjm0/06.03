using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace SupportDesk.forms
{
    internal static class Table_serverAccess
    {
        public static string main = "ServerAccessLog";
        public static string visitDate = "visitDate";
        public static string visitTime = "visitTime";
        public static string visitor = "visitor";
        public static string purpose = "purpose";
        public static string actions = "actions";
        public static string accompaniedBy = "accompaniedBy";
    }

    public static class NewModulesDb
    {
        private static string _openSessionId;
        private static string _openSessionVisitor;
        private static DateTime _openSessionStart;

        public static async Task EnsureAsync(SQLiteConnection db)
        {
            if (db == null) return;
            using (SQLiteCommand command = new SQLiteCommand(@"
CREATE TABLE IF NOT EXISTS ServerAccessLog (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    visitDate TEXT NOT NULL,
    visitTime TEXT NOT NULL,
    visitor TEXT NOT NULL,
    purpose TEXT NOT NULL,
    actions TEXT,
    accompaniedBy TEXT
);", db))
            {
                await command.ExecuteNonQueryAsync();
            }
        }

        public static async Task WriteServerVisitAsync(string visitor, string purpose, string actions = "", string accompaniedBy = "")
        {
            if (string.IsNullOrWhiteSpace(visitor)) visitor = DataUsers.Initials ?? "Неизвестно";
            if (string.IsNullOrWhiteSpace(purpose)) purpose = "Событие";

            using (SQLiteConnection db = new SQLiteConnection(Database.connectionString))
            {
                await db.OpenAsync();
                await EnsureAsync(db);
                DateTime now = DateTime.Now;
                using (SQLiteCommand command = new SQLiteCommand(
                    $"INSERT INTO {Table_serverAccess.main} ({Table_serverAccess.visitDate}, {Table_serverAccess.visitTime}, {Table_serverAccess.visitor}, {Table_serverAccess.purpose}, {Table_serverAccess.actions}, {Table_serverAccess.accompaniedBy}) VALUES (@d, @t, @v, @p, @a, @c)", db))
                {
                    command.Parameters.AddWithValue("d", now.ToString("dd.MM.yyyy"));
                    command.Parameters.AddWithValue("t", now.ToString("HH:mm:ss"));
                    command.Parameters.AddWithValue("v", visitor.Trim());
                    command.Parameters.AddWithValue("p", purpose.Trim());
                    command.Parameters.AddWithValue("a", (actions ?? "").Trim());
                    command.Parameters.AddWithValue("c", (accompaniedBy ?? "").Trim());
                    await command.ExecuteNonQueryAsync();
                }
                try
                {
                    File.AppendAllText(Logs.file, $"[Серверная]{visitor} | {purpose} | {actions} | {accompaniedBy} ({now:dd.MM.yyyy HH:mm:ss}){Environment.NewLine}");
                }
                catch { }
            }
        }

        /// <summary>
        /// Собирает из заявок, чем сейчас занят сотрудник (для примечания).
        /// </summary>
        public static async Task<string> BuildWorkNoteAsync(string visitor)
        {
            if (string.IsNullOrWhiteSpace(visitor)) visitor = DataUsers.Initials ?? "";
            var lines = new List<string>();

            try
            {
                using (SQLiteConnection db = new SQLiteConnection(Database.connectionString))
                {
                    await db.OpenAsync();

                    // Заявки «в работе» у этого исполнителя
                    using (SQLiteCommand cmd = new SQLiteCommand(@"
SELECT tema, typeProblem, status, kabinet, discription
FROM Requests
WHERE (executor = @v OR executor2 = @v)
  AND (status = 'В работе' OR status = 'Новая' OR status = 'На подтверждении')
ORDER BY ID DESC
LIMIT 8", db))
                    {
                        cmd.Parameters.AddWithValue("v", visitor);
                        using (SQLiteDataReader r = (SQLiteDataReader)await cmd.ExecuteReaderAsync())
                        {
                            while (await r.ReadAsync())
                            {
                                string tema = Convert.ToString(r["tema"]);
                                string type = Convert.ToString(r["typeProblem"]);
                                string status = Convert.ToString(r["status"]);
                                string kab = Convert.ToString(r["kabinet"]);
                                string disc = Convert.ToString(r["discription"]);
                                if (!string.IsNullOrEmpty(disc) && disc.Length > 60)
                                    disc = disc.Substring(0, 60) + "…";
                                lines.Add($"{status}: [{type}] {tema} (каб. {kab})" + (string.IsNullOrEmpty(disc) ? "" : $" — {disc}"));
                            }
                        }
                    }

                    // Недавно выполненные сегодня (что успел сделать)
                    using (SQLiteCommand cmd = new SQLiteCommand(@"
SELECT tema, typeProblem, status, result
FROM Requests
WHERE (executor = @v OR executor2 = @v)
  AND (status = 'Выполнена' OR status = 'Не выполнена')
  AND theDate LIKE @today
ORDER BY ID DESC
LIMIT 5", db))
                    {
                        cmd.Parameters.AddWithValue("v", visitor);
                        cmd.Parameters.AddWithValue("today", DateTime.Now.ToString("dd.MM.yyyy") + "%");
                        // theDate format may vary — also try without filter if empty
                        using (SQLiteDataReader r = (SQLiteDataReader)await cmd.ExecuteReaderAsync())
                        {
                            while (await r.ReadAsync())
                            {
                                string tema = Convert.ToString(r["tema"]);
                                string type = Convert.ToString(r["typeProblem"]);
                                string status = Convert.ToString(r["status"]);
                                string result = Convert.ToString(r["result"]);
                                if (!string.IsNullOrEmpty(result) && result.Length > 50)
                                    result = result.Substring(0, 50) + "…";
                                string line = $"Сегодня {status}: [{type}] {tema}";
                                if (!string.IsNullOrEmpty(result)) line += $" → {result}";
                                if (!lines.Contains(line)) lines.Add(line);
                            }
                        }
                    }
                }
            }
            catch
            {
                // заявки недоступны — не ломаем журнал
            }

            if (lines.Count == 0)
            {
                return "Активных заявок нет / не назначены";
            }

            var sb = new StringBuilder();
            for (int i = 0; i < lines.Count; i++)
            {
                if (i > 0) sb.Append("; ");
                sb.Append(lines[i]);
            }
            string note = sb.ToString();
            if (note.Length > 500) note = note.Substring(0, 500) + "…";
            return note;
        }

        public static async Task AutoEnterAsync(string reason = "Открытие журнала серверной")
        {
            string who = DataUsers.Initials ?? "Неизвестно";
            if (_openSessionVisitor == who && !string.IsNullOrEmpty(_openSessionId)) return;

            _openSessionId = Guid.NewGuid().ToString("N").Substring(0, 8);
            _openSessionVisitor = who;
            _openSessionStart = DateTime.Now;

            string work = await BuildWorkNoteAsync(who);
            // actions = детали сессии, accompaniedBy = что делает (заявки)
            await WriteServerVisitAsync(
                who,
                "ВХОД",
                $"Сессия {_openSessionId}. {reason}",
                work);
        }

        public static async Task AutoExitAsync(string reason = "Закрытие журнала серверной")
        {
            string who = DataUsers.Initials ?? "Неизвестно";
            string details = reason;
            if (!string.IsNullOrEmpty(_openSessionId) && _openSessionVisitor == who)
            {
                TimeSpan dur = DateTime.Now - _openSessionStart;
                details = $"Сессия {_openSessionId}. В серверной: {FormatDuration(dur)}. {reason}";
                _openSessionId = null;
                _openSessionVisitor = null;
            }

            string work = await BuildWorkNoteAsync(who);
            await WriteServerVisitAsync(who, "ВЫХОД", details, work);
        }

        public static async Task AutoActionAsync(string actionDescription)
        {
            string who = DataUsers.Initials ?? "Неизвестно";
            string session = string.IsNullOrEmpty(_openSessionId) ? "" : $"Сессия {_openSessionId}. ";
            string work = await BuildWorkNoteAsync(who);
            await WriteServerVisitAsync(who, "ДЕЙСТВИЕ", session + (actionDescription ?? ""), work);
        }

        public static Task WriteFromServerTicketAsync(string statusOrAction, string ticketTema = "")
        {
            string text = string.IsNullOrWhiteSpace(ticketTema) ? statusOrAction : $"{statusOrAction}: {ticketTema}";
            return AutoActionAsync("Заявка — " + text);
        }

        private static string FormatDuration(TimeSpan t)
        {
            if (t.TotalHours >= 1) return $"{(int)t.TotalHours} ч {t.Minutes} мин";
            if (t.TotalMinutes >= 1) return $"{(int)t.TotalMinutes} мин {t.Seconds} сек";
            return $"{t.Seconds} сек";
        }
    }
}
