using System;
using System.Data.SQLite;
using System.IO;
using System.Threading.Tasks;

namespace SupportDesk.forms
{
    internal static class Table_warrantyContracts
    {
        public static string main = "WarrantyContracts";
        public static string equipment = "equipment";
        public static string invNum = "invNum";
        public static string supplier = "supplier";
        public static string contractNumber = "contractNumber";
        public static string contractDate = "contractDate";
        public static string warrantyUntil = "warrantyUntil";
        public static string supportUntil = "supportUntil";
        public static string comment = "comment";
    }

    internal static class Table_serverAccess
    {
        public static string main = "ServerAccessLog";
        public static string visitDate = "visitDate";
        public static string visitTime = "visitTime";
        public static string visitor = "visitor";
        public static string purpose = "purpose";
        public static string actions = "actions";
        public static string accompaniedBy = "accompaniedBy";
    }

    /// <summary>
    /// Создание таблиц + автоматическая запись визитов в серверную.
    /// </summary>
    public static class NewModulesDb
    {
        /// <summary>Не писать повторный «вход», если тот же человек уже записан за последние N минут.</summary>
        public const int MinMinutesBetweenSameVisit = 15;

        public static async Task EnsureAsync(SQLiteConnection db)
        {
            if (db == null)
            {
                return;
            }
            using (SQLiteCommand command = new SQLiteCommand(@"
CREATE TABLE IF NOT EXISTS WarrantyContracts (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    equipment TEXT NOT NULL,
    invNum TEXT,
    supplier TEXT NOT NULL,
    contractNumber TEXT NOT NULL,
    contractDate TEXT,
    warrantyUntil TEXT,
    supportUntil TEXT,
    comment TEXT
);
CREATE TABLE IF NOT EXISTS ServerAccessLog (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    visitDate TEXT NOT NULL,
    visitTime TEXT NOT NULL,
    visitor TEXT NOT NULL,
    purpose TEXT NOT NULL,
    actions TEXT,
    accompaniedBy TEXT
);", db))
            {
                await command.ExecuteNonQueryAsync();
            }
        }

        /// <summary>
        /// Автозапись визита. Вызывай из форм/событий — без ручного ввода.
        /// </summary>
        public static async Task WriteServerVisitAsync(
            string visitor,
            string purpose,
            string actions = "",
            string accompaniedBy = "",
            bool skipIfRecentDuplicate = true)
        {
            if (string.IsNullOrWhiteSpace(visitor))
            {
                visitor = DataUsers.Initials ?? "Неизвестно";
            }
            if (string.IsNullOrWhiteSpace(purpose))
            {
                purpose = "Автофиксация";
            }

            using (SQLiteConnection db = new SQLiteConnection(Database.connectionString))
            {
                await db.OpenAsync();
                await EnsureAsync(db);

                if (skipIfRecentDuplicate && await HasRecentVisitAsync(db, visitor, purpose))
                {
                    return;
                }

                DateTime now = DateTime.Now;
                using (SQLiteCommand command = new SQLiteCommand(
                    $"INSERT INTO {Table_serverAccess.main} ({Table_serverAccess.visitDate}, {Table_serverAccess.visitTime}, {Table_serverAccess.visitor}, {Table_serverAccess.purpose}, {Table_serverAccess.actions}, {Table_serverAccess.accompaniedBy}) VALUES (@d, @t, @v, @p, @a, @c)", db))
                {
                    command.Parameters.AddWithValue("d", now.ToString("dd.MM.yyyy"));
                    command.Parameters.AddWithValue("t", now.ToString("HH:mm:ss"));
                    command.Parameters.AddWithValue("v", visitor.Trim());
                    command.Parameters.AddWithValue("p", purpose.Trim());
                    command.Parameters.AddWithValue("a", (actions ?? "").Trim());
                    command.Parameters.AddWithValue("c", (accompaniedBy ?? "").Trim());
                    await command.ExecuteNonQueryAsync();
                }

                try
                {
                    File.AppendAllText(Logs.file, $"[Серверная-АВТО]{visitor} | {purpose} | {actions} ({now:dd.MM.yyyy HH:mm:ss}){Environment.NewLine}");
                }
                catch
                {
                    // лог не критичен
                }
            }
        }

        private static async Task<bool> HasRecentVisitAsync(SQLiteConnection db, string visitor, string purpose)
        {
            using (SQLiteCommand command = new SQLiteCommand(
                $"SELECT {Table_serverAccess.visitDate}, {Table_serverAccess.visitTime} FROM {Table_serverAccess.main} WHERE {Table_serverAccess.visitor} = @v AND {Table_serverAccess.purpose} = @p ORDER BY ID DESC LIMIT 1", db))
            {
                command.Parameters.AddWithValue("v", visitor.Trim());
                command.Parameters.AddWithValue("p", purpose.Trim());
                using (SQLiteDataReader reader = (SQLiteDataReader)await command.ExecuteReaderAsync())
                {
                    if (!await reader.ReadAsync())
                    {
                        return false;
                    }
                    string d = reader[Table_serverAccess.visitDate].ToString();
                    string t = reader[Table_serverAccess.visitTime].ToString();
                    DateTime parsed;
                    if (DateTime.TryParse($"{d} {t}", out parsed))
                    {
                        return (DateTime.Now - parsed).TotalMinutes < MinMinutesBetweenSameVisit;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Автофиксация при работе с заявкой типа «Сервер».
        /// Вызови при смене статуса / назначении исполнителя.
        /// </summary>
        public static Task WriteFromServerTicketAsync(string statusOrAction, string ticketTema = "")
        {
            string who = DataUsers.Initials ?? "Система";
            string purpose = "Заявка по серверу";
            string actions = string.IsNullOrWhiteSpace(ticketTema)
                ? statusOrAction
                : $"{statusOrAction}: {ticketTema}";
            return WriteServerVisitAsync(who, purpose, actions, "", true);
        }
    }
}
