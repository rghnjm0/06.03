using System;
using System.Data.SQLite;
using System.IO;
using System.Threading.Tasks;

namespace SupportDesk.forms
{
    internal static class Table_serverAccess
    {
        public static string main = "ServerAccessLog";
        public static string visitDate = "visitDate";
        public static string visitTime = "visitTime";
        public static string visitor = "visitor";
        public static string purpose = "purpose";
        public static string actions = "actions";
        public static string accompaniedBy = "accompaniedBy";
    }

    public static class NewModulesDb
    {
        private static string _openSessionId;
        private static string _openSessionVisitor;
        private static DateTime _openSessionStart;

        public static async Task EnsureAsync(SQLiteConnection db)
        {
            if (db == null) return;
            using (SQLiteCommand command = new SQLiteCommand(@"
CREATE TABLE IF NOT EXISTS ServerAccessLog (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    visitDate TEXT NOT NULL,
    visitTime TEXT NOT NULL,
    visitor TEXT NOT NULL,
    purpose TEXT NOT NULL,
    actions TEXT,
    accompaniedBy TEXT
);", db))
            {
                await command.ExecuteNonQueryAsync();
            }
        }

        public static async Task WriteServerVisitAsync(string visitor, string purpose, string actions = "", string accompaniedBy = "")
        {
            if (string.IsNullOrWhiteSpace(visitor)) visitor = DataUsers.Initials ?? "Неизвестно";
            if (string.IsNullOrWhiteSpace(purpose)) purpose = "Событие";

            using (SQLiteConnection db = new SQLiteConnection(Database.connectionString))
            {
                await db.OpenAsync();
                await EnsureAsync(db);
                DateTime now = DateTime.Now;
                using (SQLiteCommand command = new SQLiteCommand(
                    $"INSERT INTO {Table_serverAccess.main} ({Table_serverAccess.visitDate}, {Table_serverAccess.visitTime}, {Table_serverAccess.visitor}, {Table_serverAccess.purpose}, {Table_serverAccess.actions}, {Table_serverAccess.accompaniedBy}) VALUES (@d, @t, @v, @p, @a, @c)", db))
                {
                    command.Parameters.AddWithValue("d", now.ToString("dd.MM.yyyy"));
                    command.Parameters.AddWithValue("t", now.ToString("HH:mm:ss"));
                    command.Parameters.AddWithValue("v", visitor.Trim());
                    command.Parameters.AddWithValue("p", purpose.Trim());
                    command.Parameters.AddWithValue("a", (actions ?? "").Trim());
                    command.Parameters.AddWithValue("c", (accompaniedBy ?? "").Trim());
                    await command.ExecuteNonQueryAsync();
                }
                try
                {
                    File.AppendAllText(Logs.file, $"[Серверная]{visitor} | {purpose} | {actions} ({now:dd.MM.yyyy HH:mm:ss}){Environment.NewLine}");
                }
                catch { }
            }
        }

        public static async Task AutoEnterAsync(string reason = "Открыт журнал / учёт в системе")
        {
            string who = DataUsers.Initials ?? "Неизвестно";
            if (_openSessionVisitor == who && !string.IsNullOrEmpty(_openSessionId)) return;

            _openSessionId = Guid.NewGuid().ToString("N").Substring(0, 8);
            _openSessionVisitor = who;
            _openSessionStart = DateTime.Now;
            await WriteServerVisitAsync(who, "ВХОД", $"Сессия {_openSessionId}. {reason}");
        }

        public static async Task AutoExitAsync(string reason = "Закрыт журнал / выход из учёта")
        {
            string who = DataUsers.Initials ?? "Неизвестно";
            string details = reason;
            if (!string.IsNullOrEmpty(_openSessionId) && _openSessionVisitor == who)
            {
                TimeSpan dur = DateTime.Now - _openSessionStart;
                details = $"Сессия {_openSessionId}. В серверной: {FormatDuration(dur)}. {reason}";
                _openSessionId = null;
                _openSessionVisitor = null;
            }
            await WriteServerVisitAsync(who, "ВЫХОД", details);
        }

        public static Task AutoActionAsync(string actionDescription)
        {
            string who = DataUsers.Initials ?? "Неизвестно";
            string session = string.IsNullOrEmpty(_openSessionId) ? "" : $"Сессия {_openSessionId}. ";
            return WriteServerVisitAsync(who, "ДЕЙСТВИЕ", session + (actionDescription ?? ""));
        }

        public static Task WriteFromServerTicketAsync(string statusOrAction, string ticketTema = "")
        {
            string text = string.IsNullOrWhiteSpace(ticketTema) ? statusOrAction : $"{statusOrAction}: {ticketTema}";
            return AutoActionAsync("Заявка «Сервер» — " + text);
        }

        private static string FormatDuration(TimeSpan t)
        {
            if (t.TotalHours >= 1) return $"{(int)t.TotalHours} ч {t.Minutes} мин";
            if (t.TotalMinutes >= 1) return $"{(int)t.TotalMinutes} мин {t.Seconds} сек";
            return $"{t.Seconds} сек";
        }
    }
}
