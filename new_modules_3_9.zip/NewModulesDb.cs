using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace SupportDesk.forms
{
    internal static class Table_serverAccess
    {
        public static string main = "ServerRoomVisits";
        public static string visitor = "visitor";
        public static string enterDate = "enterDate";
        public static string enterTime = "enterTime";
        public static string exitTime = "exitTime";
        public static string note = "note";
    }

    /// <summary>
    /// Журнал смены: запись при ВХОДЕ в программу, выход при ВЫХОДЕ из аккаунта.
    /// Модуль «Серверная» только показывает таблицу.
    /// </summary>
    public static class NewModulesDb
    {
        private static long _openRowId = -1;
        private static string _openVisitor;

        public static async Task EnsureAsync(SQLiteConnection db)
        {
            if (db == null) return;
            using (SQLiteCommand command = new SQLiteCommand(@"
CREATE TABLE IF NOT EXISTS ServerRoomVisits (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    visitor TEXT NOT NULL,
    enterDate TEXT NOT NULL,
    enterTime TEXT NOT NULL,
    exitTime TEXT,
    note TEXT
);", db))
            {
                await command.ExecuteNonQueryAsync();
            }
        }

        public static async Task<string> BuildWorkNoteAsync(string visitor)
        {
            if (string.IsNullOrWhiteSpace(visitor)) visitor = DataUsers.Initials ?? "";
            var lines = new List<string>();
            try
            {
                using (SQLiteConnection db = new SQLiteConnection(Database.connectionString))
                {
                    await db.OpenAsync();
                    using (SQLiteCommand cmd = new SQLiteCommand(@"
SELECT tema, typeProblem, status, kabinet, discription
FROM Requests
WHERE (executor = @v OR executor2 = @v)
  AND (status = 'В работе' OR status = 'Новая' OR status = 'На подтверждении')
ORDER BY ID DESC LIMIT 8", db))
                    {
                        cmd.Parameters.AddWithValue("v", visitor);
                        using (SQLiteDataReader r = (SQLiteDataReader)await cmd.ExecuteReaderAsync())
                        {
                            while (await r.ReadAsync())
                            {
                                string tema = Convert.ToString(r["tema"]);
                                string type = Convert.ToString(r["typeProblem"]);
                                string status = Convert.ToString(r["status"]);
                                string kab = Convert.ToString(r["kabinet"]);
                                string disc = Convert.ToString(r["discription"]);
                                if (!string.IsNullOrEmpty(disc) && disc.Length > 50)
                                    disc = disc.Substring(0, 50) + "…";
                                lines.Add($"{status}: [{type}] {tema} (каб. {kab})" + (string.IsNullOrEmpty(disc) ? "" : " — " + disc));
                            }
                        }
                    }
                }
            }
            catch { }

            if (lines.Count == 0) return "Активных заявок нет";
            var sb = new StringBuilder();
            for (int i = 0; i < lines.Count; i++)
            {
                if (i > 0) sb.Append("; ");
                sb.Append(lines[i]);
            }
            string note = sb.ToString();
            if (note.Length > 500) note = note.Substring(0, 500) + "…";
            return note;
        }

        /// <summary>Вызывать из MainAdminForm_Load / MainWorkerForm_Load после логина.</summary>
        public static async Task AutoEnterOnLoginAsync()
        {
            string who = DataUsers.Initials ?? "Неизвестно";
            if (string.IsNullOrWhiteSpace(who)) who = "Неизвестно";

            // уже записан вход этой сессии
            if (_openRowId > 0 && _openVisitor == who) return;

            string note = await BuildWorkNoteAsync(who);
            DateTime now = DateTime.Now;

            using (SQLiteConnection db = new SQLiteConnection(Database.connectionString))
            {
                await db.OpenAsync();
                await EnsureAsync(db);

                // закрыть хвосты без выхода (программа убита в прошлый раз)
                using (SQLiteCommand fix = new SQLiteCommand(
                    $"UPDATE {Table_serverAccess.main} SET {Table_serverAccess.exitTime}=@t WHERE {Table_serverAccess.visitor}=@v AND ({Table_serverAccess.exitTime} IS NULL OR {Table_serverAccess.exitTime}='')", db))
                {
                    fix.Parameters.AddWithValue("t", now.ToString("HH:mm:ss"));
                    fix.Parameters.AddWithValue("v", who);
                    await fix.ExecuteNonQueryAsync();
                }

                using (SQLiteCommand command = new SQLiteCommand(
                    $"INSERT INTO {Table_serverAccess.main} ({Table_serverAccess.visitor}, {Table_serverAccess.enterDate}, {Table_serverAccess.enterTime}, {Table_serverAccess.exitTime}, {Table_serverAccess.note}) VALUES (@v, @ed, @et, '', @n)", db))
                {
                    command.Parameters.AddWithValue("v", who);
                    command.Parameters.AddWithValue("ed", now.ToString("dd.MM.yyyy"));
                    command.Parameters.AddWithValue("et", now.ToString("HH:mm:ss"));
                    command.Parameters.AddWithValue("n", note ?? "");
                    await command.ExecuteNonQueryAsync();
                }

                using (SQLiteCommand idCmd = new SQLiteCommand("SELECT last_insert_rowid()", db))
                {
                    _openRowId = Convert.ToInt64(await idCmd.ExecuteScalarAsync());
                    _openVisitor = who;
                }
            }

            try { File.AppendAllText(Logs.file, $"[Журнал]Вход в программу {who} {now:dd.MM.yyyy HH:mm:ss} | {note}{Environment.NewLine}"); } catch { }
        }

        /// <summary>Вызывать из ExpUIButtonIconLogout_Click перед очисткой DataUsers.</summary>
        public static async Task AutoExitOnLogoutAsync()
        {
            string who = DataUsers.Initials ?? _openVisitor ?? "Неизвестно";
            string note = await BuildWorkNoteAsync(who);
            DateTime now = DateTime.Now;
            string exitT = now.ToString("HH:mm:ss");

            using (SQLiteConnection db = new SQLiteConnection(Database.connectionString))
            {
                await db.OpenAsync();
                await EnsureAsync(db);

                int updated = 0;
                if (_openRowId > 0)
                {
                    using (SQLiteCommand command = new SQLiteCommand(
                        $"UPDATE {Table_serverAccess.main} SET {Table_serverAccess.exitTime}=@t, {Table_serverAccess.note}=@n WHERE ID=@id", db))
                    {
                        command.Parameters.AddWithValue("t", exitT);
                        command.Parameters.AddWithValue("n", note ?? "");
                        command.Parameters.AddWithValue("id", _openRowId);
                        updated = await command.ExecuteNonQueryAsync();
                    }
                }

                if (updated == 0)
                {
                    using (SQLiteCommand command = new SQLiteCommand(
                        $"UPDATE {Table_serverAccess.main} SET {Table_serverAccess.exitTime}=@t, {Table_serverAccess.note}=@n WHERE ID = (SELECT MAX(ID) FROM {Table_serverAccess.main} WHERE {Table_serverAccess.visitor}=@v AND ({Table_serverAccess.exitTime} IS NULL OR {Table_serverAccess.exitTime}=''))", db))
                    {
                        command.Parameters.AddWithValue("t", exitT);
                        command.Parameters.AddWithValue("n", note ?? "");
                        command.Parameters.AddWithValue("v", who);
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }

            _openRowId = -1;
            _openVisitor = null;
            try { File.AppendAllText(Logs.file, $"[Журнал]Выход из программы {who} {exitT} | {note}{Environment.NewLine}"); } catch { }
        }
    }
}
