using System;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    /// <summary>
    /// При открытии модуля — пишет ВХОД (время входа).
    /// При закрытии — пишет ВЫХОД (время выхода в ту же строку).
    /// Таблица: кто | вход | выход | что делал.
    /// </summary>
    public partial class ServerAccessLogForm : Form
    {
        private SQLiteConnection DB;
        private DataGridView grid;
        private Label statusLabel;
        private bool sessionMarked;

        public ServerAccessLogForm()
        {
            InitializeComponent();
            Text = "Журнал посещений";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1000, 560);
            BackColor = Color.FromArgb(24, 28, 36);
            ForeColor = Color.White;
            Font = new Font("Arial", 10);

            Label title = new Label
            {
                Text = "Журнал серверной",
                Font = new Font("Arial", 15, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 12),
                AutoSize = true
            };
            Controls.Add(title);
            title.MouseDown += Drag;

            Button close = MakeButton("Закрыть", 880, 12, 100, 32);
            close.Click += (s, e) => ReturnBack();
            Controls.Add(close);

            statusLabel = new Label
            {
                Text = "Загрузка…",
                Location = new Point(20, 48),
                Size = new Size(900, 22),
                ForeColor = Color.LightGreen
            };
            Controls.Add(statusLabel);

            grid = new DataGridView
            {
                Location = new Point(20, 80),
                Size = new Size(960, 400),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.FromArgb(36, 42, 54),
                BorderStyle = BorderStyle.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            grid.Columns.Add("id", "ID");
            grid.Columns.Add("visitor", "Кто");
            grid.Columns.Add("enterDate", "Дата входа");
            grid.Columns.Add("enterTime", "Время входа");
            grid.Columns.Add("exitDate", "Дата выхода");
            grid.Columns.Add("exitTime", "Время выхода");
            grid.Columns.Add("note", "Что делал");
            grid.Columns["id"].Visible = false;
            Controls.Add(grid);

            Button refresh = MakeButton("Обновить", 20, 500, 140, 36);
            refresh.Click += (s, e) => LoadRows();
            Button del = MakeButton("Удалить (ADMIN)", 170, 500, 160, 36);
            del.Click += async (s, e) => await DeleteRow();
            Controls.Add(refresh);
            Controls.Add(del);

            Load += async (s, e) =>
            {
                try
                {
                    DB = new SQLiteConnection(Database.connectionString);
                    await DB.OpenAsync();
                    await NewModulesDb.EnsureAsync(DB);

                    // как раньше: зашёл в модуль → сразу запись входа
                    await NewModulesDb.AutoEnterAsync("Открыт модуль «Серверная»");
                    sessionMarked = true;

                    statusLabel.Text = $"Вход зафиксирован: {DataUsers.Initials}  {DateTime.Now:dd.MM.yyyy HH:mm:ss}";
                    LoadRows();
                }
                catch (Exception ex)
                {
                    statusLabel.ForeColor = Color.OrangeRed;
                    statusLabel.Text = "Ошибка записи: " + ex.Message;
                    MessageBoxUI.Show(ex.Message, "Журнал", "Error");
                }
            };

            FormClosing += async (s, e) =>
            {
                if (!sessionMarked) return;
                try
                {
                    await NewModulesDb.AutoExitAsync("Закрыт модуль «Серверная»");
                    sessionMarked = false;
                }
                catch { }
            };

            MouseDown += Drag;
        }

        private Button MakeButton(string text, int x, int y, int w, int h)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w, h),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(0, 116, 228),
                ForeColor = Color.White
            };
        }

        private async void LoadRows()
        {
            if (DB == null) return;
            grid.Rows.Clear();
            SQLiteCommand command = new SQLiteCommand(
                $"SELECT * FROM [{Table_serverAccess.main}] ORDER BY ID DESC", DB);
            SQLiteDataReader reader = null;
            try
            {
                reader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    string exitT = Convert.ToString(reader[Table_serverAccess.exitTime]);
                    int row = grid.Rows.Add(
                        reader["ID"].ToString(),
                        reader[Table_serverAccess.visitor].ToString(),
                        reader[Table_serverAccess.enterDate].ToString(),
                        reader[Table_serverAccess.enterTime].ToString(),
                        Convert.ToString(reader[Table_serverAccess.exitDate]),
                        exitT,
                        Convert.ToString(reader[Table_serverAccess.note]));

                    if (string.IsNullOrEmpty(exitT))
                        grid.Rows[row].DefaultCellStyle.BackColor = Color.FromArgb(40, 80, 40);
                    else
                        grid.Rows[row].DefaultCellStyle.BackColor = Color.FromArgb(50, 50, 60);
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Журнал", "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private async System.Threading.Tasks.Task DeleteRow()
        {
            if (DataUsers.GroupUser != "ADMIN")
            {
                MessageBoxUI.Show("Удалять может только ADMIN.", "Журнал", "Error");
                return;
            }
            if (grid.SelectedRows.Count == 0) return;
            string id = grid.SelectedRows[0].Cells["id"].Value.ToString();
            SQLiteCommand command = new SQLiteCommand($"DELETE FROM {Table_serverAccess.main} WHERE ID = @id", DB);
            command.Parameters.AddWithValue("id", id);
            await command.ExecuteNonQueryAsync();
            LoadRows();
        }

        private void ReturnBack()
        {
            Form next = DataUsers.GroupUser == "ADMIN" ? (Form)new MainAdminForm() : new MainWorkerForm();
            next.Show();
            next.FormClosed += (s, e) => Close();
            Hide();
        }

        private void Drag(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Capture = false;
                Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero);
                WndProc(ref m);
            }
        }
    }
}
