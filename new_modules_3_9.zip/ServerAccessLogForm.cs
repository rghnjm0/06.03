using System;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    public partial class ServerAccessLogForm : Form
    {
        private SQLiteConnection DB;
        private DataGridView grid;
        private Label statusLabel;
        private bool sessionActive;

        public ServerAccessLogForm()
        {
            InitializeComponent();
            Text = "Журнал посещений серверной";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1000, 580);
            BackColor = Color.FromArgb(24, 28, 36);
            ForeColor = Color.White;
            Font = new Font("Arial", 10);

            Label title = new Label
            {
                Text = "Журнал серверной — вход / выход автоматически",
                Font = new Font("Arial", 15, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 12),
                AutoSize = true
            };
            Controls.Add(title);
            title.MouseDown += Drag;

            Button close = MakeButton("Закрыть", 880, 12, 100, 32);
            close.Click += (s, e) => ReturnBack();
            Controls.Add(close);

            statusLabel = new Label
            {
                Text = "Загрузка…",
                Location = new Point(20, 48),
                Size = new Size(900, 22),
                ForeColor = Color.LightGreen
            };
            Controls.Add(statusLabel);

            grid = new DataGridView
            {
                Location = new Point(20, 80),
                Size = new Size(960, 420),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.FromArgb(36, 42, 54),
                BorderStyle = BorderStyle.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            grid.Columns.Add("id", "ID");
            grid.Columns.Add("visitDate", "Дата");
            grid.Columns.Add("visitTime", "Время");
            grid.Columns.Add("visitor", "Кто");
            grid.Columns.Add("purpose", "Событие");
            grid.Columns.Add("actions", "Детали");
            grid.Columns.Add("accompanied", "Примечание");
            grid.Columns["id"].Visible = false;
            Controls.Add(grid);

            Button refresh = MakeButton("Обновить", 20, 520, 140, 36);
            refresh.Click += (s, e) => LoadRows();
            Button del = MakeButton("Удалить запись (ADMIN)", 170, 520, 200, 36);
            del.Click += async (s, e) => await DeleteRow();
            Controls.Add(refresh);
            Controls.Add(del);

            Load += async (s, e) =>
            {
                DB = new SQLiteConnection(Database.connectionString);
                await DB.OpenAsync();
                await NewModulesDb.EnsureAsync(DB);
                await NewModulesDb.AutoEnterAsync("Открытие журнала серверной в Support Desk");
                sessionActive = true;
                statusLabel.Text = $"Сейчас в учёте: {DataUsers.Initials}  |  вход {DateTime.Now:dd.MM.yyyy HH:mm:ss}  |  все записи хранятся в базе";
                LoadRows();
            };

            FormClosing += async (s, e) =>
            {
                if (!sessionActive) return;
                try
                {
                    await NewModulesDb.AutoExitAsync("Закрытие журнала серверной");
                    sessionActive = false;
                }
                catch { }
            };

            MouseDown += Drag;
        }

        private Button MakeButton(string text, int x, int y, int w, int h)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w, h),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(0, 116, 228),
                ForeColor = Color.White
            };
        }

        private async void LoadRows()
        {
            grid.Rows.Clear();
            SQLiteCommand command = new SQLiteCommand($"SELECT * FROM [{Table_serverAccess.main}] ORDER BY ID DESC", DB);
            SQLiteDataReader reader = null;
            try
            {
                reader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    int row = grid.Rows.Add(
                        reader["ID"].ToString(),
                        reader[Table_serverAccess.visitDate].ToString(),
                        reader[Table_serverAccess.visitTime].ToString(),
                        reader[Table_serverAccess.visitor].ToString(),
                        reader[Table_serverAccess.purpose].ToString(),
                        reader[Table_serverAccess.actions].ToString(),
                        reader[Table_serverAccess.accompaniedBy].ToString());

                    string purpose = reader[Table_serverAccess.purpose].ToString();
                    if (purpose == "ВХОД")
                        grid.Rows[row].DefaultCellStyle.BackColor = Color.FromArgb(40, 80, 40);
                    else if (purpose == "ВЫХОД")
                        grid.Rows[row].DefaultCellStyle.BackColor = Color.FromArgb(80, 40, 40);
                    else if (purpose == "ДЕЙСТВИЕ")
                        grid.Rows[row].DefaultCellStyle.BackColor = Color.FromArgb(40, 50, 80);
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Серверная", "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private async System.Threading.Tasks.Task DeleteRow()
        {
            if (DataUsers.GroupUser != "ADMIN")
            {
                MessageBoxUI.Show("Удалять записи может только ADMIN.", "Серверная", "Error");
                return;
            }
            if (grid.SelectedRows.Count == 0) return;
            string id = grid.SelectedRows[0].Cells["id"].Value.ToString();
            SQLiteCommand command = new SQLiteCommand($"DELETE FROM {Table_serverAccess.main} WHERE ID = @id", DB);
            command.Parameters.AddWithValue("id", id);
            await command.ExecuteNonQueryAsync();
            LoadRows();
        }

        private void ReturnBack()
        {
            Form next = DataUsers.GroupUser == "ADMIN" ? (Form)new MainAdminForm() : new MainWorkerForm();
            next.Show();
            next.FormClosed += (s, e) => Close();
            Hide();
        }

        private void Drag(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Capture = false;
                Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero);
                WndProc(ref m);
            }
        }
    }
}
