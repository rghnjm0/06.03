using System;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    /// <summary>
    /// Журнал посещений серверной — в основном АВТОМАТИЧЕСКИЙ.
    /// При открытии сам пишет «Вход» за текущего пользователя.
    /// При закрытии сам пишет «Выход».
    /// Ручная запись — только дополнение (редко).
    /// </summary>
    public partial class ServerAccessLogForm : Form
    {
        private SQLiteConnection DB;
        private DataGridView grid;
        private Label statusLabel;
        private bool autoEntryWritten;

        public ServerAccessLogForm()
        {
            InitializeComponent();
            Text = "Журнал посещений серверной (авто)";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(980, 560);
            BackColor = Color.FromArgb(24, 28, 36);
            ForeColor = Color.White;
            Font = new Font("Arial", 10);

            Label title = new Label
            {
                Text = "Журнал посещений серверной — автозапись",
                Font = new Font("Arial", 15, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 12),
                AutoSize = true
            };
            Controls.Add(title);
            title.MouseDown += Drag;

            Button close = MakeButton("Закрыть", 860, 12, 100, 32);
            close.Click += (s, e) => ReturnBack();
            Controls.Add(close);

            statusLabel = new Label
            {
                Text = "Записи создаются автоматически при входе/выходе и по заявкам «Сервер».",
                Location = new Point(20, 48),
                Size = new Size(820, 22),
                ForeColor = Color.LightGreen
            };
            Controls.Add(statusLabel);

            grid = new DataGridView
            {
                Location = new Point(20, 80),
                Size = new Size(940, 400),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.FromArgb(36, 42, 54),
                BorderStyle = BorderStyle.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            grid.Columns.Add("id", "ID");
            grid.Columns.Add("visitDate", "Дата");
            grid.Columns.Add("visitTime", "Время");
            grid.Columns.Add("visitor", "Кто");
            grid.Columns.Add("purpose", "Событие");
            grid.Columns.Add("actions", "Детали");
            grid.Columns.Add("accompanied", "Сопровождал");
            grid.Columns["id"].Visible = false;
            Controls.Add(grid);

            Button refresh = MakeButton("Обновить", 20, 500, 140, 36);
            refresh.Click += (s, e) => LoadRows();
            Button del = MakeButton("Удалить (ADMIN)", 170, 500, 160, 36);
            del.Click += async (s, e) => await DeleteRow();
            Controls.Add(refresh);
            Controls.Add(del);

            Load += async (s, e) =>
            {
                DB = new SQLiteConnection(Database.connectionString);
                await DB.OpenAsync();
                await NewModulesDb.EnsureAsync(DB);

                // АВТО: фиксируем вход текущего пользователя
                await NewModulesDb.WriteServerVisitAsync(
                    DataUsers.Initials,
                    "Вход в серверную",
                    "Автозапись при открытии журнала в Support Desk",
                    "",
                    skipIfRecentDuplicate: true);
                autoEntryWritten = true;
                statusLabel.Text = $"Автозапись: {DataUsers.Initials} — вход {DateTime.Now:dd.MM.yyyy HH:mm:ss}";
                LoadRows();
            };

            FormClosing += async (s, e) =>
            {
                // АВТО: фиксируем выход
                if (autoEntryWritten)
                {
                    try
                    {
                        await NewModulesDb.WriteServerVisitAsync(
                            DataUsers.Initials,
                            "Выход из серверной",
                            "Автозапись при закрытии журнала",
                            "",
                            skipIfRecentDuplicate: true);
                    }
                    catch
                    {
                        // не блокируем закрытие
                    }
                }
            };

            MouseDown += Drag;
        }

        private Button MakeButton(string text, int x, int y, int w, int h)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w, h),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(0, 116, 228),
                ForeColor = Color.White
            };
        }

        private async void LoadRows()
        {
            grid.Rows.Clear();
            SQLiteCommand command = new SQLiteCommand($"SELECT * FROM [{Table_serverAccess.main}] ORDER BY ID DESC", DB);
            SQLiteDataReader reader = null;
            try
            {
                reader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    grid.Rows.Add(
                        reader["ID"].ToString(),
                        reader[Table_serverAccess.visitDate].ToString(),
                        reader[Table_serverAccess.visitTime].ToString(),
                        reader[Table_serverAccess.visitor].ToString(),
                        reader[Table_serverAccess.purpose].ToString(),
                        reader[Table_serverAccess.actions].ToString(),
                        reader[Table_serverAccess.accompaniedBy].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Серверная", "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private async System.Threading.Tasks.Task DeleteRow()
        {
            if (DataUsers.GroupUser != "ADMIN")
            {
                MessageBoxUI.Show("Удалять записи может только ADMIN.", "Серверная", "Error");
                return;
            }
            if (grid.SelectedRows.Count == 0)
            {
                return;
            }
            string id = grid.SelectedRows[0].Cells["id"].Value.ToString();
            SQLiteCommand command = new SQLiteCommand($"DELETE FROM {Table_serverAccess.main} WHERE ID = @id", DB);
            command.Parameters.AddWithValue("id", id);
            await command.ExecuteNonQueryAsync();
            LoadRows();
        }

        private void ReturnBack()
        {
            Form next = DataUsers.GroupUser == "ADMIN" ? (Form)new MainAdminForm() : new MainWorkerForm();
            next.Show();
            next.FormClosed += (s, e) => Close();
            Hide();
        }

        private void Drag(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Capture = false;
                Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero);
                WndProc(ref m);
            }
        }
    }
}
