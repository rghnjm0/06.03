import pytest
from services.passwords import hash_password, password_matches, validate_password


def test_password_hash_is_not_plaintext():
    password = 'Correct-Horse-42!'
    hashed = hash_password(password)
    assert hashed != password
    assert password_matches(hashed, password)
    assert not password_matches(hashed, 'wrong-password')


def test_password_policy_limits():
    with pytest.raises(ValueError):
        validate_password('short')
    with pytest.raises(ValueError):
        validate_password('x' * 257)


def test_legacy_plaintext_is_rejected():
    assert not password_matches('plain-text-secret', 'plain-text-secret')
