from services.booking import room_is_available


def test_adjacent_stays_do_not_conflict(memory_db):
    memory_db.execute("INSERT INTO Бронирования VALUES (?,?,?,?,?)",
        ('BK001', 'RM001', '2026-10-10', '2026-10-12', 'Подтверждено'))
    assert room_is_available(memory_db, 'RM001', '2026-10-12', '2026-10-14')


def test_overlapping_stay_is_unavailable(memory_db):
    memory_db.execute("INSERT INTO Бронирования VALUES (?,?,?,?,?)",
        ('BK001', 'RM001', '2026-10-10', '2026-10-12', 'Подтверждено'))
    assert not room_is_available(memory_db, 'RM001', '2026-10-11', '2026-10-13')


def test_cancelled_booking_does_not_block(memory_db):
    memory_db.execute("INSERT INTO Бронирования VALUES (?,?,?,?,?)",
        ('BK001', 'RM001', '2026-10-10', '2026-10-12', 'Отменено'))
    assert room_is_available(memory_db, 'RM001', '2026-10-11', '2026-10-13')
