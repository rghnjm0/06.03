"""Optional standalone process for the same Flask project and its real database.
Do not run alongside the embedded agent: set BUS_EMBEDDED=0 for python run.py.
"""
import os
import threading
from dotenv import load_dotenv
load_dotenv()
os.environ['QE_DISABLE_SCHEDULER'] = '1'
from app import create_app
from app.services.integrations.quests_agent import run

if __name__ == '__main__':
    app = create_app()
    if not app.config['BUS_ENABLED']:
        raise SystemExit('Задайте BUS_ENABLED=1 в .env')
    event = threading.Event()
    try:
        run(app, event)
    except KeyboardInterrupt:
        event.set()
