"""Клиент ресторана: бронь стола и проверка свободных мест.

Вызывается из веб-обработчиков квестов.
"""
import json
import os
import time
import uuid
from datetime import datetime
from pathlib import Path

from flask import current_app


class BusError(Exception):
    pass


def _root() -> Path:
    return Path(current_app.config["BUS_ROOT"])


def _atomic_write(target: Path, data: dict) -> None:
    tmp_dir = _root() / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = tmp_dir / f"{target.name}.{uuid.uuid4().hex}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)


def _send_and_wait(req_type: str, payload: dict,
                   timeout_sec: float | None = None) -> dict:
    """Отправить запрос в ресторан и дождаться ответа."""
    if timeout_sec is None:
        timeout_sec = current_app.config.get("BUS_REQUEST_TIMEOUT", 30)

    root = _root()
    rid = f"{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}-{uuid.uuid4().hex[:6]}"

    req = {
        "request_id": rid,
        "from": "quests",
        "to": "gurman",
        "type": req_type,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload,
    }
    _atomic_write(root / "requests" / "gurman" / f"{rid}.json", req)

    resp_path = root / "responses" / "quests" / f"{rid}.json"
    deadline = time.monotonic() + timeout_sec

    while time.monotonic() < deadline:
        if resp_path.exists():
            try:
                with open(resp_path, "r", encoding="utf-8") as f:
                    resp = json.load(f)
            except (json.JSONDecodeError, OSError):
                time.sleep(0.3)
                continue

            proc = root / "processed" / "quests"
            proc.mkdir(parents=True, exist_ok=True)
            try:
                os.replace(resp_path, proc / resp_path.name)
            except OSError:
                pass

            if resp.get("status") == "error":
                raise BusError(
                    resp.get("payload", {}).get("message")
                    or resp.get("payload", {}).get("error")
                    or "ошибка ресторана"
                )
            return resp.get("payload") or {}

        time.sleep(0.5)

    raise BusError(f"Ресторан не ответил за {timeout_sec} с (id={rid})")


def table_availability() -> dict:
    """Сколько столов свободно прямо сейчас.

    Возвращает: {"total": 16, "free": 10, "by_seats": {2: 3, 4: 5}}
    """
    return _send_and_wait("table_availability", {}, timeout_sec=10)


def reserve_table(*, guests: int, guest_name: str = "",
                  time_str: str = "",
                  timeout_sec: float | None = None) -> dict:
    """Забронировать стол в ресторане.

    Возвращает: {"table_number": 5, "seats": 4, "reservation_id": "RES-..."}
    """
    return _send_and_wait(
        "reserve_table",
        {
            "guests": int(guests),
            "guest_name": guest_name,
            "time": time_str or datetime.now().strftime("%Y-%m-%d %H:%M"),
        },
        timeout_sec=timeout_sec,
    )


def get_restaurant_snapshot() -> dict | None:
    """Снимок ресторана (свободные столы, популярные блюда)."""
    path = _root() / "snapshots" / "gurman.json"
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
