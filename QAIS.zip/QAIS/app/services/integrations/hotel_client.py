"""Hotel client using the shared-folder envelope and гостинка.txt payloads."""
import json
import os
import re
import time
import uuid
from datetime import datetime, date
from pathlib import Path
from flask import current_app
from app.services.integrations.quests_client import BusError, _atomic_write

CODE = re.compile(r'^[A-Za-z0-9_-]{1,60}$')


def service_code():
    configured = current_app.config.get('HOTEL_SERVICE_CODE', '').strip()
    if configured:
        if not CODE.fullmatch(configured):
            raise BusError('HOTEL_SERVICE_CODE должен содержать код MY_CODE агента гостиницы.')
        return configured
    root = Path(current_app.config['BUS_ROOT'])
    for name in ('hotel', 'gostinica', 'uyut'):
        path = root/'snapshots'/(name+'.json')
        try:
            if path.is_file():
                with path.open(encoding='utf-8-sig') as stream:
                    snapshot = json.load(stream)
                code = snapshot.get('service', name)
                if isinstance(code, str) and CODE.fullmatch(code):
                    return code
        except (OSError, ValueError, AttributeError):
            continue
    return 'hotel'


def _send_and_wait(req_type, payload, timeout_sec=None):
    timeout = current_app.config.get('BUS_REQUEST_TIMEOUT', 30) if timeout_sec is None else timeout_sec
    root = Path(current_app.config['BUS_ROOT'])
    if not root.is_dir():
        raise BusError('Общая папка обмена недоступна. Проверьте BUS_ROOT.')
    target = service_code()
    rid = datetime.now().strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:6]
    req = {'request_id': rid, 'from': 'quests', 'to': target, 'type': req_type,
           'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'payload': payload}
    try:
        _atomic_write(root/'requests'/target/(rid+'.json'), req)
        response_path = root/'responses/quests'/(rid+'.json')
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if response_path.exists():
                try:
                    with response_path.open(encoding='utf-8-sig') as stream:
                        response = json.load(stream)
                except (OSError, ValueError):
                    time.sleep(0.2)
                    continue
                if (not isinstance(response, dict) or response.get('request_id') != rid
                        or response.get('from') != target or response.get('to') != 'quests'
                        or response.get('status') not in ('ok', 'error')
                        or not isinstance(response.get('payload'), dict)):
                    raise BusError('Получен некорректный ответ гостиницы. Проверьте запрос ' + rid)
                archive = root/'processed/quests'
                archive.mkdir(parents=True, exist_ok=True)
                os.replace(response_path, archive/response_path.name)
                result = response['payload']
                if response['status'] == 'error' or result.get('status') == 'error':
                    raise BusError(str(result.get('error') or result.get('message') or 'Ошибка гостиницы'))
                return result
            time.sleep(min(0.2, max(0, deadline-time.monotonic())))
    except OSError as exc:
        raise BusError('Не удалось прочитать или записать файлы общей папки обмена.') from exc
    raise BusError(f'Гостиница не ответила за {timeout:g} с (id={rid}). Заявка могла быть выполнена — уточните результат перед повторной отправкой.')


def room_availability(date_str, timeout_sec=10):
    date.fromisoformat(date_str)
    result = _send_and_wait('room_availability', {'date': date_str}, timeout_sec)
    if type(result.get('free_rooms')) is not int or result['free_rooms'] < 0 or not isinstance(result.get('available_types'), list) or not all(isinstance(item, str) for item in result['available_types']):
        raise BusError('Гостиница не прислала корректные free_rooms и available_types.')
    return result


def book_room(*, guest_name, room_type, date_str, timeout_sec=None):
    date.fromisoformat(date_str)
    result = _send_and_wait('book_room', {'guest_name': guest_name.strip(), 'room_type': room_type.strip(), 'date': date_str}, timeout_sec)
    if result.get('booked') is not True or not result.get('booking_id') or result.get('room_number') is None:
        raise BusError('Гостиница не подтвердила бронь. Нужны booked=true, room_number и booking_id. Проверьте результат в гостинице.')
    return result


def get_hotel_snapshot():
    try:
        path = Path(current_app.config['BUS_ROOT'])/'snapshots'/(service_code()+'.json')
        if path.is_file():
            with path.open(encoding='utf-8-sig') as stream:
                snapshot = json.load(stream)
            if isinstance(snapshot, dict) and isinstance(snapshot.get('payload'), dict):
                return snapshot
    except (BusError, OSError, ValueError):
        pass
    return None
