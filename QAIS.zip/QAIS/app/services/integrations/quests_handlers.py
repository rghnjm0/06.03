"""Actual QuestEvent models and booking rules, no example database or fake slots."""
import re
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from app.extensions import db
from app.models import Quest, Room, Location, Slot, User
from app.constants import SLOT_AVAILABLE, ROLE_CLIENT
from app.models.room import ROOM_STATUS_MAINTENANCE
from app.services import booking_service, client_service, pricing_service
from app.services.exceptions import ValidationError
from app.services.integrations.file_bus import timestamp


def integer(value, field):
    if isinstance(value, bool):
        raise ValidationError(f'{field}: ожидается целое число')
    if not isinstance(value, (str, int)) or not re.fullmatch(r'[0-9]+', str(value)):
        raise ValidationError(f'{field}: ожидается целое число')
    number = int(value)
    if not 1 <= number <= 2_147_483_647:
        raise ValidationError(f'{field}: число должно быть от 1 до 2147483647')
    return number


def on_date(payload):
    try:
        return date.fromisoformat(payload.get('date') or date.today().isoformat())
    except (TypeError, ValueError):
        raise ValidationError('date: ожидается YYYY-MM-DD')


def active_quests():
    return (Quest.query.join(Room, Quest.room_id == Room.id)
            .join(Location, Room.location_id == Location.id)
            .filter(Quest.is_active.is_(True), Room.is_active.is_(True),
                    Room.status != ROOM_STATUS_MAINTENANCE, Location.is_active.is_(True)))


def slots_for(day, quest_id=None):
    start = datetime.combine(day, time.min)
    query = (Slot.query.join(Quest, Slot.quest_id == Quest.id)
             .join(Room, Slot.room_id == Room.id).join(Location, Room.location_id == Location.id)
             .filter(Slot.start_time >= start, Slot.start_time < start + timedelta(days=1),
                     Slot.start_time > datetime.now(), Slot.status == SLOT_AVAILABLE,
                     Quest.is_active.is_(True), Quest.room_id == Slot.room_id,
                     Room.is_active.is_(True), Room.status != ROOM_STATUS_MAINTENANCE,
                     Location.is_active.is_(True)))
    if quest_id:
        query = query.filter(Slot.quest_id == quest_id)
    return query.order_by(Slot.start_time, Slot.id).all()


def available_details(day, quest_id=None):
    details = []
    for slot in slots_for(day, quest_id):
        tariff = pricing_service.find_applicable_tariff(slot.quest, day, slot.start_time.strftime('%H:%M'))
        if tariff is None:
            continue
        details.append({'slot_id': slot.id, 'quest_id': slot.quest_id, 'title': slot.quest.title,
                        'date': day.isoformat(), 'time': slot.start_time.strftime('%H:%M'),
                        'end_time': slot.end_time.strftime('%H:%M'), 'room_id': slot.room_id,
                        'location': slot.room.location.name, 'timezone': slot.room.location.timezone,
                        'price': float(Decimal(tariff.price_per_slot)), 'currency': 'RUB',
                        'min_players': slot.quest.min_players, 'max_players': slot.quest.max_players})
    return details


def ping(payload):
    return {'status': 'ok', 'service': 'quests', 'time': timestamp()}


def quest_availability(payload):
    day = on_date(payload)
    quest_id = integer(payload['quest_id'], 'quest_id') if payload.get('quest_id') is not None else None
    details = available_details(day, quest_id)
    return {'date': day.isoformat(), 'slots': [s['time'] for s in details], 'count': len(details), 'details': details}


def quest_lookup(payload):
    quest_id = integer(payload.get('quest_id'), 'quest_id')
    quest = active_quests().filter(Quest.id == quest_id).first()
    if not quest:
        return {'found': False}
    # Quest has tariffs rather than a price column. Report a catalogue minimum.
    prices = [Decimal(t.price_per_slot) for t in quest.tariffs if t.is_active]
    return {'found': True, 'id': quest.id, 'title': quest.title, 'description': quest.description or '',
            'price': float(min(prices)) if prices else None, 'currency': 'RUB',
            'duration_min': quest.duration_minutes, 'min_players': quest.min_players,
            'max_players': quest.max_players, 'location': quest.room.location.name,
            'timezone': quest.room.location.timezone}


def book_quest(payload):
    quest_id = integer(payload.get('quest_id'), 'quest_id')
    day = on_date(payload)
    try:
        slot_time = datetime.strptime(payload.get('time', ''), '%H:%M').time()
    except (ValueError, TypeError):
        raise ValidationError('time: ожидается HH:MM')
    name, phone = payload.get('guest_name'), payload.get('phone')
    if not isinstance(name, str) or not name.strip() or len(name) > 150:
        raise ValidationError('Укажите guest_name длиной до 150 символов')
    if not isinstance(phone, str) or not re.fullmatch(r'\+?[\d\s\-()]{7,25}', phone.strip()):
        raise ValidationError('Укажите корректный phone')
    quest = active_quests().filter(Quest.id == quest_id).first()
    if not quest:
        raise ValidationError('Квест не найден или недоступен')
    players = integer(payload.get('players_count', quest.min_players), 'players_count')
    candidates = [s for s in slots_for(day, quest_id) if s.start_time.time() == slot_time]
    if payload.get('slot_id') is not None:
        slot_id = integer(payload['slot_id'], 'slot_id')
        candidates = [s for s in candidates if s.id == slot_id]
    if not candidates:
        raise ValidationError('Выбранный сеанс недоступен')
    if len(candidates) != 1:
        raise ValidationError('Найдено несколько сеансов: укажите slot_id')
    # Use the same guest-client lookup as the public booking form. Do not override
    # existing names, passwords, roles, or email addresses on behalf of a sender.
    client = client_service.get_or_create_guest_client(name, phone, commit=False)
    booking = booking_service.create_booking(client, candidates[0].id, players, source='aggregator', commit=False)
    return {'booked': True, 'booking_id': booking.id, 'confirmation': booking.confirmation_code,
            'quest_id': quest.id, 'date': day.isoformat(), 'time': slot_time.strftime('%H:%M'),
            'guest_name': name.strip(), 'price': float(booking.final_price), 'currency': 'RUB'}


HANDLERS = {'ping': ping, 'quest_availability': quest_availability, 'book_quest': book_quest, 'quest_lookup': quest_lookup}
