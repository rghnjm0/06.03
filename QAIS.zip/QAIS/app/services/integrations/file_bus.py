"""JSON transport compatible with the shared exchange folder protocol."""
import json
import os
import re
import uuid
from datetime import datetime
from pathlib import Path
from flask import current_app

MY_CODE = 'quests'
CODE = re.compile(r'^[a-zA-Z0-9_-]{1,40}$')
RID = re.compile(r'^[a-zA-Z0-9_-]{1,100}$')


class BusError(Exception):
    pass


class BusTimeout(BusError):
    def __init__(self, request_id, timeout):
        self.request_id = request_id
        super().__init__(f'Нет ответа за {timeout:g} с. Запрос {request_id} мог быть выполнен; повторяйте с тем же ID.')


def root_path():
    if not current_app.config.get('BUS_ENABLED'):
        raise BusError('Обмен с партнёрами выключен. Задайте BUS_ENABLED=1.')
    root = Path(current_app.config['BUS_ROOT'])
    # Do not create a fake UNC-path directory on Linux when the share is unmounted.
    if not root.is_dir():
        raise BusError('Общая папка обмена недоступна. Проверьте BUS_ROOT и подключение к сети.')
    return root


def timestamp():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def atomic_write(target, data):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    # Temp alongside target: same volume even when exchange is an SMB share.
    temp = target.with_name('.' + target.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temp.open('x', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)


def read_json(path):
    if Path(path).stat().st_size > 1_000_000:
        raise ValueError('JSON-файл превышает 1 МБ')
    with Path(path).open(encoding='utf-8-sig') as stream:
        data = json.load(stream)
    if not isinstance(data, dict):
        raise ValueError('Ожидается JSON-объект')
    return data


def validate_request(req, filename):
    rid, sender = req.get('request_id'), req.get('from')
    if not isinstance(rid, str) or not RID.fullmatch(rid) or rid != filename:
        raise ValueError('Некорректный request_id или имя файла')
    if not isinstance(sender, str) or not CODE.fullmatch(sender) or sender == MY_CODE:
        raise ValueError('Некорректный отправитель')
    allowed = current_app.config.get('BUS_ALLOWED_SENDERS', ())
    if allowed and sender not in allowed:
        raise ValueError('Отправитель не разрешён в BUS_ALLOWED_SENDERS')
    if req.get('to') != MY_CODE or not isinstance(req.get('type'), str):
        raise ValueError('Некорректный получатель или тип')
    if not isinstance(req.get('payload', {}), dict):
        raise ValueError('payload должен быть объектом')
    return req
