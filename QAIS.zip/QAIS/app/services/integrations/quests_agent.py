"""Фоновый агент квестов.

  * читает requests/quests/ и отвечает в responses/<from>/;
  * раз в BUS_SNAPSHOT_INTERVAL публикует snapshots/quests.json.

Запускается из app.py через start(app).
"""
import json
import os
import threading
import time
import uuid
from datetime import datetime, date as date_cls
from pathlib import Path

from flask import current_app
from app.models import Quest
from app.services import booking_service, client_service, schedule_service


MY_CODE = "quests"
_thread = None
_stop = threading.Event()


def _log(msg: str) -> None:
    try:
        current_app.logger.info("[bus] %s", msg)
    except Exception:
        pass


def _atomic_write(target: Path, data: dict) -> None:
    tmp_dir = target.parent.parent.parent / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = tmp_dir / f"{target.name}.{uuid.uuid4().hex}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)


# ---------------------------------------------------------------------------
# Обработчики
# ---------------------------------------------------------------------------
def _h_ping(req):
    return {"status": "ok", "service": MY_CODE,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}


def _h_quest_availability(req):
    """Свободные слоты на дату из расписания QuestEvent."""
    p = req.get("payload", {}) or {}
    d = p.get("date") or date_cls.today().isoformat()
    day = date_cls.fromisoformat(d)
    rows = []
    for quest in Quest.query.filter_by(is_active=True).all():
        rows.extend(schedule_service.get_available_slots(quest.id, day, day))
    rows.sort(key=lambda slot: slot.start_time)
    slots = [slot.start_time.strftime("%H:%M") for slot in rows]
    return {"date": d, "slots": slots, "count": len(slots)}


def _h_book_quest(req):
    """Создаёт настоящую бронь через сервис QuestEvent."""
    p = req.get("payload", {}) or {}
    quest_id = p.get("quest_id")
    slot_time = p.get("time")
    d = p.get("date") or date_cls.today().isoformat()
    guest_name = (p.get("guest_name") or "").strip()
    phone = (p.get("phone") or "").strip()

    if not quest_id or not slot_time:
        return {"status": "error", "error": "quest_id и time обязательны"}

    quest = Quest.query.filter_by(id=quest_id, is_active=True).first()
    if not quest:
        return {"status": "error", "error": "Квест недоступен"}
    day = date_cls.fromisoformat(d)
    slots = schedule_service.get_available_slots(quest.id, day, day)
    slot = next((s for s in slots if s.start_time.strftime("%H:%M") == slot_time), None)
    if slot is None:
        return {"status": "error", "error": f"Слот {d} {slot_time} недоступен"}

    client = client_service.get_or_create_guest_client(guest_name, phone)
    booking = booking_service.create_booking(
        client=client, slot_id=slot.id, players_count=quest.min_players,
        source="aggregator",
    )
    return {
        "booked": True,
        "confirmation": booking.confirmation_code,
        "quest_id": quest.id,
        "date": d,
        "time": slot_time,
        "guest_name": guest_name,
    }


def _h_quest_lookup(req):
    """Информация о квесте по id из моделей QuestEvent."""
    p = req.get("payload", {}) or {}
    quest_id = p.get("quest_id")
    if not quest_id:
        return {"found": False, "error": "quest_id обязателен"}
    quest = Quest.query.filter_by(id=quest_id, is_active=True).first()
    if quest is None:
        return {"found": False}
    prices = [tariff.price_per_slot for tariff in quest.tariffs if tariff.is_active]
    return {
        "found": True,
        "id": quest.id,
        "title": quest.title,
        "description": quest.description or "",
        "price": float(min(prices)) if prices else None,
        "duration_min": quest.duration_minutes,
    }


_HANDLERS = {
    "ping": _h_ping,
    "quest_availability": _h_quest_availability,
    "book_quest": _h_book_quest,
    "quest_lookup": _h_quest_lookup,
}


# ---------------------------------------------------------------------------
# Обработка одного запроса
# ---------------------------------------------------------------------------
def _process_request(root: Path, req_file: Path) -> None:
    try:
        with open(req_file, "r", encoding="utf-8") as f:
            req = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        _log(f"не смог прочитать {req_file.name}: {e}")
        return

    rid = req.get("request_id") or req_file.stem
    req_type = req.get("type", "")
    sender = req.get("from", "?")
    _log(f"вход ← {sender}/{req_type} id={rid}")

    handler = _HANDLERS.get(req_type)
    try:
        if handler:
            payload = handler(req)
            status = "error" if payload.get("status") == "error" else "ok"
        else:
            payload = {"error": f"Неизвестный тип: {req_type}"}
            status = "error"
    except Exception as e:
        _log(f"ошибка {req_type}: {e}")
        payload = {"error": str(e)}
        status = "error"

    resp = {
        "request_id": rid,
        "from": MY_CODE,
        "to": sender,
        "status": status,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload,
    }
    _atomic_write(root / "responses" / sender / f"{rid}.json", resp)
    _log(f"ответ → {sender}/{status} id={rid}")

    proc = root / "processed" / MY_CODE
    proc.mkdir(parents=True, exist_ok=True)
    try:
        os.replace(req_file, proc / req_file.name)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Публикация snapshot
# ---------------------------------------------------------------------------
def _publish_snapshot(root: Path) -> None:
    today = date_cls.today().isoformat()
    quests = Quest.query.filter_by(is_active=True).order_by(Quest.id.desc()).all()
    slots = _h_quest_availability({"payload": {"date": today}})["slots"]
    popular = []
    for quest in quests[:3]:
        info = _h_quest_lookup({"payload": {"quest_id": quest.id}})
        popular.append({"title": info["title"], "price": info["price"],
                        "duration_min": info["duration_min"]})
    payload = {
        "quests_name": current_app.config.get("QUESTS_NAME", "Квесты"),
        "active_quests": len(quests),
        "slots_today": slots,
        "popular": popular,
    }
    _atomic_write(root / "snapshots" / f"{MY_CODE}.json", {
        "service": MY_CODE,
        "published_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "payload": payload,
    })
    _log("snapshot опубликован")


# ---------------------------------------------------------------------------
# Основной цикл
# ---------------------------------------------------------------------------
def _loop(app, root: Path) -> None:
    req_dir = root / "requests" / MY_CODE
    last_snap = 0.0
    seen: set[str] = set()

    with app.app_context():
        for d in (req_dir, root / "responses" / MY_CODE,
                  root / "snapshots", root / "processed" / MY_CODE,
                  root / "tmp"):
            d.mkdir(parents=True, exist_ok=True)
        _log(f"агент запущен. Слежу за {req_dir}")

    while not _stop.is_set():
        try:
            with app.app_context():
                if req_dir.exists():
                    for f in req_dir.iterdir():
                        if (f.is_file() and f.suffix == ".json"
                                and f.name not in seen):
                            seen.add(f.name)
                            try:
                                _process_request(root, f)
                            except Exception as e:
                                _log(f"process: {e}")

                now = time.time()
                if now - last_snap >= app.config["BUS_SNAPSHOT_INTERVAL"]:
                    try:
                        _publish_snapshot(root)
                    except Exception as e:
                        _log(f"publish: {e}")
                    last_snap = now
        except Exception as e:
            _log(f"loop: {e}")
        _stop.wait(1.0)

    _log("агент остановлен")


def start(app) -> None:
    global _thread
    root = Path(app.config["BUS_ROOT"])
    if not root.exists():
        app.logger.warning("[bus] папка шины не найдена: %s", root)
        return
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(
        target=_loop, args=(app, root),
        name="bus-quests", daemon=True,
    )
    _thread.start()


def stop() -> None:
    _stop.set()
    if _thread:
        _thread.join(timeout=3)
