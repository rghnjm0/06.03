"""Views of the file bus. The agent and restaurant client retain the text protocol."""
import json
import re
import uuid
from datetime import datetime
from pathlib import Path
from flask import current_app
from app.services.integrations import quests_client

CODE = re.compile(r'^[A-Za-z0-9_-]{1,60}$')
REQUEST_ID = re.compile(r'^[A-Za-z0-9_-]{1,100}$')
NAMES = {'quests': 'Квесты', 'gurman': 'Ресторан «Гурман»', 'bank': 'Банк',
         'fakebank': 'Банк', 'hotel': 'Гостиница', 'gostinica': 'Гостиница', 'uyut': 'Гостиница',
         'recipes': 'Рецепты', 'recipe-collection': 'Рецепты'}


def bus_root():
    root = Path(current_app.config['BUS_ROOT'])
    if not root.is_dir():
        raise quests_client.BusError('Папка обмена недоступна. Проверьте BUS_ROOT в .env и доступ через Проводник.')
    return root


def read_packet(path):
    if path.stat().st_size > 1_000_000:
        raise ValueError('Файл больше 1 МБ')
    with path.open(encoding='utf-8-sig') as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ValueError('Ожидается JSON-объект')
    return value


def snapshots(root):
    items, errors = [], []
    for path in sorted((root/'snapshots').glob('*.json'))[:50]:
        try:
            packet = read_packet(path)
            code = packet.get('service') or path.stem
            items.append({'code': code, 'name': NAMES.get(code, code),
                          'published_at': packet.get('published_at', 'Не указано'), 'packet': packet})
        except (OSError, ValueError, TypeError) as exc:
            errors.append(f'{path.name}: {exc}')
    return items, errors


def packets(root):
    responses, pending = [], []
    # A response consumed by the original client moves to processed/quests.
    # Include it there too; incoming request envelopes are not responses.
    seen = set()
    for folder in (root/'responses/quests', root/'processed/quests'):
        for path in sorted(folder.glob('*.json'), reverse=True)[:100]:
            try:
                value = read_packet(path)
                rid = value.get('request_id')
                if value.get('to') != 'quests' or value.get('status') not in ('ok', 'error') or not isinstance(rid, str) or rid in seen:
                    continue
                seen.add(rid)
                responses.append(value)
            except (OSError, ValueError):
                continue
    for path in sorted((root/'requests').glob('*/*.json'), reverse=True)[:200]:
        try:
            value = read_packet(path)
            if value.get('from') == 'quests' and isinstance(value.get('request_id'), str) and value['request_id'] not in seen:
                pending.append(value)
        except (OSError, ValueError):
            continue
    responses.sort(key=lambda p: str(p.get('created_at', '')), reverse=True)
    pending.sort(key=lambda p: str(p.get('created_at', '')), reverse=True)
    return responses[:30], pending[:30]


def submit(target, kind, payload_text):
    root = bus_root()
    if not CODE.fullmatch(target) or not CODE.fullmatch(kind):
        raise quests_client.BusError('Код сервиса и тип запроса: латинские буквы, цифры, дефис и подчёркивание.')
    try:
        payload = json.loads(payload_text or '{}')
    except ValueError:
        raise quests_client.BusError('Payload должен быть корректным JSON, например {}.')
    if not isinstance(payload, dict):
        raise quests_client.BusError('Payload должен быть JSON-объектом.')
    rid = datetime.now().strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:6]
    packet = {'request_id': rid, 'from': 'quests', 'to': target, 'type': kind,
              'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'payload': payload}
    quests_client._atomic_write(root/'requests'/target/(rid+'.json'), packet)
    return rid


def selected_response(root, rid):
    if not rid:
        return None
    if not REQUEST_ID.fullmatch(rid):
        raise quests_client.BusError('Некорректный ID запроса')
    for folder in (root/'responses/quests', root/'processed/quests'):
        path = folder/(rid+'.json')
        if path.is_file():
            packet = read_packet(path)
            if packet.get('request_id') == rid and packet.get('to') == 'quests' and packet.get('status') in ('ok','error'):
                return packet
    return None
