from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, DateTimeLocalField, DateField
from wtforms.validators import DataRequired, Length, NumberRange, InputRequired


class BusRequestForm(FlaskForm):
    target = StringField('Код проекта', default='gurman', validators=[DataRequired(), Length(max=60)])
    kind = StringField('Тип запроса', default='ping', validators=[DataRequired(), Length(max=60)])
    payload = TextAreaField('Данные запроса (JSON)', default='{}', validators=[Length(max=16000)])


class RestaurantForm(FlaskForm):
    booking_id = SelectField('Бронирование квеста', coerce=int, validators=[InputRequired()])
    guests = IntegerField('Количество гостей', default=2, validators=[InputRequired(), NumberRange(min=1)])
    visit_at = DateTimeLocalField('Дата и время ужина', format='%Y-%m-%dT%H:%M', validators=[DataRequired()])


class HotelAvailabilityForm(FlaskForm):
    date = DateField('Дата заезда', validators=[DataRequired()])


class HotelBookingForm(HotelAvailabilityForm):
    guest_name = StringField('Имя гостя', validators=[DataRequired(), Length(max=150)])
    room_type = StringField('Тип номера', validators=[DataRequired(), Length(max=100)])
