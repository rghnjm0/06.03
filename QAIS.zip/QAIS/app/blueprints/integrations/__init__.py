from datetime import datetime, date
from flask import Blueprint, current_app, flash, redirect, render_template, request, session, url_for
from flask_login import current_user, login_required
from app.blueprints.rbac import roles_required, branch_scoped_query
from app.extensions import limiter
from app.forms.integration_forms import BusRequestForm, RestaurantForm, HotelAvailabilityForm, HotelBookingForm
from app.models import Booking, Slot, Room, Location
from app.services.integrations import quests_agent, quests_client, ui_service, hotel_client

bp = Blueprint('integrations', __name__, url_prefix='/integrations')


@bp.route('', methods=['GET', 'POST'])
@roles_required('superadmin', 'admin')
@limiter.limit('10 per minute', methods=['POST'])
def dashboard():
    form = BusRequestForm()
    if request.method == 'GET' and request.args.get('hotel_type') in ('room_availability', 'book_room'):
        try:
            form.target.data = hotel_client.service_code()
        except quests_client.BusError as exc:
            form.target.data = ''
            flash(str(exc), 'warning')
        form.kind.data = request.args['hotel_type']
        import json
        payload = {'date': date.today().isoformat()}
        if form.kind.data == 'book_room':
            payload.update(guest_name=current_user.full_name, room_type='standard')
        form.payload.data = json.dumps(payload, ensure_ascii=False, indent=2)
    if request.method == 'POST':
        try:
            action = request.form.get('action')
            if action == 'send' and form.validate_on_submit():
                rid = ui_service.submit(form.target.data.strip(), form.kind.data.strip(), form.payload.data)
                flash('Запрос отправлен. Ответ появится после обработки другим проектом.', 'success')
                return redirect(url_for('integrations.dashboard', request_id=rid))
            elif action == 'start':
                ui_service.bus_root()
                quests_agent.start(current_app._get_current_object())
                flash('Агент запущен. Обновите страницу через несколько секунд.', 'success')
                return redirect(url_for('integrations.dashboard'))
            elif action == 'snapshot':
                quests_agent._publish_snapshot(ui_service.bus_root())
                flash('Снимок квестов обновлён.', 'success')
                return redirect(url_for('integrations.dashboard'))
            elif action not in ('send', 'start', 'snapshot'):
                flash('Неизвестная операция.', 'danger')
        except (quests_client.BusError, OSError, ValueError) as exc:
            flash(str(exc), 'warning')
        except Exception:
            current_app.logger.exception('Integration dashboard operation failed')
            flash('Операция не выполнена. Подробности записаны в журнал приложения.', 'danger')
    snapshots, errors, responses, pending = [], [], [], []
    selected, root_error = None, None
    rid = request.args.get('request_id', '')
    try:
        root = ui_service.bus_root()
        snapshots, errors = ui_service.snapshots(root)
        responses, pending = ui_service.packets(root)
        selected = ui_service.selected_response(root, rid)
    except (quests_client.BusError, OSError, ValueError) as exc:
        root_error = str(exc)
    active = bool(quests_agent._thread and quests_agent._thread.is_alive())
    return render_template('integrations/dashboard.html', form=form, snapshots=snapshots, errors=errors,
                           responses=responses, pending=pending, selected=selected, request_id=rid,
                           root_error=root_error, root_path=current_app.config['BUS_ROOT'], agent_active=active)


def _bookings():
    query = Booking.query.filter(Booking.status != 'canceled')
    if current_user.is_staff():
        query = query.join(Slot, Booking.slot_id == Slot.id).join(Room, Slot.room_id == Room.id).join(Location, Room.location_id == Location.id)
        return branch_scoped_query(query, Location.branch_id)
    return query.filter(Booking.client_id == current_user.id)


@bp.route('/restaurant', methods=['GET', 'POST'])
@login_required
@limiter.limit('10 per minute', methods=['POST'])
def restaurant():
    bookings = _bookings().order_by(Booking.id.desc()).limit(100).all()
    form = RestaurantForm()
    form.booking_id.choices = [(b.id, f'№{b.id} — {b.slot.quest.title} — {b.slot.start_time:%d.%m.%Y %H:%M} (до {b.slot.end_time:%H:%M})') for b in bookings]
    if request.method == 'GET' and request.args.get('booking_id', type=int) in {b.id for b in bookings}:
        form.booking_id.data = request.args.get('booking_id', type=int)
    result = session.pop('restaurant_result', None)
    availability = session.pop('restaurant_availability', None)
    if request.method == 'POST':
        try:
            ui_service.bus_root()
            if request.form.get('action') == 'availability':
                data = quests_client.table_availability()
                session['restaurant_availability'] = {key: data.get(key) for key in ('free','total')}
                return redirect(url_for('integrations.restaurant'))
            if request.form.get('action') == 'reserve' and form.validate_on_submit():
                booking = _bookings().filter(Booking.id == form.booking_id.data).first_or_404()
                if form.visit_at.data < booking.slot.end_time:
                    form.visit_at.errors.append('Выберите время после окончания квеста.')
                elif form.visit_at.data <= datetime.now():
                    form.visit_at.errors.append('Выберите будущее время.')
                else:
                    data = quests_client.reserve_table(guests=form.guests.data, guest_name=booking.client.full_name,
                                                       time_str=form.visit_at.data.strftime('%Y-%m-%d %H:%M'))
                    if 'table_number' not in data or 'reservation_id' not in data:
                        raise quests_client.BusError('Ресторан прислал ответ без номера стола или брони. Проверьте заявку в ресторане.')
                    session['restaurant_result'] = {k: data[k] for k in ('table_number','reservation_id')}
                    return redirect(url_for('integrations.restaurant'))
        except quests_client.BusError as exc:
            flash(str(exc), 'warning')
            flash('При задержке ответа сначала уточните результат в ресторане: заявка могла быть выполнена.', 'info')
        except (OSError, ValueError):
            flash('Нет доступа к папке обмена или ответ ресторана повреждён.', 'warning')
    snapshot = quests_client.get_restaurant_snapshot()
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get('payload'), dict) or not isinstance(snapshot['payload'].get('tables'), dict):
        snapshot = None
    return render_template('integrations/restaurant.html', form=form, result=result, availability=availability,
                           snapshot=snapshot, has_bookings=bool(bookings))


@bp.route('/hotel', methods=['GET', 'POST'])
@login_required
@limiter.limit('10 per minute', methods=['POST'])
def hotel():
    search_form = HotelAvailabilityForm(prefix='search')
    booking_form = HotelBookingForm(prefix='book')
    if request.method == 'GET':
        search_form.date.data = date.today()
        booking_form.date.data = date.today()
        booking_form.guest_name.data = current_user.full_name
        selected_date = request.args.get('date')
        if selected_date:
            try:
                booking_form.date.data = search_form.date.data = date.fromisoformat(selected_date)
            except ValueError:
                pass
    result = session.pop('hotel_result', None)
    availability = session.pop('hotel_availability', None)
    available_types = session.get('hotel_available_types', [])
    if request.method == 'POST':
        try:
            action = request.form.get('action')
            if action == 'availability' and search_form.validate_on_submit():
                if search_form.date.data < date.today():
                    search_form.date.errors.append('Выберите сегодняшнюю или будущую дату.')
                else:
                    data = hotel_client.room_availability(search_form.date.data.isoformat())
                    session['hotel_availability'] = {k: data.get(k) for k in ('date', 'free_rooms')}
                    session['hotel_available_types'] = data['available_types'][:30]
                    return redirect(url_for('integrations.hotel', date=search_form.date.data.isoformat()))
            elif action == 'reserve' and booking_form.validate_on_submit():
                if booking_form.date.data < date.today():
                    booking_form.date.errors.append('Выберите сегодняшнюю или будущую дату.')
                else:
                    data = hotel_client.book_room(guest_name=booking_form.guest_name.data,
                                room_type=booking_form.room_type.data, date_str=booking_form.date.data.isoformat())
                    session['hotel_result'] = {k: data.get(k) for k in ('room_number', 'booking_id', 'room_type', 'guest_name')}
                    return redirect(url_for('integrations.hotel', date=booking_form.date.data.isoformat()))
        except quests_client.BusError as exc:
            flash(str(exc), 'warning')
        except ValueError:
            flash('Проверьте дату и ответ гостиницы.', 'warning')
    root_error = None
    try:
        ui_service.bus_root()
        target = hotel_client.service_code()
    except (quests_client.BusError, OSError) as exc:
        root_error = str(exc)
        target = None
    return render_template('integrations/hotel.html', search_form=search_form, booking_form=booking_form,
                           availability=availability, available_types=available_types, result=result,
                           snapshot=hotel_client.get_hotel_snapshot(), root_error=root_error, target=target)
