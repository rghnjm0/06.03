"""HTTP integration for QuestEvent. Partner requests do not change booking/payment state."""
import hashlib
import json
import os
import sqlite3
from datetime import date
from decimal import Decimal
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

from flask import Blueprint, abort, current_app, render_template, request
from flask_login import current_user, login_required
from app.models.booking import Booking
from app.extensions import db

bp = Blueprint('partners', __name__, url_prefix='/partners')
SERVICES = {'bank': 'Банк', 'hotel': 'Гостиница', 'restaurant': 'Ресторан', 'recipes': 'Рецепты'}

class PartnerError(Exception):
    pass

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def call_partner(service, path, payload=None, key=None):
    prefix = 'PARTNER_' + service.upper()
    base = os.getenv(prefix + '_URL', '').rstrip('/')
    token = os.getenv(prefix + '_TOKEN', '')
    parsed = urlsplit(base)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.query or parsed.fragment or not token:
        raise PartnerError('Не настроены адрес и ключ сервиса «' + SERVICES[service] + '».')
    headers = {'Authorization': 'Bearer ' + token, 'Accept': 'application/json'}
    body = None
    if payload is not None:
        headers['Content-Type'] = 'application/json'
        headers['Idempotency-Key'] = key
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = Request(base + path, data=body, headers=headers)
    try:
        with build_opener(NoRedirect()).open(req, timeout=8) as response:
            raw = response.read(1_000_001)
            if len(raw) > 1_000_000:
                raise PartnerError('Ответ сервиса слишком большой.')
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise PartnerError('Сервис вернул неверный формат ответа.')
            return result
    except HTTPError as exc:
        raise PartnerError(f'Сервис ответил HTTP {exc.code}.') from exc
    except (URLError, TimeoutError, OSError, ValueError) as exc:
        raise PartnerError('Нет корректного ответа сервиса. Запрос мог быть принят; повторите с теми же данными.') from exc


def journal():
    # Separate local journal: no migration of the existing QuestEvent database needed.
    conn = sqlite3.connect(os.path.join(current_app.instance_path, 'partner_requests.sqlite3'))
    conn.row_factory = sqlite3.Row
    conn.execute('CREATE TABLE IF NOT EXISTS requests (request_key TEXT PRIMARY KEY, user_id INTEGER NOT NULL, service TEXT NOT NULL, payload TEXT NOT NULL, response TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
    return conn


@bp.route('/', methods=['GET', 'POST'])
@login_required
def index():
    error = result = None
    if request.method == 'POST':
        service = request.form.get('service')
        if service not in SERVICES:
            abort(400)
        try:
            if service == 'recipes':
                result = call_partner(service, '/api/recipes?' + urlencode({'q': request.form.get('search', '')[:100], 'page': 1, 'limit': 10}))
            else:
                booking_id = int(request.form.get('booking_id', '0'))
                booking = db.session.get(Booking, booking_id)
                # Staff cannot send somebody else's request through this customer screen.
                if not booking or booking.client_id != current_user.id:
                    abort(404)
                if booking.status == 'canceled':
                    raise ValueError('Бронь отменена.')
                payload = {'source': 'questevent', 'booking_id': str(booking.id)}
                if service == 'bank':
                    total = max(Decimal('0'), Decimal(booking.final_price) - Decimal(booking.certificate_amount_used or 0))
                    if total <= 0:
                        raise ValueError('У этой брони нет суммы к оплате.')
                    payload.update(amount_minor=int(total * 100), currency='RUB')
                    path = '/api/payments'
                elif service == 'hotel':
                    start = date.fromisoformat(request.form.get('check_in', ''))
                    end = date.fromisoformat(request.form.get('check_out', ''))
                    guests = int(request.form.get('guests', '1'))
                    if start < date.today() or end <= start or not 1 <= guests <= 50:
                        raise ValueError('Проверьте даты и число гостей.')
                    payload.update(check_in=start.isoformat(), check_out=end.isoformat(), guests=guests)
                    path = '/api/booking-requests'
                else:
                    from datetime import datetime
                    when = datetime.fromisoformat(request.form.get('visit_at', ''))
                    guests = int(request.form.get('guests', '1'))
                    if when.tzinfo is None or when <= datetime.now(when.tzinfo) or not 1 <= guests <= 50:
                        raise ValueError('Укажите будущее время с часовым поясом и число гостей.')
                    payload.update(visit_at=when.isoformat(), guests=guests)
                    path = '/api/table-requests'
                serialized = json.dumps(payload, sort_keys=True, ensure_ascii=False)
                namespace = os.getenv('PARTNER_CLIENT_ID', '')
                if not namespace:
                    raise PartnerError('Задайте уникальный PARTNER_CLIENT_ID в .env.')
                key = hashlib.sha256((namespace + ':' + str(current_user.id) + ':' + service + ':' + serialized).encode()).hexdigest()
                conn = journal()
                try:
                    conn.execute('INSERT OR IGNORE INTO requests(request_key,user_id,service,payload) VALUES(?,?,?,?)', (key, current_user.id, service, serialized))
                    conn.commit()
                    row = conn.execute('SELECT response FROM requests WHERE request_key=?', (key,)).fetchone()
                    if row['response']:
                        result = json.loads(row['response'])
                    else:
                        result = call_partner(service, path, payload, key)
                        if not result.get('request_id') or not result.get('status'):
                            raise PartnerError('В ответе нет request_id или status. Обратитесь к владельцу сервиса.')
                        conn.execute('UPDATE requests SET response=? WHERE request_key=?', (json.dumps(result, ensure_ascii=False), key))
                        conn.commit()
                finally:
                    conn.close()
        except (ValueError, PartnerError) as exc:
            error = str(exc) if isinstance(exc, PartnerError) else 'Проверьте поля формы. ' + str(exc)
    bookings = Booking.query.filter_by(client_id=current_user.id).order_by(Booking.id.desc()).limit(100).all()
    conn = journal()
    try:
        history = conn.execute('SELECT service,payload,response,created_at FROM requests WHERE user_id=? ORDER BY rowid DESC LIMIT 20', (current_user.id,)).fetchall()
    finally:
        conn.close()
    return render_template('partners/index.html', services=SERVICES, bookings=bookings, result=result, error=error, history=history)
