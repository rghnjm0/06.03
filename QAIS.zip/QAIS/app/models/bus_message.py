"""Persistent request results. Booking and response commit in one transaction."""
from datetime import datetime, timezone
from app.extensions import db


class BusMessage(db.Model):
    __tablename__ = 'bus_messages'
    id = db.Column(db.Integer, primary_key=True)
    sender = db.Column(db.String(40), nullable=False)
    request_id = db.Column(db.String(100), nullable=False)
    request_hash = db.Column(db.String(64), nullable=False)
    response_json = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    __table_args__ = (db.UniqueConstraint('sender', 'request_id', name='uq_bus_sender_request'),)
