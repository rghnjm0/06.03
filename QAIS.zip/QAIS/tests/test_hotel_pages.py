import json
import threading
import time
from datetime import date, timedelta
import pytest
from app.services.integrations import hotel_client
from app.services.integrations.quests_client import BusError
from tests.conftest import login
from tests.test_integration_pages import client_login


@pytest.fixture
def exchange(app,tmp_path):
    app.config.update(BUS_ROOT=str(tmp_path), HOTEL_SERVICE_CODE='', BUS_REQUEST_TIMEOUT=1)
    return tmp_path


def tomorrow():
    return (date.today()+timedelta(days=1)).isoformat()


def hotel_worker(root, kind, result, seen, code='hotel', envelope_status='ok'):
    def run():
        until=time.monotonic()+3
        while time.monotonic()<until:
            files=list((root/'requests'/code).glob('*.json'))
            if files:break
            time.sleep(0.01)
        else:return
        req=json.loads(files[0].read_text());seen.append(req)
        response={'request_id':req['request_id'],'from':code,'to':'quests','status':envelope_status,
                  'created_at':'2026-10-20 12:00:00','payload':result}
        path=root/'responses/quests'/files[0].name
        path.parent.mkdir(parents=True,exist_ok=True)
        temporary=path.with_suffix('.tmp')
        temporary.write_text(json.dumps(response),encoding='utf-8')
        temporary.replace(path)
    worker=threading.Thread(target=run);worker.start();return worker


def test_availability_format_matches_uploaded_text(app,exchange):
    seen=[];day=tomorrow()
    expected={'status':'ok','date':day,'free_rooms':5,'available_types':['standard','lux']}
    worker=hotel_worker(exchange,'room_availability',expected,seen)
    try:result=hotel_client.room_availability(day,timeout_sec=2)
    finally:worker.join()
    assert result==expected
    assert seen[0]['type']=='room_availability' and seen[0]['payload']=={'date':day}
    assert seen[0]['from']=='quests' and seen[0]['to']=='hotel'
    assert set(seen[0])=={'request_id','from','to','type','created_at','payload'}
    assert (exchange/'processed/quests'/(seen[0]['request_id']+'.json')).exists()


def test_booking_format_matches_uploaded_text(app,exchange):
    seen=[];day=tomorrow()
    expected={'status':'ok','booked':True,'room_number':'204','room_type':'standard','guest_name':'Тестовый гость','booking_id':'ROOM-test'}
    worker=hotel_worker(exchange,'book_room',expected,seen)
    try:result=hotel_client.book_room(guest_name='Тестовый гость',room_type='standard',date_str=day,timeout_sec=2)
    finally:worker.join()
    assert result==expected
    assert seen[0]['type']=='book_room'
    assert seen[0]['payload']=={'guest_name':'Тестовый гость','room_type':'standard','date':day}


def test_service_code_from_snapshot_and_config(app,exchange):
    path=exchange/'snapshots/gostinica.json';path.parent.mkdir(parents=True)
    path.write_text(json.dumps({'service':'gostinica','published_at':'2026-10-20 10:00:00','payload':{'hotel_name':'Уют'}}))
    assert hotel_client.service_code()=='gostinica'
    assert hotel_client.get_hotel_snapshot()['payload']['hotel_name']=='Уют'
    app.config['HOTEL_SERVICE_CODE']='my_hotel'
    assert hotel_client.service_code()=='my_hotel'
    app.config['HOTEL_SERVICE_CODE']='../outside'
    with pytest.raises(BusError):hotel_client.service_code()


def test_sends_to_actual_service_code(app,exchange):
    app.config['HOTEL_SERVICE_CODE']='gostinica'
    seen=[];expected={'free_rooms':0,'available_types':[]}
    worker=hotel_worker(exchange,'room_availability',expected,seen,code='gostinica')
    try:assert hotel_client.room_availability(tomorrow(),timeout_sec=2)==expected
    finally:worker.join()
    assert seen[0]['to']=='gostinica'


@pytest.mark.parametrize('envelope_status',['ok','error'])
def test_hotel_error_is_not_shown_as_success(app,exchange,envelope_status):
    seen=[];worker=hotel_worker(exchange,'book_room',{'status':'error','error':'Нет свободных номеров'},seen,envelope_status=envelope_status)
    try:
        with pytest.raises(BusError,match='Нет свободных номеров'):
            hotel_client.book_room(guest_name='Гость',room_type='lux',date_str=tomorrow(),timeout_sec=2)
    finally:worker.join()


def test_incomplete_booking_response_is_not_success(app,exchange,monkeypatch):
    monkeypatch.setattr(hotel_client,'_send_and_wait',lambda *a,**k:{'status':'ok'})
    with pytest.raises(BusError,match='не подтвердила'):
        hotel_client.book_room(guest_name='Гость',room_type='lux',date_str=tomorrow())


def test_hotel_timeout_preserves_request(app,exchange):
    with pytest.raises(BusError,match='Гостиница не ответила'):
        hotel_client.room_availability(tomorrow(),timeout_sec=0.01)
    assert len(list((exchange/'requests/hotel').glob('*.json')))==1


def test_hotel_page_and_menu(app,client,demo_data,exchange):
    assert client.get('/integrations/hotel').status_code==302
    client_login(client,demo_data['client_user'],app)
    page=client.get('/integrations/hotel')
    assert page.status_code==200
    html=page.get_data(as_text=True)
    assert 'Забронировать номер' in html and 'Проверить свободные номера' in html
    assert 'href="/integrations/hotel"' in html


def test_availability_form_and_type_suggestions(app,client,demo_data,exchange,monkeypatch):
    calls=[]
    def available(day):calls.append(day);return {'date':day,'free_rooms':5,'available_types':['standard','lux']}
    monkeypatch.setattr(hotel_client,'room_availability',available)
    client_login(client,demo_data['client_user'],app)
    response=client.post('/integrations/hotel',data={'action':'availability','search-date':tomorrow()},follow_redirects=True)
    assert response.status_code==200
    html=response.get_data(as_text=True)
    assert 'standard, lux' in html and '<option value="lux">' in html
    assert calls==[tomorrow()]


def test_book_form_prg_no_duplicate_on_refresh(app,client,demo_data,exchange,monkeypatch):
    calls=[]
    def book(**kwargs):calls.append(kwargs);return {'booked':True,'room_number':'204','booking_id':'ROOM-test','guest_name':kwargs['guest_name'],'room_type':kwargs['room_type']}
    monkeypatch.setattr(hotel_client,'book_room',book)
    client_login(client,demo_data['client_user'],app)
    response=client.post('/integrations/hotel',data={'action':'reserve','book-date':tomorrow(),'book-guest_name':'Иван','book-room_type':'lux'})
    assert response.status_code==302
    assert 'ROOM-test' in client.get(response.location).get_data(as_text=True)
    assert client.get(response.location).status_code==200
    assert calls==[{'guest_name':'Иван','room_type':'lux','date_str':tomorrow()}]


def test_hotel_form_validation(app,client,demo_data,exchange,monkeypatch):
    calls=[];monkeypatch.setattr(hotel_client,'book_room',lambda **kwargs:calls.append(kwargs))
    client_login(client,demo_data['client_user'],app)
    response=client.post('/integrations/hotel',data={'action':'reserve','book-date':'bad','book-guest_name':'','book-room_type':''})
    assert response.status_code==200 and not calls
    response=client.post('/integrations/hotel',data={'action':'reserve','book-date':'2020-01-01','book-guest_name':'Иван','book-room_type':'lux'})
    assert 'будущую дату' in response.get_data(as_text=True) and not calls


def test_hotel_timeout_page(app,client,demo_data,exchange,monkeypatch):
    def fail(**kwargs):raise BusError('Гостиница не ответила')
    monkeypatch.setattr(hotel_client,'book_room',fail)
    client_login(client,demo_data['client_user'],app)
    response=client.post('/integrations/hotel',data={'action':'reserve','book-date':tomorrow(),'book-guest_name':'Иван','book-room_type':'lux'})
    assert response.status_code==200
    html=response.get_data(as_text=True)
    assert 'Гостиница не ответила' in html and 'подтвердила бронирование' not in html


def test_dashboard_hotel_button_and_prefilled_requests(app,client,demo_data,exchange):
    login(client,'admin@example.com','test1234')
    html=client.get('/integrations').get_data(as_text=True)
    assert 'Перейти к гостинице' in html
    html=client.get('/integrations?hotel_type=room_availability').get_data(as_text=True)
    assert 'value="room_availability"' in html and 'date' in html
    html=client.get('/integrations?hotel_type=book_room').get_data(as_text=True)
    assert 'value="book_room"' in html and 'room_type' in html and 'standard' in html


def test_hotel_csrf_is_enabled(app,client,demo_data,exchange):
    app.config['WTF_CSRF_ENABLED']=True
    assert client.post('/integrations/hotel',data={'action':'reserve'}).status_code==400


def test_missing_share_is_shown(app,client,demo_data,exchange):
    app.config['BUS_ROOT']=str(exchange/'missing')
    client_login(client,demo_data['client_user'],app)
    html=client.get('/integrations/hotel').get_data(as_text=True)
    assert 'Папка обмена недоступна' in html
    assert not (exchange/'missing').exists()
