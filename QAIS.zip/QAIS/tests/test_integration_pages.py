import json
from datetime import timedelta
import pytest
from flask import g
from app.extensions import db
from app.models import Booking
from app.services import booking_service
from app.services.integrations import quests_client, ui_service
from tests.conftest import login


@pytest.fixture
def exchange(app, tmp_path):
    app.config['BUS_ROOT'] = str(tmp_path)
    return tmp_path


def snapshot(root):
    path=root/'snapshots/gurman.json';path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({'service':'gurman','published_at':'2026-10-20 10:00:00',
                    'payload':{'tables':{'free':10,'total':16}}}),encoding='utf-8')


def client_login(client, user, app):
    app.login_manager.session_protection=None
    with client.session_transaction() as s:
        s['_user_id']=str(user.id);s['_fresh']=True
    g.pop('_login_user', None)


def test_dashboard_menu_and_snapshots(app, client, demo_data, exchange):
    snapshot(exchange)
    login(client,'admin@example.com','test1234')
    page=client.get('/integrations')
    assert page.status_code==200
    html=page.get_data(as_text=True)
    assert 'Шина обмена' in html and 'Гурман' in html and '2026-10-20 10:00:00' in html
    assert 'href="/integrations"' in client.get('/').get_data(as_text=True)


def test_requests_use_text_protocol(app, client, demo_data, exchange):
    login(client,'admin@example.com','test1234')
    response=client.post('/integrations',data={'action':'send','target':'gurman','kind':'ping','payload':'{}'})
    assert response.status_code==302
    files=list((exchange/'requests/gurman').glob('*.json'))
    assert len(files)==1
    data=json.loads(files[0].read_text())
    assert set(data)=={'request_id','from','to','type','created_at','payload'}
    assert data['from']=='quests' and data['to']=='gurman' and data['type']=='ping' and data['payload']=={}
    path=exchange/'responses/quests'/files[0].name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({'request_id':data['request_id'],'from':'gurman','to':'quests','status':'ok',
                                'created_at':'2026-10-20 12:00:00','payload':{'service':'gurman'}}))
    html=client.get(response.location).get_data(as_text=True)
    assert 'Ответ получен' in html and 'gurman' in html
    assert path.exists()  # Viewing never consumes or archives a reply.


@pytest.mark.parametrize('values',[{'target':'../outside','kind':'ping','payload':'{}'},
                                  {'target':'gurman','kind':'ping','payload':'[]'},
                                  {'target':'gurman','kind':'ping','payload':'broken'}])
def test_invalid_requests_write_nothing(app,client,demo_data,exchange,values):
    login(client,'admin@example.com','test1234')
    assert client.post('/integrations',data={'action':'send',**values}).status_code==200
    assert not list(exchange.rglob('*.json'))


def test_missing_share_is_explained(app,client,demo_data,exchange):
    app.config['BUS_ROOT']=str(exchange/'missing')
    login(client,'admin@example.com','test1234')
    html=client.get('/integrations').get_data(as_text=True)
    assert 'Недоступна' in html and 'Папка обмена недоступна' in html
    assert not (exchange/'missing').exists()


def test_corrupted_snapshot_does_not_break_dashboard(app,client,demo_data,exchange):
    path=exchange/'snapshots/broken.json';path.parent.mkdir(parents=True);path.write_text('{')
    login(client,'admin@example.com','test1234')
    page=client.get('/integrations')
    assert page.status_code==200 and 'Не удалось прочитать' in page.get_data(as_text=True)


def test_restaurant_prg_does_not_resend_on_refresh(app,client,demo_data,exchange,monkeypatch):
    snapshot(exchange)
    booking=booking_service.create_booking(demo_data['client_user'],demo_data['slots'][0].id,2)
    bid=booking.id
    when=(booking.slot.end_time+timedelta(minutes=30)).strftime('%Y-%m-%dT%H:%M')
    calls=[]
    def reserve(**kwargs):calls.append(kwargs);return {'table_number':5,'reservation_id':'RES-test'}
    monkeypatch.setattr(quests_client,'reserve_table',reserve)
    client_login(client,demo_data['client_user'],app)
    response=client.post('/integrations/restaurant',data={'action':'reserve','booking_id':bid,'guests':4,'visit_at':when})
    assert response.status_code==302
    assert 'RES-test' in client.get(response.location).get_data(as_text=True)
    assert client.get(response.location).status_code==200
    assert len(calls)==1
    assert calls[0]['guests']==4 and calls[0]['guest_name']=='Клиент Тестов'
    assert calls[0]['time_str']==when.replace('T',' ')
    assert Booking.query.count()==1


def test_restaurant_availability(app,client,demo_data,exchange,monkeypatch):
    monkeypatch.setattr(quests_client,'table_availability',lambda:{'free':10,'total':16})
    client_login(client,demo_data['client_user'],app)
    response=client.post('/integrations/restaurant',data={'action':'availability'},follow_redirects=True)
    assert response.status_code==200 and 'Сейчас свободно 10 из 16' in response.get_data(as_text=True)


def test_other_client_booking_is_not_sent(app,client,demo_data,exchange,monkeypatch):
    booking=booking_service.create_booking(demo_data['client_user'],demo_data['slots'][0].id,2)
    bid=booking.id
    when=(booking.slot.end_time+timedelta(minutes=30)).strftime('%Y-%m-%dT%H:%M')
    from app.models import User
    other=User(role='client',full_name='Other',phone='+79000009999');db.session.add(other);db.session.commit()
    calls=[]
    monkeypatch.setattr(quests_client,'reserve_table',lambda **kw:calls.append(kw))
    client_login(client,other,app)
    response=client.post('/integrations/restaurant',data={'action':'reserve','booking_id':bid,'guests':2,'visit_at':when})
    assert response.status_code==200 and not calls


def test_staff_branch_isolation(app,client,two_branches,exchange,monkeypatch):
    a,b=two_branches['a'],two_branches['b']
    foreign=booking_service.create_booking(b['client'],b['slots'][0].id,2)
    bid=foreign.id;when=(foreign.slot.end_time+timedelta(minutes=30)).strftime('%Y-%m-%dT%H:%M')
    login(client,a['admin'].email,a['admin_pw'])
    calls=[]
    monkeypatch.setattr(quests_client,'reserve_table',lambda **kw:calls.append(kw))
    response=client.post('/integrations/restaurant',data={'action':'reserve','booking_id':bid,'guests':2,'visit_at':when})
    assert response.status_code==200 and not calls


def test_timeout_shows_warning_without_changing_quest(app,client,demo_data,exchange,monkeypatch):
    booking=booking_service.create_booking(demo_data['client_user'],demo_data['slots'][0].id,2)
    bid=booking.id;when=(booking.slot.end_time+timedelta(minutes=30)).strftime('%Y-%m-%dT%H:%M')
    def fail(**kwargs):raise quests_client.BusError('Ресторан не ответил')
    monkeypatch.setattr(quests_client,'reserve_table',fail)
    client_login(client,demo_data['client_user'],app)
    response=client.post('/integrations/restaurant',data={'action':'reserve','booking_id':bid,'guests':2,'visit_at':when})
    assert response.status_code==200 and 'Ресторан не ответил' in response.get_data(as_text=True)
    assert db.session.get(Booking,bid).status=='confirmed'


def test_browser_forms_keep_csrf(app,client,demo_data,exchange):
    app.config['WTF_CSRF_ENABLED']=True
    assert client.post('/integrations',data={'action':'start'}).status_code==400
    assert client.post('/integrations/restaurant',data={'action':'availability'}).status_code==400


def test_own_snapshot_button(app,client,demo_data,exchange):
    login(client,'admin@example.com','test1234')
    response=client.post('/integrations',data={'action':'snapshot'})
    assert response.status_code==302
    assert json.loads((exchange/'snapshots/quests.json').read_text())['service']=='quests'
