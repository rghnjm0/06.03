"""File protocol + real ORM booking; no network share or external restaurant needed."""
import json
import threading
import time
from datetime import datetime, timedelta
import pytest
from app.extensions import db
from app.models import Booking, BusMessage, Slot, User
from app.services.integrations import quests_agent, quests_client
from app.services.integrations.file_bus import BusError, BusTimeout, atomic_write, read_json


@pytest.fixture
def exchange(app, tmp_path):
    app.config.update(BUS_ENABLED=True, BUS_ROOT=str(tmp_path), BUS_SNAPSHOT_INTERVAL=120,
                      BUS_ALLOWED_SENDERS=(), BUS_REQUEST_TIMEOUT=1)
    return tmp_path


def request_file(root, kind, payload=None, rid='req-1', sender='gurman'):
    path = root / 'requests' / 'quests' / (rid + '.json')
    atomic_write(path, {'request_id': rid, 'from': sender, 'to': 'quests', 'type': kind,
                        'created_at': '2026-10-20 12:00:00', 'payload': payload or {}})
    return path


def answer(root, rid='req-1', sender='gurman'):
    return read_json(root / 'responses' / sender / (rid + '.json'))


def booking_payload(data):
    slot = data['slots'][0]
    return {'quest_id': data['quest'].id, 'date': slot.start_time.date().isoformat(),
            'time': slot.start_time.strftime('%H:%M'), 'guest_name': 'Новый Гость',
            'phone': '+79001234567', 'players_count': 2}


def test_ping_snapshot_and_archive(app, demo_data, exchange):
    title = demo_data['quest'].title
    path = request_file(exchange, 'ping')
    quests_agent.poll_once(publish=True)
    assert answer(exchange)['payload']['service'] == 'quests'
    assert not path.exists()
    snapshot = read_json(exchange / 'snapshots/quests.json')
    assert snapshot['payload']['active_quests'] == 1
    assert snapshot['payload']['popular'][0]['title'] == title
    assert snapshot['payload']['popular'][0]['price'] == 1000


def test_availability_uses_real_slots(app, demo_data, exchange):
    p = booking_payload(demo_data)
    slot_id = demo_data['slots'][0].id
    request_file(exchange, 'quest_availability', {'date': p['date'], 'quest_id': p['quest_id']})
    quests_agent.poll_once()
    result = answer(exchange)['payload']
    assert result['count'] == len(demo_data['slots'])
    assert result['details'][0]['slot_id'] == slot_id
    assert result['details'][0]['price'] == 1000


def test_book_quest_is_real_and_replay_is_persistent(app, demo_data, exchange):
    p = booking_payload(demo_data)
    request_file(exchange, 'book_quest', p)
    quests_agent.poll_once()
    result = answer(exchange)
    assert result['status'] == 'ok' and result['payload']['booked'] is True
    booking = db.session.get(Booking, result['payload']['booking_id'])
    assert booking.confirmation_code == result['payload']['confirmation']
    assert booking.source == 'aggregator' and booking.final_price == 1000
    assert db.session.get(Slot, booking.slot_id).status == 'booked'
    assert BusMessage.query.count() == 1
    db.session.remove()  # Simulate next app context/process: no in-memory seen set.
    request_file(exchange, 'book_quest', p)
    quests_agent.poll_once()
    assert answer(exchange) == result
    assert Booking.query.count() == 1 and BusMessage.query.count() == 1


def test_other_request_cannot_book_same_slot(app, demo_data, exchange):
    p = booking_payload(demo_data)
    request_file(exchange, 'book_quest', p)
    quests_agent.poll_once()
    request_file(exchange, 'book_quest', p, rid='req-2')
    quests_agent.poll_once()
    assert answer(exchange, 'req-2')['status'] == 'error'
    assert Booking.query.count() == 1


def test_changed_request_id_conflict(app, demo_data, exchange):
    quest_id = demo_data['quest'].id
    request_file(exchange, 'ping')
    quests_agent.poll_once()
    request_file(exchange, 'quest_lookup', {'quest_id': quest_id})
    quests_agent.poll_once()
    assert answer(exchange)['status'] == 'error'
    assert BusMessage.query.count() == 1


def test_error_rolls_back_guest_and_booking(app, demo_data, exchange):
    p = booking_payload(demo_data)
    slot_id = demo_data['slots'][0].id
    p['players_count'] = 99
    request_file(exchange, 'book_quest', p)
    quests_agent.poll_once()
    assert answer(exchange)['status'] == 'error'
    assert Booking.query.count() == 0
    assert User.query.filter_by(phone=p['phone']).first() is None
    assert db.session.get(Slot, slot_id).status == 'available'


def test_unavailable_and_other_quest(app, demo_data, exchange):
    p = booking_payload(demo_data)
    p['quest_id'] += 1000
    request_file(exchange, 'book_quest', p)
    quests_agent.poll_once()
    assert answer(exchange)['status'] == 'error'
    assert Booking.query.count() == 0


def test_lookup_and_hidden_quest(app, demo_data, exchange):
    from app.models import Quest
    quest_id = demo_data['quest'].id
    request_file(exchange, 'quest_lookup', {'quest_id': quest_id})
    quests_agent.poll_once()
    assert answer(exchange)['payload']['duration_min'] == 60
    db.session.get(Quest, quest_id).is_active = False
    db.session.commit()
    request_file(exchange, 'quest_lookup', {'quest_id': quest_id}, rid='req-2')
    quests_agent.poll_once()
    assert answer(exchange, 'req-2')['payload'] == {'found': False}


def test_path_traversal_is_quarantined(app, exchange):
    request_file(exchange, 'ping', sender='../escaped')
    quests_agent.poll_once()
    assert len(list((exchange / 'processed/quests/rejected').glob('*.json'))) == 1
    assert not (exchange / 'responses').exists() or not list((exchange / 'responses').rglob('*.json'))


def test_unknown_type_and_invalid_json(app, exchange):
    request_file(exchange, 'wrong')
    quests_agent.poll_once()
    assert answer(exchange)['status'] == 'error'
    (exchange / 'requests/quests/broken.json').write_text('{', encoding='utf-8')
    quests_agent.poll_once()
    assert len(list((exchange / 'processed/quests/rejected').glob('*.json'))) == 1


def test_response_write_failure_replays_without_second_booking(app, demo_data, exchange, monkeypatch):
    p = booking_payload(demo_data)
    request_file(exchange, 'book_quest', p)
    write = quests_agent.atomic_write
    def fail(*args, **kwargs):
        raise OSError('share disconnected')
    monkeypatch.setattr(quests_agent, 'atomic_write', fail)
    quests_agent.poll_once()
    assert Booking.query.count() == 1
    assert (exchange / 'requests/quests/req-1.json').exists()
    monkeypatch.setattr(quests_agent, 'atomic_write', write)
    quests_agent.poll_once()
    assert answer(exchange)['status'] == 'ok'
    assert Booking.query.count() == 1


def test_transaction_commit_failure_leaves_no_booking(app, demo_data, exchange, monkeypatch):
    request_file(exchange, 'book_quest', booking_payload(demo_data))
    commit = db.session.commit
    def fail():
        raise RuntimeError('commit failed')
    monkeypatch.setattr(db.session, 'commit', fail)
    quests_agent.poll_once()
    assert Booking.query.count() == 0 and BusMessage.query.count() == 0
    monkeypatch.setattr(db.session, 'commit', commit)
    quests_agent.poll_once()
    assert answer(exchange)['status'] == 'ok' and Booking.query.count() == 1


def test_restaurant_file_roundtrip_and_cached_replay(app, exchange):
    rid = 'dinner-test'
    when = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d %H:%M')
    def restaurant():
        path = exchange / 'requests/gurman' / (rid + '.json')
        until = time.monotonic() + 3
        while not path.exists() and time.monotonic() < until:
            time.sleep(0.01)
        req = read_json(path)
        atomic_write(exchange / 'responses/quests' / (rid + '.json'), {
            'request_id': req['request_id'], 'from': 'gurman', 'to': 'quests', 'status': 'ok',
            'payload': {'table_number': 5, 'seats': 4, 'reservation_id': 'RES-test'}})
        path.unlink()
    worker = threading.Thread(target=restaurant)
    worker.start()
    result = quests_client.reserve_table(guests=4, guest_name='Гость', time_str=when, request_id=rid)
    worker.join()
    assert result['table_number'] == 5
    assert quests_client.reserve_table(guests=4, guest_name='Гость', time_str=when, request_id=rid) == result
    assert not (exchange / 'requests/gurman' / (rid + '.json')).exists()


def test_timeout_has_request_id_and_preserves_request(app, exchange):
    with pytest.raises(BusTimeout) as caught:
        quests_client._send_and_wait('table_availability', {}, timeout_sec=0.02, request_id='timeout-1')
    assert caught.value.request_id == 'timeout-1'
    assert (exchange / 'requests/gurman/timeout-1.json').exists()


def test_snapshot_validates_and_marks_stale(app, exchange):
    assert quests_client.get_restaurant_snapshot() is None
    path = exchange / 'snapshots/gurman.json'
    atomic_write(path, {'service': 'gurman', 'published_at': '2020-01-01 10:00:00',
                        'payload': {'tables': {'free': 2, 'total': 8}}})
    assert quests_client.get_restaurant_snapshot()['stale'] is True
    atomic_write(path, {'service': 'gurman', 'payload': {}})
    assert quests_client.get_restaurant_snapshot() is None


def test_no_fake_root_and_disabled_bus(app, exchange):
    app.config['BUS_ROOT'] = str(exchange / 'missing')
    with pytest.raises(BusError):
        quests_client.table_availability(timeout_sec=0)
    assert not (exchange / 'missing').exists()
    app.config['BUS_ENABLED'] = False
    assert quests_client.get_restaurant_snapshot() is None


def test_dashboard_restricted_and_widget_renders(client, app, demo_data, exchange):
    assert client.get('/integrations').status_code == 302
    assert client.get('/').status_code == 200
    assert client.get('/booking/step2/' + str(demo_data['slots'][0].id)).status_code == 200
    app.login_manager.session_protection = None
    try:
        with client.session_transaction() as session:
            session['_user_id'] = str(demo_data['client_user'].id)
            session['_fresh'] = True
        from flask import g
        g.pop('_login_user', None)
        assert client.get('/integrations').status_code == 403
        assert client.get('/integrations/restaurant').status_code == 200
        with client.session_transaction() as session:
            session['_user_id'] = str(demo_data['superadmin'].id)
        g.pop('_login_user', None)
        assert client.get('/integrations').status_code == 200
    finally:
        app.login_manager.session_protection = 'strong'


def test_dinner_failure_preserves_widget_booking(client, app, demo_data, exchange, monkeypatch):
    from app.blueprints import integrations
    def fail(*args, **kwargs):
        raise BusError('restaurant offline')
    monkeypatch.setattr(integrations, 'reserve_table', fail)
    slot = demo_data['slots'][0]
    response = client.post('/booking/step2/' + str(slot.id), data={
        'slot_id': slot.id, 'full_name': 'Гость', 'phone': '+79007654321',
        'players_count': 2, 'dinner_after': 'y', 'dinner_guests': 2}, follow_redirects=True)
    assert response.status_code == 200
    assert 'restaurant offline' in response.get_data(as_text=True)
    assert Booking.query.count() == 1 and Booking.query.first().status == 'confirmed'


def test_dinner_success_and_own_booking_check(client, app, demo_data, exchange, monkeypatch):
    from app.services import booking_service
    from app.blueprints import integrations
    from flask import g
    booking = booking_service.create_booking(demo_data['client_user'], demo_data['slots'][0].id, 2)
    booking_id = booking.id
    other_id = demo_data['superadmin'].id
    own_id = demo_data['client_user'].id
    visit_at = (booking.slot.end_time + timedelta(minutes=30)).strftime('%Y-%m-%dT%H:%M')
    calls = []
    def reserve(**kwargs):
        calls.append(kwargs)
        return {'table_number': 5, 'reservation_id': 'RES-ok'}
    monkeypatch.setattr(integrations, 'reserve_table', reserve)
    app.login_manager.session_protection = None
    try:
        with client.session_transaction() as session:
            session['_user_id'] = str(other_id)
            session['_fresh'] = True
        g.pop('_login_user', None)
        data = {'action': 'reserve', 'booking_id': booking_id, 'guests': 2, 'visit_at': visit_at}
        assert client.post('/integrations/restaurant', data=data).status_code == 404
        assert not calls
        with client.session_transaction() as session:
            session['_user_id'] = str(own_id)
        g.pop('_login_user', None)
        assert 'RES-ok' in client.post('/integrations/restaurant', data=data).get_data(as_text=True)
        assert 'RES-ok' in client.post('/integrations/restaurant', data=data).get_data(as_text=True)
        assert calls[0]['request_id'] == calls[1]['request_id']
    finally:
        app.login_manager.session_protection = 'strong'


def test_browser_csrf_remains_enabled(client, app, demo_data, exchange):
    from flask import g
    app.login_manager.session_protection = None
    app.config['WTF_CSRF_ENABLED'] = True
    try:
        with client.session_transaction() as session:
            session['_user_id'] = str(demo_data['superadmin'].id)
            session['_fresh'] = True
        g.pop('_login_user', None)
        assert client.post('/integrations', data={'action': 'poll'}).status_code == 400
        assert client.post('/integrations/restaurant', data={'action': 'availability'}).status_code == 400
    finally:
        app.login_manager.session_protection = 'strong'
