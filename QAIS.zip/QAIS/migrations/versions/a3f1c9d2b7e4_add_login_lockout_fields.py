"""add login lockout fields to users

Revision ID: a3f1c9d2b7e4
Revises: dbe7d263cc27
Create Date: 2026-09-29 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a3f1c9d2b7e4'
down_revision = 'dbe7d263cc27'
branch_labels = None
depends_on = None


def upgrade():
    # Простые ADD COLUMN поддерживаются SQLite напрямую (batch-режим с пересозданием
    # таблицы конфликтует с PRAGMA foreign_keys=ON, см. миграцию dbe7d263cc27).
    op.add_column('users', sa.Column('failed_login_count', sa.Integer(), nullable=False, server_default='0'))
    op.add_column('users', sa.Column('locked_until', sa.DateTime(), nullable=True))


def downgrade():
    with op.batch_alter_table('users', schema=None) as batch_op:
        batch_op.drop_column('locked_until')
        batch_op.drop_column('failed_login_count')
