"""add quest is_horror flag

Revision ID: dbe7d263cc27
Revises: 3054eca3eff7
Create Date: 2026-09-28 23:58:35.109136

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'dbe7d263cc27'
down_revision = '3054eca3eff7'
branch_labels = None
depends_on = None


def upgrade():
    # Простое добавление колонки со значением по умолчанию поддерживается SQLite
    # напрямую (ALTER TABLE ... ADD COLUMN) — batch-режим (пересоздание таблицы
    # через DROP+CREATE) здесь не нужен и конфликтует с PRAGMA foreign_keys=ON
    # (app/extensions.py), так как quests ссылаются другие таблицы по FK.
    op.add_column('quests', sa.Column('is_horror', sa.Boolean(), nullable=False, server_default=sa.false()))


def downgrade():
    with op.batch_alter_table('quests', schema=None) as batch_op:
        batch_op.drop_column('is_horror')
