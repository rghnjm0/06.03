from flask import render_template, request, redirect, url_for, flash, session
from datetime import datetime, timedelta
import sqlite3
import os
from db import get_db, DB_NAME
from utils import sync_room_statuses
from auth import login_required, admin_required



def register_auth_routes(app):
    @app.route('/register', methods=['GET', 'POST'])


    def register():


        if request.method == 'POST':


            try:


                last_name = request.form['last_name']


                first_name = request.form['first_name']


                middle_name = request.form.get('middle_name', '')


                phone = request.form['phone']


                birth_date = request.form.get('birth_date', '')


                address = request.form.get('address', '')


                password = request.form['password']


                confirm_password = request.form['confirm_password']





                if not all([last_name, first_name, phone, password]):


                    flash('Заполните все обязательные поля', 'danger')


                    return render_template('register.html')





                if password != confirm_password:


                    flash('Пароли не совпадают', 'danger')


                    return render_template('register.html')





                if len(password) < 6:


                    flash('Пароль должен содержать минимум 6 символов', 'danger')


                    return render_template('register.html')





                conn = get_db()


                cursor = conn.cursor()





                cursor.execute("SELECT ID_Клиента FROM Клиенты WHERE Телефон = ?", (phone,))


                if cursor.fetchone():


                    flash('Клиент с таким телефоном уже зарегистрирован', 'danger')


                    conn.close()


                    return render_template('register.html')





                cursor.execute("SELECT COUNT(*) FROM Клиенты")


                count = cursor.fetchone()[0] + 1


                client_id = f"CL{count:03d}"





                cursor.execute("""


                    INSERT INTO Клиенты (ID_Клиента, Фамилия, Имя, Отчество, Телефон, Дата_рождения, Адрес)


                    VALUES (?, ?, ?, ?, ?, ?, ?)


                """, (client_id, last_name, first_name, middle_name, phone, birth_date or None, address or None))





                cursor.execute("""


                    INSERT INTO Пользователи (ID_Клиента, Логин, Пароль, Роль)


                    VALUES (?, ?, ?, ?)


                """, (client_id, phone, password, 'client'))





                conn.commit()


                conn.close()





                flash('Регистрация успешна! Теперь вы можете войти в систему.', 'success')


                return redirect(url_for('login'))





            except Exception as e:


                flash(f'Ошибка при регистрации: {str(e)}', 'danger')


                return render_template('register.html')





        return render_template('register.html')








    # Вход в систему (единый для всех)


    @app.route('/login', methods=['GET', 'POST'])


    def login():


        if request.method == 'POST':


            try:
                login_value = request.form.get('login', '').strip()
                password = request.form.get('password', '')

                conn = get_db()
                cursor = conn.cursor()

                # Единая авторизация: телефон гостя или логин/телефон администратора.
                if login_value.lower() == 'admin':
                    cursor.execute("""
                        SELECT u.ID_Клиента, u.Роль, u.Пароль,
                               c.Фамилия, c.Имя, c.Отчество
                        FROM Пользователи u
                        LEFT JOIN Клиенты c ON u.ID_Клиента = c.ID_Клиента
                        WHERE u.Роль = 'admin'
                        ORDER BY u.ID
                        LIMIT 1
                    """)
                else:
                    cursor.execute("""
                        SELECT u.ID_Клиента, u.Роль, u.Пароль,
                               c.Фамилия, c.Имя, c.Отчество
                        FROM Пользователи u
                        LEFT JOIN Клиенты c ON u.ID_Клиента = c.ID_Клиента
                        WHERE u.Логин = ?
                    """, (login_value,))

                user = cursor.fetchone()
                conn.close()





                if user and user['Пароль'] == password:


                    session.clear()


                    session['user_id'] = user['ID_Клиента']


                    session['user_role'] = user['Роль']


                    session['user_name'] = f"{user['Фамилия'] or ''} {user['Имя'] or ''}".strip()





                    if user['Роль'] == 'admin':


                        session['admin_id'] = user['ID_Клиента']


                        session['admin_name'] = session['user_name'] or 'Администратор'


                        flash(f'Добро пожаловать в админ-панель, {user["Имя"] or "Администратор"}!', 'success')


                        return redirect(url_for('admin_dashboard'))


                    else:


                        session['client_id'] = user['ID_Клиента']


                        session['client_name'] = session['user_name']


                        flash(f'Добро пожаловать, {user["Имя"]}!', 'success')





                        next_page = request.args.get('next')


                        if next_page:


                            return redirect(next_page)


                        return redirect(url_for('index'))


                else:


                    flash('Неверный телефон/логин или пароль', 'danger')





            except Exception as e:


                flash(f'Ошибка при входе: {str(e)}', 'danger')





        return render_template('login.html')








    # Выход из системы


    @app.route('/logout')


    def logout():


        session.clear()


        flash('Вы вышли из системы', 'info')


        return redirect(url_for('index'))








    # Личный кабинет


    @app.route('/profile')


    @login_required


    def profile():


        try:


            conn = get_db()


            cursor = conn.cursor()





            cursor.execute("SELECT * FROM Клиенты WHERE ID_Клиента = ?", (session['client_id'],))


            client = cursor.fetchone()





            if not client:


                flash('Клиент не найден', 'danger')


                return redirect(url_for('index'))





            cursor.execute("""


                SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,


                       CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) as days_count


                FROM Бронирования b


                JOIN Номера n ON b.ID_Номера = n.ID_Номера


                WHERE b.ID_Клиента = ?


                ORDER BY b.Дата_заезда DESC


            """, (session['client_id'],))





            bookings = cursor.fetchall()


            bookings_with_total = []


            for booking in bookings:


                booking_dict = dict(booking)


                days = booking_dict.get('days_count', 0)


                if days <= 0:


                    days = 1


                booking_dict['total_price'] = days * booking_dict.get('Цена_за_сутки', 0)


                if booking_dict.get('Дата_заезда'):


                    booking_dict['Дата_заезда'] = str(booking_dict['Дата_заезда'])


                if booking_dict.get('Дата_выезда'):


                    booking_dict['Дата_выезда'] = str(booking_dict['Дата_выезда'])


                bookings_with_total.append(booking_dict)





            conn.close()


            return render_template('profile.html', client=client, bookings=bookings_with_total)





        except Exception as e:


            flash(f'Ошибка при загрузке профиля: {str(e)}', 'danger')


            return redirect(url_for('index'))








    # Создание бронирования


    @app.route('/booking/<string:room_id>', methods=['GET', 'POST'])


    @login_required


    def create_booking(room_id):


        try:


            conn = get_db()


            cursor = conn.cursor()





            cursor.execute("SELECT * FROM Номера WHERE ID_Номера = ?", (room_id,))


            room = cursor.fetchone()





            if not room:


                flash('Номер не найден', 'danger')


                conn.close()


                return redirect(url_for('index'))





            if request.method == 'POST':


                check_in = request.form['check_in']


                check_out = request.form['check_out']


                guests = int(request.form['guests'])





                check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()


                check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()


                today = datetime.now().date()





                if check_in_date < today:


                    flash('Дата заезда не может быть в прошлом', 'danger')


                    return render_template('booking.html', room=room,


                                           check_in=check_in, check_out=check_out, guests=guests)





                if check_out_date <= check_in_date:


                    flash('Дата выезда должна быть позже даты заезда', 'danger')


                    return render_template('booking.html', room=room,


                                           check_in=check_in, check_out=check_out, guests=guests)





                if guests > room['Вместимость']:


                    flash(f'Максимальная вместимость номера: {room["Вместимость"]} гостей', 'danger')


                    return render_template('booking.html', room=room,


                                           check_in=check_in, check_out=check_out, guests=guests)





                # Проверяем доступность номера


                cursor.execute("""


                    SELECT ID_Бронирования FROM Бронирования 


                    WHERE ID_Номера = ? 


                    AND Статус IN ('Подтверждено', 'Заселен')


                    AND NOT (Дата_выезда <= ? OR Дата_заезда >= ?)


                """, (room_id, check_in, check_out))





                if cursor.fetchone():


                    flash('Номер недоступен на выбранные даты', 'danger')


                    return render_template('booking.html', room=room,


                                           check_in=check_in, check_out=check_out, guests=guests)





                cursor.execute("SELECT COUNT(*) FROM Бронирования")


                booking_count = cursor.fetchone()[0] + 1


                booking_id = f"BR{booking_count:03d}"





                days = (check_out_date - check_in_date).days


                total_price = days * room['Цена_за_сутки']


                prepayment = total_price * 0.3





                # Создаем бронирование


                cursor.execute("""


                    INSERT INTO Бронирования (


                        ID_Бронирования, ID_Клиента, ID_Номера, 


                        Дата_бронирования, Дата_заезда, Дата_выезда, 


                        Количество_гостей, Статус, Предоплата


                    ) VALUES (?, ?, ?, date('now'), ?, ?, ?, 'Подтверждено', ?)


                """, (booking_id, session['client_id'], room_id,


                      check_in, check_out, guests, prepayment))





                # Обновляем статус номера


                if check_in_date == today or check_in_date == today + timedelta(days=1):


                    cursor.execute("UPDATE Номера SET Статус = 'Занят' WHERE ID_Номера = ?", (room_id,))


                else:


                    cursor.execute("UPDATE Номера SET Статус = 'Будет занят' WHERE ID_Номера = ?", (room_id,))





                # Создаем счет


                cursor.execute("SELECT COUNT(*) FROM Счета")


                invoice_count = cursor.fetchone()[0] + 1


                invoice_id = f"INV{invoice_count:03d}"





                cursor.execute("""


                    INSERT INTO Счета (


                        ID_Счета, ID_Бронирования, Дата_выставления, 


                        Сумма_проживание, Оплачено


                    ) VALUES (?, ?, date('now'), ?, 0)


                """, (invoice_id, booking_id, total_price))





                conn.commit()


                conn.close()





                flash('Бронирование успешно создано!', 'success')


                return redirect(url_for('booking_confirmation', booking_id=booking_id))





            conn.close()





            check_in = request.args.get('check_in', datetime.now().strftime('%Y-%m-%d'))


            check_out = request.args.get('check_out', (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d'))


            guests = request.args.get('guests', 1, type=int)





            return render_template('booking.html', room=room,


                                   check_in=check_in, check_out=check_out, guests=guests)





        except Exception as e:


            flash(f'Ошибка при создании бронирования: {str(e)}', 'danger')


            return redirect(url_for('room_detail', room_id=room_id))








    # Подтверждение бронирования


    @app.route('/booking/confirmation/<string:booking_id>')


    @login_required


    def booking_confirmation(booking_id):


        try:


            conn = get_db()


            cursor = conn.cursor()





            cursor.execute("""


                SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,


                       CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) as days_count,


                       c.Фамилия, c.Имя, c.Отчество


                FROM Бронирования b


                JOIN Номера n ON b.ID_Номера = n.ID_Номера


                JOIN Клиенты c ON b.ID_Клиента = c.ID_Клиента


                WHERE b.ID_Бронирования = ? AND b.ID_Клиента = ?


            """, (booking_id, session['client_id']))





            booking = cursor.fetchone()


            conn.close()





            if not booking:


                flash('Бронирование не найдено', 'danger')


                return redirect(url_for('profile'))





            booking_dict = dict(booking)


            days = booking_dict.get('days_count', 0)


            if days <= 0:


                days = 1


            booking_dict['total_price'] = days * booking_dict.get('Цена_за_сутки', 0)





            return render_template('confirmation.html', booking=booking_dict)





        except Exception as e:


            flash(f'Ошибка при загрузке подтверждения: {str(e)}', 'danger')


            return redirect(url_for('profile'))








    # Отмена бронирования


    @app.route('/booking/cancel/<string:booking_id>')


    @login_required


    def cancel_booking(booking_id):


        try:


            conn = get_db()


            cursor = conn.cursor()





            cursor.execute("""


                SELECT Дата_заезда, ID_Номера FROM Бронирования 


                WHERE ID_Бронирования = ? AND ID_Клиента = ?


            """, (booking_id, session['client_id']))





            booking = cursor.fetchone()





            if not booking:


                flash('Бронирование не найдено', 'danger')


                conn.close()


                return redirect(url_for('profile'))





            check_in = datetime.strptime(booking['Дата_заезда'], '%Y-%m-%d').date()


            today = datetime.now().date()





            if check_in <= today:


                flash('Невозможно отменить бронирование в день заезда или позже', 'danger')


                conn.close()


                return redirect(url_for('profile'))





            # Обновляем статус бронирования


            cursor.execute("""


                UPDATE Бронирования 


                SET Статус = 'Отменено' 


                WHERE ID_Бронирования = ?


            """, (booking_id,))





            # Проверяем, есть ли другие активные брони на этот номер


            cursor.execute("""


                SELECT COUNT(*) FROM Бронирования 


                WHERE ID_Номера = ? AND Статус IN ('Подтверждено', 'Заселен')


            """, (booking['ID_Номера'],))





            if cursor.fetchone()[0] == 0:


                cursor.execute("UPDATE Номера SET Статус = 'Свободен' WHERE ID_Номера = ?", (booking['ID_Номера'],))


            else:


                # Если есть другие брони, нужно пересчитать статус


                sync_room_statuses()





            conn.commit()


            conn.close()





            flash('Бронирование успешно отменено', 'success')


            return redirect(url_for('profile'))





        except Exception as e:


            flash(f'Ошибка при отмене бронирования: {str(e)}', 'danger')


            return redirect(url_for('profile'))








    # Контакты
