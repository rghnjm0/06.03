SupportDesk — все формы (старые + новые)

Папка forms/ — полный набор форм проекта.

НОВЫЕ модули (добавлены):
  ContractsForm.cs + Designer.cs     — Договоры и гарантии
  ServerRoomLogForm.cs + Designer.cs — Журнал посещений серверной
  ModulesSchema.cs                   — таблицы Contracts и ServerRoomLog

СТАРЫЕ (уже были в проекте):
  ContactsForm, InventoryForm, LicensesForm, CartridgesForm,
  MainAdminForm, MainWorkerForm, MainUserForm, LoginForm,
  PasswordsForm, DirectoryForm, UsersForm, и остальные.

КАК ИСПОЛЬЗОВАТЬ:
1. Скопируй содержимое forms/ в папку forms своего проекта (с заменой).
2. Если были NewModulesSchema.* — удали их.
3. В MainAdminForm_Load и MainWorkerForm_Load должен быть вызов AddNewModuleButtons()
   (уже есть в MainAdminForm.cs / MainWorkerForm.cs из этого архива).
4. Rebuild решения.

ContactsForm — это СТАРАЯ форма контактов. ContractsForm — НОВАЯ (договоры).
