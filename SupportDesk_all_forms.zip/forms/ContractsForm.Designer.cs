namespace SupportDesk.forms
{
    partial class ContractsForm
    {
        private void InitializeComponent()
        {
        }
    }
}
