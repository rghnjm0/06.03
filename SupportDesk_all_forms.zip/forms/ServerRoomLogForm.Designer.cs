namespace SupportDesk.forms
{
    partial class ServerRoomLogForm
    {
        private void InitializeComponent()
        {
        }
    }
}
