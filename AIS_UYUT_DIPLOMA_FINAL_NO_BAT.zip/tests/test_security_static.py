from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_no_legacy_login_readme():
    assert not (ROOT / 'LOGIN_FIX_README.txt').exists()


def test_no_hardcoded_demo_passwords_in_source():
    source = '\n'.join(p.read_text(encoding='utf-8') for p in ROOT.glob('*.py'))
    assert "or 'pass123'" not in source
    assert 'or "admin123"' not in source
    assert "or 'admin123'" not in source


def test_database_path_is_project_relative():
    text = (ROOT / 'db.py').read_text(encoding='utf-8')
    assert 'os.path.abspath(__file__)' in text
    assert 'DB_NAME = os.path.join(BASE_DIR' in text


def test_logout_is_post():
    text = (ROOT / 'routes' / 'auth.py').read_text(encoding='utf-8')
    assert "@app.route('/logout', methods=['POST'])" in text


def test_csrf_present_in_templates_with_forms():
    missing = []
    for template in (ROOT / 'templates').rglob('*.html'):
        text = template.read_text(encoding='utf-8')
        if 'method="post"' in text.lower() and '_csrf_token' not in text:
            missing.append(str(template.relative_to(ROOT)))
    assert not missing, f'Missing CSRF token: {missing}'
