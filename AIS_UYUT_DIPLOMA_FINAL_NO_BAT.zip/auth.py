"""Авторизация и проверки доступа."""
from functools import wraps
from flask import session, flash, redirect, url_for
from werkzeug.security import check_password_hash, generate_password_hash


def password_matches(stored, supplied):
    """Проверяет только безопасные password hashes."""
    if not stored or not supplied:
        return False
    try:
        return check_password_hash(stored, supplied)
    except (TypeError, ValueError):
        return False


def hash_password(password):
    return generate_password_hash(password)


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "client_id" not in session and session.get("user_role") != "admin":
            flash("Требуется авторизация", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_role") != "admin":
            flash("Недостаточно прав", "danger")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function
