# Security and deployment notes

- Never deploy with the development environment or demo data.
- Production startup refuses to create a missing database. Provision and migrate it explicitly.
- Set a unique `UYUT_SECRET_KEY`, enable HTTPS, and set `UYUT_ENV=production`.
- Back up the database before any schema/data migration; test restoration.
- Do not distribute a production database or `.env` file.
- Demo/test data is intended only for development. Generated credentials are printed once during initial development seeding; store them securely.
- The bootstrap administrator is created only during first-time local database initialization. Existing admin credentials are not overwritten.
- This hardening pass is not a guarantee of security. Before production, run dynamic authorization, payment-webhook, concurrency, dependency, and restore tests.
