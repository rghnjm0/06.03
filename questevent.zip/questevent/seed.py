"""Скрипт наполнения БД демонстрационными данными.

Использование:
    flask seed-demo
или напрямую:
    python seed.py

Наполняет базу расширенным набором данных для полноценной демонстрации
всех подсистем: два филиала, несколько локаций/комнат/квестов, клиенты
с историей бронирований (проведённые/отменённые/предстоящие), отзывы,
промокоды и сертификаты в разных состояниях (активные/исчерпанные/
просроченные) — чтобы CRM, отчёты, календарь и виджет не выглядели пустыми
сразу после `flask seed-demo`.
"""
from datetime import date, timedelta, time

from app import create_app
from app.extensions import db
from app.models import (
    Branch, Location, Room, Quest, Tariff, User, PromoCode, Certificate,
    ChecklistTemplate, ChecklistItem, Review,
)
from app.constants import (
    ROLE_SUPERADMIN, ROLE_LOCATION_ADMIN, ROLE_HOST, ROLE_MANAGER, ROLE_ACCOUNTANT,
    ROLE_CLIENT, BOOKING_NO_SHOW,
)
from app.services import schedule_service, booking_service


def run_seed():
    db.create_all()

    if Branch.query.first():
        print("База уже содержит данные — пропускаем наполнение.")
        return

    # ------------------------------------------------------------------
    # Филиалы и локации (multi-tenant, ТЗ п.4.2.2)
    # ------------------------------------------------------------------
    branch_msk = Branch(name="QuestEvent Москва", city="Москва",
                         address="ул. Тверская, 1", phone="+7 495 000-00-00")
    branch_spb = Branch(name="QuestEvent Санкт-Петербург", city="Санкт-Петербург",
                         address="Невский пр-т, 28", phone="+7 812 000-00-00")
    db.session.add_all([branch_msk, branch_spb])
    db.session.flush()

    loc_tverskaya = Location(branch_id=branch_msk.id, name="Локация на Тверской",
                              address="ул. Тверская, 1")
    loc_arbat = Location(branch_id=branch_msk.id, name="Локация на Арбате",
                          address="ул. Арбат, 25")
    loc_nevsky = Location(branch_id=branch_spb.id, name="Локация на Невском",
                           address="Невский пр-т, 28")
    db.session.add_all([loc_tverskaya, loc_arbat, loc_nevsky])
    db.session.flush()

    # ------------------------------------------------------------------
    # Комнаты и квесты (6 штук на 3 локации)
    # ------------------------------------------------------------------
    room1 = Room(location_id=loc_tverskaya.id, name="Комната «Тайна пирамиды»")
    room2 = Room(location_id=loc_tverskaya.id, name="Комната «Заброшенный госпиталь»")
    room3 = Room(location_id=loc_arbat.id, name="Комната «Особняк с привидениями»")
    room4 = Room(location_id=loc_arbat.id, name="Комната «Секретная лаборатория»")
    room5 = Room(location_id=loc_nevsky.id, name="Комната «Побег из тюрьмы»")
    room6 = Room(location_id=loc_nevsky.id, name="Комната «Пиратский корабль»")
    db.session.add_all([room1, room2, room3, room4, room5, room6])
    db.session.flush()

    quest1 = Quest(room_id=room1.id, title="Тайна пирамиды",
                    description="Исследуйте гробницу фараона за 60 минут.",
                    difficulty="средний", duration_minutes=60, min_players=2, max_players=6, min_age=10)
    quest2 = Quest(room_id=room2.id, title="Заброшенный госпиталь",
                    description="Хоррор-квест для смелых.",
                    difficulty="сложный", duration_minutes=60, min_players=3, max_players=5, min_age=16)
    quest3 = Quest(room_id=room3.id, title="Особняк с привидениями",
                    description="Старинный особняк хранит немало тайн и призраков.",
                    difficulty="средний", duration_minutes=75, min_players=2, max_players=8, min_age=12)
    quest4 = Quest(room_id=room4.id, title="Секретная лаборатория",
                    description="Семейный квест: соберите антидот за 45 минут.",
                    difficulty="легкий", duration_minutes=45, min_players=2, max_players=6, min_age=8)
    quest5 = Quest(room_id=room5.id, title="Побег из тюрьмы",
                    description="Классика жанра — выберитесь из камеры до рассвета.",
                    difficulty="сложный", duration_minutes=60, min_players=2, max_players=5, min_age=14)
    quest6 = Quest(room_id=room6.id, title="Пиратский корабль",
                    description="Найдите сокровища капитана, пока корабль не затонул.",
                    difficulty="средний", duration_minutes=60, min_players=3, max_players=7, min_age=10)
    quests = [quest1, quest2, quest3, quest4, quest5, quest6]
    db.session.add_all(quests)
    db.session.flush()

    # ------------------------------------------------------------------
    # Тарифы
    # ------------------------------------------------------------------
    tariff1 = Tariff(quest_id=quest1.id, name="Будни", weekday_mask="0,1,2,3,4", time_from="10:00", time_to="17:00",
                      price_per_slot=3000, price_per_extra_player=300, priority=1)
    tariff2 = Tariff(quest_id=quest1.id, name="Вечер/выходные", weekday_mask="0,1,2,3,4,5,6",
                      time_from="00:00", time_to="23:59",
                      price_per_slot=4000, price_per_extra_player=400, priority=0)
    tariff3 = Tariff(quest_id=quest2.id, name="Базовый", weekday_mask="0,1,2,3,4,5,6",
                      time_from="00:00", time_to="23:59",
                      price_per_slot=4500, price_per_extra_player=500, priority=0)
    tariff4 = Tariff(quest_id=quest3.id, name="Базовый", weekday_mask="0,1,2,3,4,5,6",
                      time_from="00:00", time_to="23:59",
                      price_per_slot=3800, price_per_extra_player=350, priority=0)
    tariff5 = Tariff(quest_id=quest4.id, name="Базовый", weekday_mask="0,1,2,3,4,5,6",
                      time_from="00:00", time_to="23:59",
                      price_per_slot=2500, price_per_extra_player=250, priority=0)
    tariff6 = Tariff(quest_id=quest5.id, name="Будни", weekday_mask="0,1,2,3,4", time_from="00:00", time_to="23:59",
                      price_per_slot=3200, price_per_extra_player=300, priority=1)
    tariff7 = Tariff(quest_id=quest5.id, name="Выходные", weekday_mask="5,6", time_from="00:00", time_to="23:59",
                      price_per_slot=4200, price_per_extra_player=400, priority=2)
    tariff8 = Tariff(quest_id=quest6.id, name="Базовый", weekday_mask="0,1,2,3,4,5,6",
                      time_from="00:00", time_to="23:59",
                      price_per_slot=3600, price_per_extra_player=320, priority=0)
    db.session.add_all([tariff1, tariff2, tariff3, tariff4, tariff5, tariff6, tariff7, tariff8])

    # ------------------------------------------------------------------
    # Чек-листы подготовки комнаты
    # ------------------------------------------------------------------
    checklist_items_common = [
        "Проверить реквизит и декорации", "Проверить работу замков/датчиков",
        "Убрать следы предыдущей игры", "Проверить освещение и звук",
    ]
    for quest, extra_item in [
        (quest1, "Проверить целостность саркофага"),
        (quest2, "Проверить работу спецэффектов (свет/звук пугалок)"),
        (quest3, "Проверить механизм потайной двери"),
    ]:
        checklist = ChecklistTemplate(quest_id=quest.id, name="Подготовка к сеансу")
        db.session.add(checklist)
        db.session.flush()
        for i, text in enumerate(checklist_items_common + [extra_item]):
            db.session.add(ChecklistItem(template_id=checklist.id, text=text, order=i))

    # ------------------------------------------------------------------
    # Сотрудники
    # ------------------------------------------------------------------
    staff = [
        ("Суперадминистратор", "superadmin@questevent.ru", ROLE_SUPERADMIN, None),
        ("Администратор Тверской", "admin@questevent.ru", ROLE_LOCATION_ADMIN, branch_msk.id),
        ("Ведущий Иван", "host@questevent.ru", ROLE_HOST, branch_msk.id),
        ("Менеджер Ольга", "manager@questevent.ru", ROLE_MANAGER, branch_msk.id),
        ("Бухгалтер Мария", "accountant@questevent.ru", ROLE_ACCOUNTANT, branch_msk.id),
        ("Администратор Невского", "admin.spb@questevent.ru", ROLE_LOCATION_ADMIN, branch_spb.id),
        ("Ведущий Пётр", "host.spb@questevent.ru", ROLE_HOST, branch_spb.id),
        ("Менеджер Анна", "manager.spb@questevent.ru", ROLE_MANAGER, branch_spb.id),
    ]
    for name, email, role, b_id in staff:
        u = User(full_name=name, email=email, role=role, branch_id=b_id)
        u.set_password("admin123")
        db.session.add(u)

    # ------------------------------------------------------------------
    # Клиенты (для CRM, истории бронирований и отзывов)
    # ------------------------------------------------------------------
    client_seed = [
        ("Анна Соколова", "anna.sokolova@example.com", "+79261110001", 120, "Серебро"),
        ("Дмитрий Волков", "dmitry.volkov@example.com", "+79261110002", 40, "Новичок"),
        ("Екатерина Морозова", "ekaterina.morozova@example.com", "+79261110003", 310, "Золото"),
        ("Сергей Кузнецов", "sergey.kuznetsov@example.com", "+79261110004", 0, "Новичок"),
        ("Ольга Новикова", "olga.novikova@example.com", "+79261110005", 75, "Новичок"),
        ("Иван Попов", "ivan.popov@example.com", "+79261110006", 200, "Серебро"),
        ("Мария Лебедева", None, "+79261110007", 10, "Новичок"),
        ("Алексей Козлов", "alexey.kozlov@example.com", "+79261110008", 450, "Золото"),
        ("Наталья Соловьёва", "natalia.solovyova@example.com", "+79261110009", 60, "Новичок"),
        ("Павел Морозов", None, "+79261110010", 15, "Новичок"),
        ("Виктория Егорова", "victoria.egorova@example.com", "+79261110011", 90, "Серебро"),
        ("Роман Никитин", "roman.nikitin@example.com", "+79261110012", 5, "Новичок"),
        ("Юлия Кириллова", "yulia.kirillova@example.com", "+79261110013", 260, "Золото"),
        ("Максим Фёдоров", "maxim.fedorov@example.com", "+79261110014", 30, "Новичок"),
    ]
    clients = []
    for name, email, phone, points, status in client_seed:
        c = User(role=ROLE_CLIENT, full_name=name, email=email, phone=phone,
                 loyalty_points=points, loyalty_status=status)
        c.set_password("client123")
        db.session.add(c)
        clients.append(c)

    # ------------------------------------------------------------------
    # Промокоды — активный / с частичным использованием / исчерпанный / просроченный
    # ------------------------------------------------------------------
    today = date.today()
    db.session.add(PromoCode(code="WELCOME10", discount_percent=10, usage_limit=0))
    db.session.add(PromoCode(code="SUMMER15", discount_percent=15,
                              valid_from=today - timedelta(days=20), valid_to=today + timedelta(days=40),
                              usage_limit=50, used_count=12))
    db.session.add(PromoCode(code="FIRSTGAME", discount_amount=500, usage_limit=1, used_count=1))
    db.session.add(PromoCode(code="OLDPROMO", discount_percent=20,
                              valid_from=today - timedelta(days=90), valid_to=today - timedelta(days=30)))

    # ------------------------------------------------------------------
    # Сертификаты — активный / частично потрачен / полностью потрачен / просрочен
    # ------------------------------------------------------------------
    db.session.add(Certificate(code="GIFT1000", initial_balance=1000, balance=1000,
                                expires_at=today + timedelta(days=365)))
    db.session.add(Certificate(code="GIFT2000", initial_balance=2000, balance=2000,
                                expires_at=today + timedelta(days=180), issued_to_name="Иван Петров"))
    db.session.add(Certificate(code="GIFT500USED", initial_balance=500, balance=0,
                                expires_at=today + timedelta(days=60), issued_to_name="Анна Соколова"))
    db.session.add(Certificate(code="GIFTEXPIRED", initial_balance=1500, balance=1500,
                                expires_at=today - timedelta(days=5), issued_to_name="Сергей Кузнецов"))

    db.session.commit()

    # ------------------------------------------------------------------
    # Расписание: прошлые 14 дней (для истории) + ближайшие 14 дней
    # ------------------------------------------------------------------
    past_from, past_to = today - timedelta(days=14), today - timedelta(days=1)
    future_from, future_to = today, today + timedelta(days=13)

    room_quest_pairs = [
        (room1, quest1), (room2, quest2), (room3, quest3),
        (room4, quest4), (room5, quest5), (room6, quest6),
    ]
    for room, quest in room_quest_pairs:
        schedule_service.generate_slots_for_room(room, quest, past_from, past_to, time(10, 0), time(22, 0))
        schedule_service.generate_slots_for_room(room, quest, future_from, future_to, time(10, 0), time(22, 0))

    # ------------------------------------------------------------------
    # История бронирований на прошлых сеансах: проведённые (+ отзывы),
    # отменённые, неявка — чтобы отчёты/CRM/виджет не были пустыми.
    # ------------------------------------------------------------------
    from app.models.slot import Slot
    from app.constants import SLOT_AVAILABLE

    def past_slots_for(room, n=6):
        return (
            Slot.query.filter(Slot.room_id == room.id, Slot.status == SLOT_AVAILABLE,
                               Slot.start_time < today)
            .order_by(Slot.start_time.asc())
            .limit(n)
            .all()
        )

    review_texts = [
        (5, "Потрясающая атмосфера, ведущий на высоте! Обязательно вернёмся."),
        (4, "Очень понравилось, один момент показался слишком сложным, но в целом супер."),
        (5, "Лучший квест из тех, что проходили в этом году!"),
        (3, "Неплохо, но декорации немного устарели."),
        (5, "Атмосферно, страшно, азартно — всё как надо."),
    ]

    booking_plan = [
        # (room, quest, client, players, статус_после, отзыв?)
        (room1, quest1, clients[0], 4, "completed", 0),
        (room1, quest1, clients[1], 2, "completed", 1),
        (room2, quest2, clients[2], 3, "completed", 2),
        (room2, quest2, clients[3], 4, "canceled", None),
        (room3, quest3, clients[4], 5, "completed", 3),
        (room3, quest3, clients[5], 2, "completed", 4),
        (room4, quest4, clients[6], 3, "no_show", None),
        (room5, quest5, clients[7], 2, "completed", None),
        (room6, quest6, clients[8], 4, "canceled", None),
        (room1, quest1, clients[9], 3, "completed", None),
    ]

    for room, quest, client, players, outcome, review_idx in booking_plan:
        available = past_slots_for(room)
        if not available:
            continue
        slot = available[0]
        try:
            booking = booking_service.create_booking(
                client=client, slot_id=slot.id, players_count=min(players, quest.max_players),
                source="admin",
            )
        except Exception:
            continue

        if outcome == "completed":
            booking_service.mark_completed(booking)
            if review_idx is not None:
                rating, text = review_texts[review_idx]
                db.session.add(Review(booking_id=booking.id, client_id=client.id, rating=rating, text=text))
                db.session.commit()
        elif outcome == "canceled":
            booking_service.cancel_booking(booking, reason="Клиент попросил перенести, но не вышло",
                                            free_cancellation_hours=0)
        elif outcome == "no_show":
            booking.status = BOOKING_NO_SHOW
            db.session.commit()

    # ------------------------------------------------------------------
    # Несколько предстоящих подтверждённых броней (в т.ч. с промокодом/сертификатом)
    # ------------------------------------------------------------------
    def future_slots_for(room, n=3):
        return (
            Slot.query.filter(Slot.room_id == room.id, Slot.status == SLOT_AVAILABLE,
                               Slot.start_time >= today)
            .order_by(Slot.start_time.asc())
            .limit(n)
            .all()
        )

    upcoming_plan = [
        (room1, quest1, clients[10], 2, "WELCOME10", None),
        (room3, quest3, clients[11], 3, None, "GIFT1000"),
        (room5, quest5, clients[12], 2, "SUMMER15", None),
        (room2, quest2, clients[13], 4, None, None),
    ]
    for room, quest, client, players, promo_code, cert_code in upcoming_plan:
        available = future_slots_for(room)
        if not available:
            continue
        slot = available[0]
        try:
            booking_service.create_booking(
                client=client, slot_id=slot.id, players_count=min(players, quest.max_players),
                promo_code=promo_code, certificate_code=cert_code, source="widget",
            )
        except Exception:
            continue

    print("Демо-данные успешно созданы.")


if __name__ == "__main__":
    app = create_app("development")
    with app.app_context():
        run_seed()