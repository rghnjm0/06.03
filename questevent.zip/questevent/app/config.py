import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))


class Config:
    """Базовая конфигурация приложения."""

    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")

    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///" + os.path.join(basedir, "instance", "questevent.db")
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        # Гарантирует включение внешних ключей и ускоряет запись в SQLite (WAL)
        "connect_args": {"check_same_thread": False},
    }

    WTF_CSRF_ENABLED = True

    # --- Безопасность сессии/cookie ---
    # HttpOnly и SameSite защищают cookie сессии от кражи через XSS и от
    # межсайтовых запросов (CSRF); Secure включается отдельно в
    # ProductionConfig, когда приложение обслуживается по HTTPS.
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = False
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_SECURE = False
    REMEMBER_COOKIE_DURATION = timedelta(days=14)
    PERMANENT_SESSION_LIFETIME = timedelta(hours=12)

    CACHE_TYPE = os.environ.get("CACHE_TYPE", "SimpleCache")
    CACHE_DEFAULT_TIMEOUT = 60

    LANGUAGES = ["ru", "en"]
    BABEL_DEFAULT_LOCALE = "ru"

    # Бизнес-параметры (могут быть переопределены в БД / настройках филиала)
    REMINDER_24H_HOURS_BEFORE = 24
    REMINDER_2H_HOURS_BEFORE = 2
    REVIEW_REQUEST_DELAY = timedelta(hours=3)
    DEFAULT_SLOT_STEP_MINUTES = 60
    CANCELLATION_FREE_HOURS = 24  # бесплатная отмена не позднее чем за N часов

    REMINDER_POLL_SECONDS = int(os.environ.get("REMINDER_POLL_SECONDS", "60"))
    SCHEDULER_ENABLED = os.environ.get("SCHEDULER_ENABLED", "1") == "1"

    ITEMS_PER_PAGE = 20


class DevelopmentConfig(Config):
    DEBUG = True


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False
    SCHEDULER_ENABLED = False
    SECRET_KEY = "testing-secret-key"
    # StaticPool + shared connection необходимы, чтобы in-memory SQLite не
    # "терялась" между запросами теста (иначе каждое новое соединение получает
    # собственную пустую базу).
    from sqlalchemy.pool import StaticPool
    SQLALCHEMY_ENGINE_OPTIONS = {
        "connect_args": {"check_same_thread": False},
        "poolclass": StaticPool,
    }


class ProductionConfig(Config):
    DEBUG = False
    SESSION_COOKIE_SECURE = True
    REMEMBER_COOKIE_SECURE = True


config_by_name = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
}
