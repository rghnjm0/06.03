"""Небольшие переиспользуемые утилиты общего назначения."""
from urllib.parse import urlparse


def is_safe_redirect_target(target: str | None) -> bool:
    """Разрешает редирект только на относительный локальный путь (CWE-601:
    без этой проверки значения вроде ?next=<url> или заголовка Referer
    позволяют открытый редирект на произвольный внешний сайт — фишинг под
    видом самого приложения)."""
    if not target:
        return False
    parsed = urlparse(target)
    return not parsed.scheme and not parsed.netloc and target.startswith("/") and not target.startswith("//")
