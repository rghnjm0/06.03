"""Отчётность и аналитика. ТЗ п.4.2.7: загрузка, выручка, конверсия, эффективность."""
import csv
import io
from datetime import date, datetime, time

from sqlalchemy import func, case

from app.extensions import db
from app.models.slot import Slot
from app.models.booking import Booking
from app.models.quest import Quest
from app.models.room import Room
from app.models.user import User
from app.constants import (
    SLOT_BOOKED, SLOT_COMPLETED, BOOKING_CANCELED, BOOKING_COMPLETED,
    BOOKING_CONFIRMED,
)


def _date_range_filter(query, model_datetime_col, date_from: date, date_to: date):
    return query.filter(
        model_datetime_col >= datetime.combine(date_from, time.min),
        model_datetime_col <= datetime.combine(date_to, time.max),
    )


def occupancy_report(date_from: date, date_to: date, branch_id: int | None = None):
    """Загрузка локаций/комнат: доля занятых сеансов от общего числа."""
    q = (
        db.session.query(
            Room.name.label("room"),
            func.count(Slot.id).label("total_slots"),
            func.sum(case((Slot.status.in_([SLOT_BOOKED, SLOT_COMPLETED]), 1), else_=0)).label("booked_slots"),
        )
        .join(Room, Room.id == Slot.room_id)
    )
    if branch_id:
        from app.models.location import Location
        q = q.join(Location, Location.id == Room.location_id).filter(Location.branch_id == branch_id)
    q = _date_range_filter(q, Slot.start_time, date_from, date_to).group_by(Room.id)

    rows = []
    for room, total, booked in q.all():
        booked = booked or 0
        rate = round((booked / total) * 100, 1) if total else 0.0
        rows.append({"room": room, "total_slots": total, "booked_slots": booked, "occupancy_pct": rate})
    return rows


def revenue_report(date_from: date, date_to: date, branch_id: int | None = None):
    """Выручка, средний чек и конверсия за период."""
    bookings_q = Booking.query.join(Slot, Slot.id == Booking.slot_id)
    if branch_id:
        from app.models.room import Room as RoomModel
        from app.models.location import Location
        bookings_q = (
            bookings_q.join(RoomModel, RoomModel.id == Slot.room_id)
            .join(Location, Location.id == RoomModel.location_id)
            .filter(Location.branch_id == branch_id)
        )
    bookings_q = _date_range_filter(bookings_q, Booking.created_at, date_from, date_to)
    bookings = bookings_q.all()

    total_bookings = len(bookings)
    canceled = sum(1 for b in bookings if b.status == BOOKING_CANCELED)
    confirmed_or_completed = [b for b in bookings if b.status in (BOOKING_CONFIRMED, BOOKING_COMPLETED)]
    revenue = sum(float(b.final_price) for b in bookings if b.status in (BOOKING_CONFIRMED, BOOKING_COMPLETED))
    avg_check = round(revenue / len(confirmed_or_completed), 2) if confirmed_or_completed else 0.0
    conversion = round((len(confirmed_or_completed) / total_bookings) * 100, 1) if total_bookings else 0.0

    return {
        "total_bookings": total_bookings,
        "canceled_bookings": canceled,
        "confirmed_bookings": len(confirmed_or_completed),
        "revenue": round(revenue, 2),
        "avg_check": avg_check,
        "conversion_pct": conversion,
    }


def quest_effectiveness_report(date_from: date, date_to: date):
    q = (
        db.session.query(
            Quest.title,
            func.count(Booking.id).label("bookings_count"),
        )
        .join(Slot, Slot.quest_id == Quest.id)
        .join(Booking, Booking.slot_id == Slot.id)
        .filter(Booking.status != BOOKING_CANCELED)
    )
    q = _date_range_filter(q, Booking.created_at, date_from, date_to).group_by(Quest.id)
    return [{"quest": title, "bookings_count": cnt} for title, cnt in q.order_by(func.count(Booking.id).desc()).all()]


def host_effectiveness_report(date_from: date, date_to: date):
    """Эффективность администраторов, оформивших бронирования (created_by)."""
    q = (
        db.session.query(User.full_name, func.count(Booking.id))
        .join(Booking, Booking.created_by_id == User.id)
        .filter(Booking.status != BOOKING_CANCELED)
    )
    q = _date_range_filter(q, Booking.created_at, date_from, date_to).group_by(User.id)
    return [{"host": name, "bookings_count": cnt} for name, cnt in q.all()]


def kpi_dashboard(branch_id: int | None = None):
    """Ключевые показатели в реальном времени для дашборда руководителя (ТЗ п.4.2.7)."""
    today = date.today()
    month_start = today.replace(day=1)
    rev = revenue_report(month_start, today, branch_id)
    occ = occupancy_report(month_start, today, branch_id)
    avg_occupancy = round(sum(r["occupancy_pct"] for r in occ) / len(occ), 1) if occ else 0.0
    return {
        "period": f"{month_start:%d.%m.%Y} — {today:%d.%m.%Y}",
        **rev,
        "avg_occupancy_pct": avg_occupancy,
    }


def export_rows_to_csv(rows: list[dict]) -> io.BytesIO:
    output = io.StringIO()
    if rows:
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    buf = io.BytesIO(output.getvalue().encode("utf-8-sig"))  # BOM для корректного Excel
    buf.seek(0)
    return buf


def export_rows_to_xlsx(rows: list[dict], sheet_title: str = "Отчёт") -> io.BytesIO:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = sheet_title[:31]
    if rows:
        headers = list(rows[0].keys())
        ws.append(headers)
        for row in rows:
            ws.append([row[h] for h in headers])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
