"""Оркестрация создания/отмены/переноса бронирований.

Ключевое требование ТЗ п.2.2.2 и п.4.2.1: «автоматический контроль конфликтов
и блокировка двойного бронирования одного слота». Реализовано двумя рубежами
защиты:
  1) проверка статуса Slot.status == available перед созданием брони;
  2) уникальный индекс (room_id, start_time) на Slot и unique(slot_id) на
     Booking на уровне БД — при гонке запросов вторая транзакция получит
     IntegrityError, который перехватывается и превращается в понятную ошибку.
"""
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy.exc import IntegrityError

from app.extensions import db
from app.models.slot import Slot
from app.models.booking import Booking
from app.models.certificate import Certificate
from app.models.promocode import PromoCode
from app.constants import (
    SLOT_AVAILABLE, SLOT_BOOKED, SLOT_CANCELED, SLOT_COMPLETED,
    BOOKING_NEW, BOOKING_CONFIRMED, BOOKING_CANCELED,
)
from app.services import pricing_service, notification_service
from app.services.exceptions import SlotConflictError, ValidationError
from app.services.audit_service import log_action


def create_booking(client, slot_id: int, players_count: int, promo_code: str | None = None,
                    certificate_code: str | None = None, source: str = "widget", created_by=None,
                    comment: str | None = None) -> Booking:
    slot = db.session.get(Slot, slot_id)
    if slot is None:
        raise ValidationError("Слот не найден")
    if slot.status != SLOT_AVAILABLE:
        raise SlotConflictError("Выбранное время уже занято либо недоступно")

    promo = None
    if promo_code:
        promo = PromoCode.query.filter_by(code=promo_code.strip().upper()).first()
        if not promo or not promo.is_valid(slot.start_time.date()):
            raise ValidationError("Промокод недействителен")

    pricing = pricing_service.calculate_price(
        slot.quest, slot.start_time.date(), slot.start_time.strftime("%H:%M"),
        players_count, promo,
    )

    certificate = None
    cert_used = Decimal("0")
    if certificate_code:
        certificate = Certificate.query.filter_by(code=certificate_code.strip().upper()).first()
        if not certificate or not certificate.is_valid(slot.start_time.date()):
            raise ValidationError("Сертификат недействителен или исчерпан")
        cert_used, _ = pricing_service.apply_certificate(pricing["final_price"], certificate)

    # Рубеж защиты №1: атомарно помечаем слот занятым до создания брони
    slot.status = SLOT_BOOKED

    booking = Booking(
        slot_id=slot.id,
        client_id=client.id,
        created_by_id=created_by.id if created_by else None,
        players_count=players_count,
        status=BOOKING_NEW,
        base_price=pricing["base_price"],
        discount_amount=pricing["discount_amount"],
        final_price=pricing["final_price"],
        promocode_id=promo.id if promo else None,
        certificate_id=certificate.id if certificate else None,
        certificate_amount_used=cert_used,
        source=source,
        comment=comment,
    )
    db.session.add(booking)

    try:
        db.session.flush()  # рубеж защиты №2 — сработает уникальный индекс при гонке
    except IntegrityError:
        db.session.rollback()
        raise SlotConflictError("Слот только что был забронирован другим клиентом")

    if promo:
        promo.used_count += 1
    if certificate and cert_used > 0:
        certificate.balance = Decimal(certificate.balance) - cert_used

    db.session.commit()
    log_action("booking_created", "Booking", booking.id, f"slot={slot.id} players={players_count}")

    # Оплата не проводится системой — бронь подтверждается сразу после создания.
    booking.status = BOOKING_CONFIRMED
    db.session.commit()
    notification_service.notify_booking_confirmed(booking)

    return booking


def cancel_booking(booking: Booking, reason: str = "", initiated_by=None,
                    free_cancellation_hours: int = 24) -> Booking:
    if booking.status == BOOKING_CANCELED:
        return booking

    now = datetime.now(timezone.utc)

    booking.status = BOOKING_CANCELED
    booking.canceled_at = now
    booking.cancel_reason = reason
    booking.slot.status = SLOT_AVAILABLE

    # Возврат номинала на сертификат при отмене (если использовался)
    if booking.certificate_id and booking.certificate_amount_used:
        booking.certificate.balance = Decimal(booking.certificate.balance) + Decimal(booking.certificate_amount_used)

    db.session.commit()
    log_action("booking_canceled", "Booking", booking.id,
               f"reason={reason} by={initiated_by.id if initiated_by else 'client'}")
    notification_service.notify_booking_canceled(booking, reason)
    return booking


def mark_completed(booking: Booking):
    from app.constants import BOOKING_COMPLETED
    booking.status = BOOKING_COMPLETED
    booking.slot.status = SLOT_COMPLETED
    db.session.commit()
    log_action("booking_completed", "Booking", booking.id)
