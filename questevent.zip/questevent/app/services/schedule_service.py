"""Формирование расписания сеансов (Slot). ТЗ п.4.2.1."""
from datetime import datetime, date, time, timedelta

from app.extensions import db
from app.models.slot import Slot
from app.models.room import Room, ROOM_STATUS_MAINTENANCE
from app.models.quest import Quest
from app.constants import SLOT_AVAILABLE
from app.services.exceptions import ValidationError


def generate_slots_for_room(room: Room, quest: Quest, date_from: date, date_to: date,
                             day_start: time, day_end: time, step_minutes: int | None = None):
    """Генерирует сеансы для комнаты/квеста на диапазон дат.

    Шаг сеанса по умолчанию равен продолжительности квеста (без окон между играми
    можно передать больший step_minutes для технологического перерыва).
    Пропускает слоты, которые уже существуют (идемпотентно) и комнаты на обслуживании.
    """
    if room.status == ROOM_STATUS_MAINTENANCE:
        raise ValidationError(f"Комната «{room.name}» выведена на обслуживание: {room.maintenance_note or ''}")
    if date_from > date_to:
        raise ValidationError("Дата начала не может быть позже даты окончания")

    step = step_minutes or quest.duration_minutes
    created = []
    current_date = date_from
    while current_date <= date_to:
        cursor = datetime.combine(current_date, day_start)
        day_end_dt = datetime.combine(current_date, day_end)
        while cursor + timedelta(minutes=quest.duration_minutes) <= day_end_dt:
            slot_end = cursor + timedelta(minutes=quest.duration_minutes)
            exists = Slot.query.filter_by(room_id=room.id, start_time=cursor).first()
            if not exists:
                slot = Slot(
                    room_id=room.id,
                    quest_id=quest.id,
                    start_time=cursor,
                    end_time=slot_end,
                    status=SLOT_AVAILABLE,
                )
                db.session.add(slot)
                created.append(slot)
            cursor += timedelta(minutes=step)
        current_date += timedelta(days=1)

    db.session.commit()
    return created


def block_slot(slot: Slot, reason: str = ""):
    from app.constants import SLOT_BLOCKED, SLOT_BOOKED
    if slot.status == SLOT_BOOKED:
        raise ValidationError("Нельзя заблокировать слот с активным бронированием")
    slot.status = SLOT_BLOCKED
    db.session.commit()


def get_available_slots(quest_id: int, date_from: date, date_to: date):
    return (
        Slot.query.filter(
            Slot.quest_id == quest_id,
            Slot.status == SLOT_AVAILABLE,
            Slot.start_time >= datetime.combine(date_from, time.min),
            Slot.start_time <= datetime.combine(date_to, time.max),
        )
        .order_by(Slot.start_time.asc())
        .all()
    )
