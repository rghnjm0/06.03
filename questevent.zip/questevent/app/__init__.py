"""Application Factory (ТЗ п.4.2.4 — принцип «Application Factory» Flask)."""
import os
import secrets
import logging
from logging.handlers import RotatingFileHandler

from flask import Flask, render_template

from app.config import config_by_name
from app.extensions import db, migrate, login_manager, csrf, cache


def create_app(config_name: str | None = None) -> Flask:
    config_name = config_name or os.environ.get("FLASK_CONFIG", "development")
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_by_name[config_name])

    if config_name == "production" and not os.environ.get("SECRET_KEY"):
        # Не даём приложению незаметно подняться в проде на дефолтном,
        # публично известном ключе — без надёжного SECRET_KEY подделываются
        # cookie сессии, "remember me"-токены и CSRF-токены.
        raise RuntimeError(
            "SECRET_KEY не задан через переменную окружения. "
            "Установите её перед запуском в production, "
            f"например: SECRET_KEY={secrets.token_hex(32)}"
        )

    os.makedirs(app.instance_path, exist_ok=True)
    os.makedirs(os.path.join(app.instance_path, "..", "logs"), exist_ok=True)

    _init_extensions(app)
    _init_logging(app)
    _register_blueprints(app)
    _register_error_handlers(app)
    _register_security_headers(app)
    _register_cli(app)

    if app.config.get("SCHEDULER_ENABLED", True) and not app.config.get("TESTING"):
        from app.tasks.scheduler import init_scheduler
        init_scheduler(app)

    return app


def _init_extensions(app: Flask) -> None:
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    # "strong" разлогинивает сессию, если у клиента резко меняется отпечаток
    # (IP/User-Agent) — снижает риск использования угнанной сессионной cookie.
    login_manager.session_protection = "strong"
    csrf.init_app(app)
    cache.init_app(app)

    from app.models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))


def _init_logging(app: Flask) -> None:
    """Структурированное журналирование с ротацией (ТЗ п.4.1.5 — надёжность,
    журналирование ошибок и инцидентов)."""
    if app.testing:
        return
    log_dir = os.path.join(app.root_path, "..", "logs")
    os.makedirs(log_dir, exist_ok=True)
    handler = RotatingFileHandler(os.path.join(log_dir, "questevent.log"), maxBytes=2_000_000, backupCount=5)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s [%(filename)s:%(lineno)d]: %(message)s"
    ))
    handler.setLevel(logging.INFO)
    app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)
    logging.getLogger("questevent").addHandler(handler)
    logging.getLogger("questevent").setLevel(logging.INFO)


def _register_blueprints(app: Flask) -> None:
    from app.blueprints.auth import bp as auth_bp
    from app.blueprints.admin import bp as admin_bp
    from app.blueprints.schedule import bp as schedule_bp
    from app.blueprints.crm import bp as crm_bp
    from app.blueprints.pricing import bp as pricing_bp
    from app.blueprints.reports import bp as reports_bp
    from app.blueprints.widget import bp as widget_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(schedule_bp)
    app.register_blueprint(crm_bp)
    app.register_blueprint(pricing_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(widget_bp)


def _register_error_handlers(app: Flask) -> None:
    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("Внутренняя ошибка сервера: %s", e)
        return render_template("errors/500.html"), 500


def _register_security_headers(app: Flask) -> None:
    """Базовые защитные HTTP-заголовки (снижают риск clickjacking, MIME-sniffing
    и утечки Referer на сторонние сайты)."""
    @app.after_request
    def set_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        if not app.debug and not app.testing:
            response.headers.setdefault(
                "Strict-Transport-Security", "max-age=31536000; includeSubDomains"
            )
        return response


def _register_cli(app: Flask) -> None:
    @app.cli.command("seed-demo")
    def seed_demo():
        """Наполняет БД демонстрационными данными: flask seed-demo"""
        from seed import run_seed
        run_seed()
        print("Демо-данные загружены.")
