from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SelectField
from wtforms.validators import DataRequired, Email, Length, Optional


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Пароль", validators=[DataRequired()])
    remember = BooleanField("Запомнить меня")


class ClientRegisterForm(FlaskForm):
    full_name = StringField("Имя", validators=[DataRequired(), Length(max=150)])
    email = StringField("Email", validators=[Optional(), Email()])
    phone = StringField("Телефон", validators=[DataRequired(), Length(max=50)])
    password = PasswordField("Пароль", validators=[DataRequired(), Length(min=8, message="Минимум 8 символов")])


class StaffUserForm(FlaskForm):
    full_name = StringField("ФИО", validators=[DataRequired(), Length(max=150)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    phone = StringField("Телефон", validators=[Optional(), Length(max=50)])
    password = PasswordField("Пароль", validators=[Optional(), Length(min=8, message="Минимум 8 символов")])
    role = SelectField("Роль", validators=[DataRequired()])
    branch_id = SelectField("Филиал", coerce=int, validators=[Optional()])
