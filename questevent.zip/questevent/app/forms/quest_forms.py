from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, TextAreaField, SelectField, BooleanField, DecimalField
from wtforms.validators import DataRequired, NumberRange, Optional, Length


class BranchForm(FlaskForm):
    name = StringField("Название филиала", validators=[DataRequired(), Length(max=150)])
    city = StringField("Город", validators=[Optional(), Length(max=120)])
    address = StringField("Адрес", validators=[Optional(), Length(max=255)])
    phone = StringField("Телефон", validators=[Optional(), Length(max=50)])


class LocationForm(FlaskForm):
    branch_id = SelectField("Филиал", coerce=int, validators=[DataRequired()])
    name = StringField("Название локации", validators=[DataRequired(), Length(max=150)])
    address = StringField("Адрес", validators=[DataRequired(), Length(max=255)])


class RoomForm(FlaskForm):
    location_id = SelectField("Локация", coerce=int, validators=[DataRequired()])
    name = StringField("Название комнаты", validators=[DataRequired(), Length(max=150)])
    status = SelectField("Статус", choices=[("ok", "В строю"), ("maintenance", "На обслуживании")])
    maintenance_note = StringField("Примечание", validators=[Optional(), Length(max=255)])


class QuestForm(FlaskForm):
    room_id = SelectField("Комната", coerce=int, validators=[DataRequired()])
    title = StringField("Название квеста", validators=[DataRequired(), Length(max=150)])
    description = TextAreaField("Описание", validators=[Optional()])
    difficulty = SelectField("Сложность", choices=[("легкий", "Лёгкий"), ("средний", "Средний"), ("сложный", "Сложный")])
    duration_minutes = IntegerField("Длительность (мин)", validators=[DataRequired(), NumberRange(min=15, max=480)])
    min_players = IntegerField("Мин. игроков", validators=[DataRequired(), NumberRange(min=1)])
    max_players = IntegerField("Макс. игроков", validators=[DataRequired(), NumberRange(min=1)])
    min_age = IntegerField("Мин. возраст", validators=[Optional(), NumberRange(min=0, max=99)])


class TariffForm(FlaskForm):
    quest_id = SelectField("Квест", coerce=int, validators=[DataRequired()])
    name = StringField("Название тарифа", validators=[DataRequired(), Length(max=100)])
    weekdays = SelectField(
        "Дни недели", choices=[], validators=[Optional()]
    )  # заполняется во view; используем multi-select через raw HTML при необходимости
    time_from = StringField("Время с (HH:MM)", default="00:00")
    time_to = StringField("Время по (HH:MM)", default="23:59")
    price_per_slot = DecimalField("Цена за сеанс", validators=[DataRequired(), NumberRange(min=0)])
    price_per_extra_player = DecimalField("Доплата за игрока сверх мин.", validators=[Optional(), NumberRange(min=0)], default=0)
    priority = IntegerField("Приоритет", default=0)


class SlotGenerationForm(FlaskForm):
    room_id = SelectField("Комната", coerce=int, validators=[DataRequired()])
    quest_id = SelectField("Квест", coerce=int, validators=[DataRequired()])
    date_from = StringField("Дата с (YYYY-MM-DD)", validators=[DataRequired()])
    date_to = StringField("Дата по (YYYY-MM-DD)", validators=[DataRequired()])
    day_start = StringField("Начало дня (HH:MM)", default="10:00")
    day_end = StringField("Конец дня (HH:MM)", default="22:00")


class PromoCodeForm(FlaskForm):
    code = StringField("Код", validators=[DataRequired(), Length(max=50)])
    discount_percent = IntegerField("Скидка, %", validators=[Optional(), NumberRange(min=0, max=100)], default=0)
    discount_amount = DecimalField("Скидка, сумма", validators=[Optional(), NumberRange(min=0)], default=0)
    valid_from = StringField("Действует с (YYYY-MM-DD)", validators=[Optional()])
    valid_to = StringField("Действует по (YYYY-MM-DD)", validators=[Optional()])
    usage_limit = IntegerField("Лимит использований (0 = без лимита)", default=0)


class CertificateForm(FlaskForm):
    code = StringField("Код сертификата", validators=[DataRequired(), Length(max=50)])
    initial_balance = DecimalField("Номинал", validators=[DataRequired(), NumberRange(min=0)])
    expires_at = StringField("Действует до (YYYY-MM-DD)", validators=[Optional()])
    issued_to_name = StringField("Кому выдан", validators=[Optional(), Length(max=150)])


class ReviewForm(FlaskForm):
    rating = SelectField("Оценка", choices=[(str(i), str(i)) for i in range(1, 6)], validators=[DataRequired()])
    text = TextAreaField("Отзыв", validators=[Optional(), Length(max=2000)])
