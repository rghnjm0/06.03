from flask_wtf import FlaskForm
from wtforms import IntegerField, StringField, SelectField, HiddenField
from wtforms.validators import DataRequired, NumberRange, Optional, Length


class WidgetBookingForm(FlaskForm):
    slot_id = HiddenField(validators=[DataRequired()])
    full_name = StringField("Ваше имя", validators=[DataRequired(), Length(max=150)])
    phone = StringField("Телефон", validators=[DataRequired(), Length(max=50)])
    email = StringField("Email", validators=[Optional(), Length(max=150)])
    players_count = IntegerField("Число игроков", validators=[DataRequired(), NumberRange(min=1, max=30)])
    promo_code = StringField("Промокод", validators=[Optional(), Length(max=50)])
    certificate_code = StringField("Сертификат", validators=[Optional(), Length(max=50)])


class StaffBookingForm(FlaskForm):
    slot_id = SelectField("Сеанс", coerce=int, validators=[DataRequired()])
    client_phone = StringField("Телефон клиента", validators=[DataRequired()])
    client_name = StringField("Имя клиента", validators=[DataRequired()])
    players_count = IntegerField("Число игроков", validators=[DataRequired(), NumberRange(min=1, max=30)])
    promo_code = StringField("Промокод", validators=[Optional()])
    certificate_code = StringField("Сертификат", validators=[Optional()])


class CancelBookingForm(FlaskForm):
    reason = StringField("Причина отмены", validators=[Optional(), Length(max=255)])
