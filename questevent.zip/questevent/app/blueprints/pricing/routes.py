from datetime import datetime

from flask import render_template, redirect, url_for, flash
from flask_login import login_required

from app.blueprints.pricing import bp
from app.blueprints.rbac import roles_required
from app.extensions import db
from app.models import PromoCode, Certificate
from app.constants import ROLE_SUPERADMIN, ROLE_ACCOUNTANT, ROLE_LOCATION_ADMIN
from app.forms.quest_forms import PromoCodeForm, CertificateForm


@bp.route("/promocodes")
@login_required
@roles_required(ROLE_SUPERADMIN, ROLE_LOCATION_ADMIN)
def promocodes():
    items = PromoCode.query.order_by(PromoCode.id.desc()).all()
    return render_template("pricing/promocodes.html", items=items)


@bp.route("/promocodes/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, ROLE_LOCATION_ADMIN)
def promocode_new():
    form = PromoCodeForm()
    if form.validate_on_submit():
        if PromoCode.query.filter_by(code=form.code.data.upper()).first():
            flash("Промокод с таким кодом уже существует", "danger")
            return render_template("pricing/promocode_form.html", form=form)
        promo = PromoCode(
            code=form.code.data.strip().upper(),
            discount_percent=form.discount_percent.data or 0,
            discount_amount=form.discount_amount.data or 0,
            valid_from=datetime.strptime(form.valid_from.data, "%Y-%m-%d").date() if form.valid_from.data else None,
            valid_to=datetime.strptime(form.valid_to.data, "%Y-%m-%d").date() if form.valid_to.data else None,
            usage_limit=form.usage_limit.data or 0,
        )
        db.session.add(promo)
        db.session.commit()
        flash("Промокод создан", "success")
        return redirect(url_for("pricing.promocodes"))
    return render_template("pricing/promocode_form.html", form=form)


@bp.route("/certificates")
@login_required
@roles_required(ROLE_SUPERADMIN, ROLE_LOCATION_ADMIN, ROLE_ACCOUNTANT)
def certificates():
    items = Certificate.query.order_by(Certificate.id.desc()).all()
    return render_template("pricing/certificates.html", items=items)


@bp.route("/certificates/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, ROLE_LOCATION_ADMIN)
def certificate_new():
    form = CertificateForm()
    if form.validate_on_submit():
        if Certificate.query.filter_by(code=form.code.data.upper()).first():
            flash("Сертификат с таким кодом уже существует", "danger")
            return render_template("pricing/certificate_form.html", form=form)
        cert = Certificate(
            code=form.code.data.strip().upper(),
            initial_balance=form.initial_balance.data,
            balance=form.initial_balance.data,
            expires_at=datetime.strptime(form.expires_at.data, "%Y-%m-%d").date() if form.expires_at.data else None,
            issued_to_name=form.issued_to_name.data,
        )
        db.session.add(cert)
        db.session.commit()
        flash("Сертификат создан", "success")
        return redirect(url_for("pricing.certificates"))
    return render_template("pricing/certificate_form.html", form=form)
