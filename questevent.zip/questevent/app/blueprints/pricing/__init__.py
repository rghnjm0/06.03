from flask import Blueprint

bp = Blueprint("pricing", __name__, url_prefix="/pricing", template_folder="../../templates/pricing")

from app.blueprints.pricing import routes  # noqa: E402,F401
