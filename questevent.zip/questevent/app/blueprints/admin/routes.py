from datetime import date, timedelta

from flask import render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from app.blueprints.admin import bp
from app.blueprints.rbac import staff_required, roles_required, branch_scoped_query
from app.extensions import db
from app.models import Branch, Location, Room, Quest, Tariff, User, AuditLog
from app.constants import ALL_ROLES, ROLE_LABELS, STAFF_ROLES, ROLE_SUPERADMIN
from app.forms.auth_forms import StaffUserForm
from app.forms.quest_forms import BranchForm, LocationForm, RoomForm, QuestForm, TariffForm
from app.services.audit_service import log_action
from app.services import report_service


@bp.route("/")
@login_required
@staff_required
def dashboard():
    kpi = report_service.kpi_dashboard(
        branch_id=None if current_user.role == ROLE_SUPERADMIN else current_user.branch_id
    )
    return render_template("admin/dashboard.html", kpi=kpi)


# ---------------------------------------------------------------- branches
@bp.route("/branches")
@login_required
@roles_required(ROLE_SUPERADMIN)
def branches():
    items = Branch.query.order_by(Branch.name).all()
    return render_template("admin/branches.html", items=items)


@bp.route("/branches/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN)
def branch_new():
    form = BranchForm()
    if form.validate_on_submit():
        b = Branch(name=form.name.data, city=form.city.data, address=form.address.data, phone=form.phone.data)
        db.session.add(b)
        db.session.commit()
        log_action("branch_created", "Branch", b.id)
        flash("Филиал создан", "success")
        return redirect(url_for("admin.branches"))
    return render_template("admin/branch_form.html", form=form, title="Новый филиал")


# ---------------------------------------------------------------- locations
@bp.route("/locations")
@login_required
@staff_required
def locations():
    q = branch_scoped_query(Location.query, Location.branch_id)
    return render_template("admin/locations.html", items=q.order_by(Location.name).all())


@bp.route("/locations/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def location_new():
    form = LocationForm()
    form.branch_id.choices = [(b.id, b.name) for b in Branch.query.order_by(Branch.name)]
    if form.validate_on_submit():
        if current_user.role != ROLE_SUPERADMIN and form.branch_id.data != current_user.branch_id:
            flash("Нет доступа к выбранному филиалу", "danger")
            return redirect(url_for("admin.locations"))
        loc = Location(branch_id=form.branch_id.data, name=form.name.data, address=form.address.data)
        db.session.add(loc)
        db.session.commit()
        log_action("location_created", "Location", loc.id)
        flash("Локация создана", "success")
        return redirect(url_for("admin.locations"))
    return render_template("admin/location_form.html", form=form, title="Новая локация")


# ---------------------------------------------------------------- rooms
@bp.route("/rooms")
@login_required
@staff_required
def rooms():
    q = Room.query.join(Location)
    q = branch_scoped_query(q, Location.branch_id)
    return render_template("admin/rooms.html", items=q.order_by(Room.name).all())


@bp.route("/rooms/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def room_new():
    form = RoomForm()
    locs = Location.query
    locs = branch_scoped_query(locs, Location.branch_id)
    form.location_id.choices = [(l.id, l.name) for l in locs]
    if form.validate_on_submit():
        room = Room(
            location_id=form.location_id.data, name=form.name.data,
            status=form.status.data, maintenance_note=form.maintenance_note.data,
        )
        db.session.add(room)
        db.session.commit()
        log_action("room_created", "Room", room.id)
        flash("Комната создана", "success")
        return redirect(url_for("admin.rooms"))
    return render_template("admin/room_form.html", form=form, title="Новая комната")


@bp.route("/rooms/<int:room_id>/maintenance", methods=["POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def room_toggle_maintenance(room_id):
    from app.models.room import ROOM_STATUS_OK, ROOM_STATUS_MAINTENANCE
    room = Room.query.get_or_404(room_id)
    if room.status == ROOM_STATUS_MAINTENANCE:
        room.status = ROOM_STATUS_OK
        room.maintenance_note = None
    else:
        room.status = ROOM_STATUS_MAINTENANCE
        room.maintenance_note = request.form.get("note", "Техническое обслуживание")
    db.session.commit()
    log_action("room_maintenance_toggled", "Room", room.id, room.status)
    flash("Статус комнаты обновлён", "success")
    return redirect(url_for("admin.rooms"))


# ---------------------------------------------------------------- quests
@bp.route("/quests")
@login_required
@staff_required
def quests():
    q = Quest.query.join(Room).join(Location)
    q = branch_scoped_query(q, Location.branch_id)
    return render_template("admin/quests.html", items=q.order_by(Quest.title).all())


@bp.route("/quests/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def quest_new():
    form = QuestForm()
    rooms_q = Room.query.join(Location)
    rooms_q = branch_scoped_query(rooms_q, Location.branch_id)
    form.room_id.choices = [(r.id, f"{r.location.name} / {r.name}") for r in rooms_q]
    if form.validate_on_submit():
        if form.min_players.data > form.max_players.data:
            flash("Минимум игроков не может быть больше максимума", "danger")
            return render_template("admin/quest_form.html", form=form, title="Новый квест")
        quest = Quest(
            room_id=form.room_id.data, title=form.title.data, description=form.description.data,
            difficulty=form.difficulty.data, duration_minutes=form.duration_minutes.data,
            min_players=form.min_players.data, max_players=form.max_players.data,
            min_age=form.min_age.data or 0,
        )
        db.session.add(quest)
        db.session.commit()
        log_action("quest_created", "Quest", quest.id)
        flash("Квест создан", "success")
        return redirect(url_for("admin.quests"))
    return render_template("admin/quest_form.html", form=form, title="Новый квест")


# ---------------------------------------------------------------- tariffs
@bp.route("/tariffs")
@login_required
@staff_required
def tariffs():
    q = Tariff.query.join(Quest).join(Room).join(Location)
    q = branch_scoped_query(q, Location.branch_id)
    return render_template("admin/tariffs.html", items=q.all())


@bp.route("/tariffs/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def tariff_new():
    form = TariffForm()
    quests_q = Quest.query.join(Room).join(Location)
    quests_q = branch_scoped_query(quests_q, Location.branch_id)
    form.quest_id.choices = [(q.id, q.title) for q in quests_q]
    del form.weekdays  # управляется через чекбоксы в шаблоне (см. request.form.getlist)
    if request.method == "POST" and form.validate_on_submit():
        weekdays = request.form.getlist("weekday")
        tariff = Tariff(
            quest_id=form.quest_id.data, name=form.name.data,
            weekday_mask=",".join(weekdays) if weekdays else "0,1,2,3,4,5,6",
            time_from=form.time_from.data, time_to=form.time_to.data,
            price_per_slot=form.price_per_slot.data,
            price_per_extra_player=form.price_per_extra_player.data or 0,
            priority=form.priority.data or 0,
        )
        db.session.add(tariff)
        db.session.commit()
        log_action("tariff_created", "Tariff", tariff.id)
        flash("Тариф создан", "success")
        return redirect(url_for("admin.tariffs"))
    return render_template("admin/tariff_form.html", form=form, title="Новый тариф")


# ---------------------------------------------------------------- users
@bp.route("/users")
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def users():
    q = User.query.filter(User.role.in_(STAFF_ROLES))
    q = branch_scoped_query(q, User.branch_id)
    return render_template("admin/users.html", items=q.order_by(User.full_name).all(), role_labels=ROLE_LABELS)


@bp.route("/users/new", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def user_new():
    form = StaffUserForm()
    allowed_roles = STAFF_ROLES if current_user.role == ROLE_SUPERADMIN else [
        r for r in STAFF_ROLES if r != ROLE_SUPERADMIN
    ]
    form.role.choices = [(r, ROLE_LABELS[r]) for r in allowed_roles]
    form.branch_id.choices = [(b.id, b.name) for b in Branch.query.order_by(Branch.name)]
    if form.validate_on_submit():
        if User.query.filter_by(email=form.email.data.lower()).first():
            flash("Email уже используется", "danger")
            return render_template("admin/user_form.html", form=form, title="Новый сотрудник")
        branch_id = form.branch_id.data
        if current_user.role != ROLE_SUPERADMIN:
            branch_id = current_user.branch_id
        user = User(
            full_name=form.full_name.data, email=form.email.data.lower().strip(),
            phone=form.phone.data or None, role=form.role.data, branch_id=branch_id,
        )
        user.set_password(form.password.data or "changeme123")
        db.session.add(user)
        db.session.commit()
        log_action("staff_user_created", "User", user.id, f"role={user.role}")
        flash("Сотрудник добавлен", "success")
        return redirect(url_for("admin.users"))
    return render_template("admin/user_form.html", form=form, title="Новый сотрудник")


@bp.route("/audit-log")
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def audit_log():
    page = request.args.get("page", 1, type=int)
    pagination = AuditLog.query.order_by(AuditLog.created_at.desc()).paginate(page=page, per_page=50, error_out=False)
    return render_template("admin/audit_log.html", pagination=pagination)
