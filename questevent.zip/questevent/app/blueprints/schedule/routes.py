from datetime import datetime, date, timedelta

from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user

from app.blueprints.schedule import bp
from app.blueprints.rbac import staff_required, roles_required, branch_scoped_query
from app.extensions import db
from app.models import Room, Quest, Slot, Booking, User, Location
from app.constants import ROLE_SUPERADMIN, ROLE_CLIENT
from app.forms.quest_forms import SlotGenerationForm
from app.forms.booking_forms import StaffBookingForm, CancelBookingForm
from app.services import schedule_service, booking_service
from app.services.exceptions import DomainError


def _safe_referrer_or(default_endpoint: str):
    """Редирект назад на Referer, но только если он указывает на этот же
    хост (заголовок Referer полностью контролируется клиентом — тот же
    принцип защиты от открытого редиректа, что и для ?next= при логине)."""
    ref = request.referrer
    if ref:
        from urllib.parse import urlparse
        parsed = urlparse(ref)
        if parsed.netloc == urlparse(request.host_url).netloc:
            return redirect(ref)
    return redirect(url_for(default_endpoint))


@bp.route("/")
@login_required
@staff_required
def calendar():
    day_str = request.args.get("date")
    day = datetime.strptime(day_str, "%Y-%m-%d").date() if day_str else date.today()

    rooms_q = Room.query.join(Location)
    rooms_q = branch_scoped_query(rooms_q, Location.branch_id)
    rooms = rooms_q.order_by(Room.name).all()

    slots = (
        Slot.query.filter(
            Slot.start_time >= datetime.combine(day, datetime.min.time()),
            Slot.start_time <= datetime.combine(day, datetime.max.time()),
        )
        .join(Room)
        .join(Location)
    )
    slots = branch_scoped_query(slots, Location.branch_id).order_by(Slot.start_time).all()

    slots_by_room = {}
    for s in slots:
        slots_by_room.setdefault(s.room_id, []).append(s)

    return render_template(
        "schedule/calendar.html", rooms=rooms, day=day, slots_by_room=slots_by_room,
        prev_day=day - timedelta(days=1), next_day=day + timedelta(days=1),
    )


@bp.route("/generate", methods=["GET", "POST"])
@login_required
@roles_required(ROLE_SUPERADMIN, "admin")
def generate_slots():
    form = SlotGenerationForm()
    rooms_q = Room.query.join(Location)
    rooms_q = branch_scoped_query(rooms_q, Location.branch_id)
    rooms = rooms_q.all()
    form.room_id.choices = [(r.id, f"{r.location.name} / {r.name}") for r in rooms]
    form.quest_id.choices = [(q.id, q.title) for r in rooms for q in r.quests]

    if form.validate_on_submit():
        try:
            room = Room.query.get_or_404(form.room_id.data)
            quest = Quest.query.get_or_404(form.quest_id.data)
            d_from = datetime.strptime(form.date_from.data, "%Y-%m-%d").date()
            d_to = datetime.strptime(form.date_to.data, "%Y-%m-%d").date()
            t_start = datetime.strptime(form.day_start.data, "%H:%M").time()
            t_end = datetime.strptime(form.day_end.data, "%H:%M").time()
            created = schedule_service.generate_slots_for_room(room, quest, d_from, d_to, t_start, t_end)
            flash(f"Создано сеансов: {len(created)}", "success")
            return redirect(url_for("schedule.calendar", date=d_from.isoformat()))
        except DomainError as exc:
            flash(str(exc), "danger")
    return render_template("schedule/generate_form.html", form=form)


@bp.route("/booking/new", methods=["GET", "POST"])
@login_required
@staff_required
def booking_new():
    slot_id = request.args.get("slot_id", type=int)
    form = StaffBookingForm()
    if slot_id:
        form.slot_id.data = slot_id
    open_slots = Slot.query.filter_by(status="available").order_by(Slot.start_time).limit(200).all()
    form.slot_id.choices = [
        (s.id, f"{s.room.name} — {s.quest.title} — {s.start_time:%d.%m %H:%M}") for s in open_slots
    ]

    if form.validate_on_submit():
        client = User.query.filter_by(phone=form.client_phone.data.strip()).first()
        if not client:
            client = User(role=ROLE_CLIENT, full_name=form.client_name.data.strip(), phone=form.client_phone.data.strip())
            db.session.add(client)
            db.session.commit()
        try:
            booking = booking_service.create_booking(
                client=client, slot_id=form.slot_id.data, players_count=form.players_count.data,
                promo_code=form.promo_code.data or None, certificate_code=form.certificate_code.data or None,
                source="admin", created_by=current_user,
            )
            flash(f"Бронирование создано: {booking.confirmation_code}", "success")
            return redirect(url_for("schedule.calendar"))
        except DomainError as exc:
            flash(str(exc), "danger")
    return render_template("schedule/booking_form.html", form=form)


@bp.route("/booking/<int:booking_id>/cancel", methods=["POST"])
@login_required
@staff_required
def booking_cancel(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    reason = request.form.get("reason", "Отменено сотрудником")
    booking_service.cancel_booking(booking, reason=reason, initiated_by=current_user)
    flash("Бронирование отменено", "info")
    return _safe_referrer_or("schedule.calendar")


@bp.route("/booking/<int:booking_id>/complete", methods=["POST"])
@login_required
@staff_required
def booking_complete(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    booking_service.mark_completed(booking)
    flash("Бронирование отмечено как проведённое", "success")
    return _safe_referrer_or("schedule.calendar")


@bp.route("/slot/<int:slot_id>/checklist", methods=["GET", "POST"])
@login_required
@staff_required
def slot_checklist(slot_id):
    from app.models.checklist import SlotChecklistMark
    slot = Slot.query.get_or_404(slot_id)
    templates = slot.quest.checklist_templates
    items = [item for t in templates for item in t.items]

    if request.method == "POST":
        checked_ids = {int(x) for x in request.form.getlist("item_id")}
        for item in items:
            mark = SlotChecklistMark.query.filter_by(slot_id=slot.id, item_id=item.id).first()
            if not mark:
                mark = SlotChecklistMark(slot_id=slot.id, item_id=item.id)
                db.session.add(mark)
            mark.is_done = item.id in checked_ids
            mark.marked_by_id = current_user.id
        db.session.commit()
        flash("Чек-лист обновлён", "success")
        return redirect(url_for("schedule.slot_checklist", slot_id=slot.id))

    marks = {m.item_id: m for m in SlotChecklistMark.query.filter_by(slot_id=slot.id).all()}
    return render_template("schedule/checklist.html", slot=slot, items=items, marks=marks)


@bp.route("/api/available-slots")
def api_available_slots():
    """Публичный JSON-эндпоинт для AJAX-календаря виджета бронирования."""
    quest_id = request.args.get("quest_id", type=int)
    date_from = request.args.get("date_from")
    date_to = request.args.get("date_to")
    if not (quest_id and date_from and date_to):
        return jsonify({"error": "quest_id, date_from, date_to обязательны"}), 400
    d_from = datetime.strptime(date_from, "%Y-%m-%d").date()
    d_to = datetime.strptime(date_to, "%Y-%m-%d").date()
    slots = schedule_service.get_available_slots(quest_id, d_from, d_to)
    return jsonify([
        {"id": s.id, "start_time": s.start_time.isoformat(), "end_time": s.end_time.isoformat(), "room": s.room.name}
        for s in slots
    ])
