from datetime import datetime, date, timedelta

from flask import render_template, request, send_file
from flask_login import login_required, current_user

from app.blueprints.reports import bp
from app.blueprints.rbac import staff_required
from app.constants import ROLE_SUPERADMIN
from app.services import report_service


def _parse_period():
    today = date.today()
    date_from = request.args.get("date_from")
    date_to = request.args.get("date_to")
    d_from = datetime.strptime(date_from, "%Y-%m-%d").date() if date_from else today.replace(day=1)
    d_to = datetime.strptime(date_to, "%Y-%m-%d").date() if date_to else today
    return d_from, d_to


def _branch_scope():
    return None if current_user.role == ROLE_SUPERADMIN else current_user.branch_id


@bp.route("/")
@login_required
@staff_required
def dashboard():
    d_from, d_to = _parse_period()
    occupancy = report_service.occupancy_report(d_from, d_to, _branch_scope())
    revenue = report_service.revenue_report(d_from, d_to, _branch_scope())
    quest_eff = report_service.quest_effectiveness_report(d_from, d_to)
    host_eff = report_service.host_effectiveness_report(d_from, d_to)
    return render_template(
        "reports/dashboard.html", d_from=d_from, d_to=d_to, occupancy=occupancy,
        revenue=revenue, quest_eff=quest_eff, host_eff=host_eff,
    )


@bp.route("/export/<report_name>.<fmt>")
@login_required
@staff_required
def export(report_name, fmt):
    d_from, d_to = _parse_period()
    branch = _branch_scope()

    generators = {
        "occupancy": lambda: report_service.occupancy_report(d_from, d_to, branch),
        "quest-effectiveness": lambda: report_service.quest_effectiveness_report(d_from, d_to),
        "host-effectiveness": lambda: report_service.host_effectiveness_report(d_from, d_to),
    }
    if report_name not in generators:
        return "Неизвестный отчёт", 404
    rows = generators[report_name]()

    if fmt == "csv":
        buf = report_service.export_rows_to_csv(rows)
        mimetype = "text/csv"
    elif fmt == "xlsx":
        buf = report_service.export_rows_to_xlsx(rows, sheet_title=report_name)
        mimetype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    else:
        return "Формат не поддерживается (доступны csv, xlsx)", 400

    filename = f"{report_name}_{d_from}_{d_to}.{fmt}"
    return send_file(buf, mimetype=mimetype, as_attachment=True, download_name=filename)
