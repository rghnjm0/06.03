"""Вспомогательные декораторы ролевой модели доступа (RBAC, ТЗ п.4.1.5)."""
from functools import wraps
from flask import abort
from flask_login import current_user


def roles_required(*roles):
    """Ограничивает доступ к view только указанным ролям сотрудников."""
    def decorator(view_func):
        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if current_user.role not in roles:
                abort(403)
            return view_func(*args, **kwargs)
        return wrapped
    return decorator


def staff_required(view_func):
    from app.constants import STAFF_ROLES
    return roles_required(*STAFF_ROLES)(view_func)


def branch_scoped_query(query, branch_column):
    """Ограничивает queryset филиалом текущего пользователя (если не superadmin)."""
    if current_user.is_authenticated and current_user.role != "superadmin" and current_user.branch_id:
        query = query.filter(branch_column == current_user.branch_id)
    return query
