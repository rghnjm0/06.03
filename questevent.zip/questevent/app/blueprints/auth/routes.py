from urllib.parse import urlparse

from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user

from app.blueprints.auth import bp
from app.forms.auth_forms import LoginForm, ClientRegisterForm
from app.models.user import User
from app.extensions import db, cache
from app.constants import ROLE_CLIENT
from app.services.audit_service import log_action
from app.utils import is_safe_redirect_target

LOGIN_MAX_ATTEMPTS = 5
LOGIN_LOCKOUT_SECONDS = 300  # 5 минут


def _login_attempts_key() -> str:
    return f"login_attempts:{request.remote_addr}:{request.form.get('email', '').strip().lower()}"


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("admin.dashboard") if current_user.is_staff() else url_for("widget.index"))

    form = LoginForm()
    if form.validate_on_submit():
        attempts_key = _login_attempts_key()
        attempts = cache.get(attempts_key) or 0
        if attempts >= LOGIN_MAX_ATTEMPTS:
            flash("Слишком много неудачных попыток входа. Попробуйте позже.", "danger")
            return render_template("auth/login.html", form=form)

        user = User.query.filter_by(email=form.email.data.lower().strip()).first()
        if user and user.check_password(form.password.data) and user.is_active:
            cache.delete(attempts_key)
            login_user(user, remember=form.remember.data)
            log_action("login", "User", user.id)
            next_url = request.args.get("next")
            if next_url and is_safe_redirect_target(next_url):
                return redirect(next_url)
            return redirect(url_for("admin.dashboard") if user.is_staff() else url_for("widget.index"))

        cache.set(attempts_key, attempts + 1, timeout=LOGIN_LOCKOUT_SECONDS)
        flash("Неверный email или пароль", "danger")
    return render_template("auth/login.html", form=form)


@bp.route("/logout")
@login_required
def logout():
    log_action("logout", "User", current_user.id)
    logout_user()
    return redirect(url_for("auth.login"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    """Регистрация клиента для личного кабинета (публичный виджет)."""
    form = ClientRegisterForm()
    if form.validate_on_submit():
        existing = User.query.filter(
            (User.email == form.email.data) | (User.phone == form.phone.data)
        ).first()
        if existing:
            flash("Пользователь с таким email/телефоном уже существует", "warning")
            return render_template("auth/register.html", form=form)

        user = User(
            role=ROLE_CLIENT,
            full_name=form.full_name.data.strip(),
            email=(form.email.data or "").strip().lower() or None,
            phone=form.phone.data.strip(),
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash("Регистрация успешна!", "success")
        return redirect(url_for("widget.my_bookings"))
    return render_template("auth/register.html", form=form)
