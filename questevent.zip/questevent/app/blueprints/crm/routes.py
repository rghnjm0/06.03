from flask import render_template, request
from flask_login import login_required

from app.blueprints.crm import bp
from app.blueprints.rbac import staff_required
from app.models import User, Review
from app.constants import ROLE_CLIENT


@bp.route("/clients")
@login_required
@staff_required
def clients():
    search = request.args.get("q", "").strip()
    query = User.query.filter_by(role=ROLE_CLIENT)
    if search:
        like = f"%{search}%"
        query = query.filter(
            (User.full_name.ilike(like)) | (User.phone.ilike(like)) | (User.email.ilike(like))
        )
    page = request.args.get("page", 1, type=int)
    pagination = query.order_by(User.created_at.desc()).paginate(page=page, per_page=25, error_out=False)
    return render_template("crm/clients.html", pagination=pagination, search=search)


@bp.route("/clients/<int:client_id>")
@login_required
@staff_required
def client_detail(client_id):
    client = User.query.filter_by(id=client_id, role=ROLE_CLIENT).first_or_404()
    return render_template("crm/client_detail.html", client=client)


@bp.route("/reviews")
@login_required
@staff_required
def reviews():
    page = request.args.get("page", 1, type=int)
    pagination = Review.query.order_by(Review.created_at.desc()).paginate(page=page, per_page=25, error_out=False)
    return render_template("crm/reviews.html", pagination=pagination)
