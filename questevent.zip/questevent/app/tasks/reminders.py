"""Фоновые регламентные задачи. ТЗ п.4.2.4: планировщик для отправки уведомлений
по расписанию, формирования отчётов и прочих регламентных операций.

Каждая задача идемпотентна (использует флаги reminder_*_sent / review_request_sent),
поэтому безопасна при повторном запуске / нескольких воркерах с общей БД.
"""
import logging
from datetime import datetime, timedelta, timezone

logger = logging.getLogger("questevent.tasks")


def send_due_reminders(app):
    """Отправляет напоминания за 24ч и за 2ч, а также запросы отзыва после игры."""
    with app.app_context():
        from app.models import Booking
        from app.constants import BOOKING_CONFIRMED, BOOKING_COMPLETED
        from app.services import notification_service, booking_service
        from app.extensions import db

        now = datetime.now(timezone.utc)

        confirmed = Booking.query.filter_by(status=BOOKING_CONFIRMED).all()
        for booking in confirmed:
            slot_start = booking.slot.start_time
            if slot_start.tzinfo is None:
                slot_start = slot_start.replace(tzinfo=timezone.utc)
            hours_left = (slot_start - now).total_seconds() / 3600.0

            if not booking.reminder_24h_sent and hours_left <= 24:
                notification_service.notify_reminder(booking, 24)
                booking.reminder_24h_sent = True
                db.session.commit()

            if not booking.reminder_2h_sent and hours_left <= 2:
                notification_service.notify_reminder(booking, 2)
                booking.reminder_2h_sent = True
                db.session.commit()

            if hours_left <= 0:
                booking_service.mark_completed(booking)

        completed = Booking.query.filter_by(status=BOOKING_COMPLETED, review_request_sent=False).all()
        for booking in completed:
            slot_end = booking.slot.end_time
            if slot_end.tzinfo is None:
                slot_end = slot_end.replace(tzinfo=timezone.utc)
            if now - slot_end >= timedelta(hours=3):
                notification_service.notify_review_request(booking)
                booking.review_request_sent = True
                db.session.commit()


def release_stale_unpaid_bookings(app, minutes: int = 20):
    """Освобождает слот, если бронь осталась неоплаченной дольше `minutes` минут."""
    with app.app_context():
        from app.models import Booking
        from app.constants import BOOKING_NEW, SLOT_AVAILABLE
        from app.extensions import db

        cutoff = datetime.now(timezone.utc) - timedelta(minutes=minutes)
        stale = Booking.query.filter_by(status=BOOKING_NEW).all()
        for booking in stale:
            created = booking.created_at
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            if created < cutoff:
                booking.slot.status = SLOT_AVAILABLE
                db.session.delete(booking)
        db.session.commit()
