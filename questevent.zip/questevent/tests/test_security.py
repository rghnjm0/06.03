"""Регрессионные тесты по итогам аудита безопасности."""
from app.extensions import cache


def _login(client, email, password, next_url=None):
    url = "/auth/login" + (f"?next={next_url}" if next_url else "")
    return client.post(url, data={"email": email, "password": password, "remember": ""},
                        follow_redirects=False)


def test_open_redirect_next_param_is_ignored(client, demo_data):
    """?next=<внешний URL> не должен уводить пользователя со своего сайта."""
    resp = _login(client, "admin@example.com", "test1234", next_url="https://evil.example/phish")
    assert resp.status_code == 302
    assert resp.headers["Location"].startswith("/")
    assert "evil.example" not in resp.headers["Location"]


def test_open_redirect_protocol_relative_url_is_ignored(client, demo_data):
    """//evil.example — тоже валидный способ обойти наивную проверку "начинается с /"."""
    resp = _login(client, "admin@example.com", "test1234", next_url="//evil.example/phish")
    assert resp.status_code == 302
    assert "evil.example" not in resp.headers["Location"]


def test_safe_next_param_is_respected(client, demo_data):
    """Обычный локальный next (например, страница, с которой пришли) должен работать."""
    resp = _login(client, "admin@example.com", "test1234", next_url="/schedule/")
    assert resp.status_code == 302
    assert resp.headers["Location"] == "/schedule/"


def test_login_lockout_after_repeated_failures(client, demo_data):
    """После нескольких неверных попыток вход должен временно блокироваться."""
    cache.clear()
    for _ in range(5):
        client.post("/auth/login", data={"email": "admin@example.com", "password": "wrong"})
    resp = client.post("/auth/login", data={"email": "admin@example.com", "password": "test1234"},
                        follow_redirects=True)
    # Даже с верным паролем вход не должен пройти — активна блокировка.
    assert resp.status_code == 200
    assert "Слишком много".encode("utf-8") in resp.data
    cache.clear()


def test_security_headers_present(client, demo_data):
    resp = client.get("/")
    assert resp.headers.get("X-Content-Type-Options") == "nosniff"
    assert resp.headers.get("X-Frame-Options") == "DENY"
    assert resp.headers.get("Referrer-Policy") == "strict-origin-when-cross-origin"


def test_weak_password_rejected_on_registration(client, demo_data):
    resp = client.get("/auth/register")
    import re
    csrf = re.search(rb'name="csrf_token" type="hidden" value="([^"]+)"', resp.data)
    data = {
        "full_name": "Слабый Пароль", "phone": "+79991230000",
        "email": "weak@example.com", "password": "123",
    }
    if csrf:
        data["csrf_token"] = csrf.group(1).decode()
    resp = client.post("/auth/register", data=data)
    assert resp.status_code == 200  # форма не прошла валидацию, редиректа нет
    from app.models import User
    assert User.query.filter_by(email="weak@example.com").first() is None


def test_session_cookie_flags(app):
    assert app.config["SESSION_COOKIE_HTTPONLY"] is True
    assert app.config["SESSION_COOKIE_SAMESITE"] == "Lax"
