"""Общие вспомогательные функции приложения."""
import os
from datetime import datetime, timedelta
from flask import url_for
from db import get_db

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOMS_DIR = os.path.join(BASE_DIR, "static", "images", "rooms")

def init_uploads():
    os.makedirs(ROOMS_DIR, exist_ok=True)

def get_room_image(room_number):
    """Возвращает гарантированно существующее изображение номера.

    Если для конкретного номера отдельной фотографии нет, берётся одна
    из фотографий, которые реально лежат в static/images/rooms.
    Это предотвращает пустые картинки на главной странице.
    """
    room_number_str = str(room_number)
    extensions = [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG", ".WEBP"]

    # Сначала ищем точное совпадение номера.
    for ext in extensions:
        filename = f"{room_number_str}{ext}"
        if os.path.isfile(os.path.join(ROOMS_DIR, filename)):
            return url_for("static", filename=f"images/rooms/{filename}")

    # Если фото номера нет — используем стабильный fallback из имеющихся файлов.
    available = sorted(
        f for f in os.listdir(ROOMS_DIR)
        if os.path.isfile(os.path.join(ROOMS_DIR, f)) and f.lower().endswith(tuple(e.lower() for e in extensions))
    )
    if available:
        # Один и тот же номер всегда получает одну и ту же запасную фотографию.
        index = sum(ord(ch) for ch in room_number_str) % len(available)
        filename = available[index]
        return url_for("static", filename=f"images/rooms/{filename}")

    return ""

def get_room_image_extra(room_number, index):
    room_number_str = str(room_number)
    possible_formats = [
        f"{room_number_str}-{index}", f"{room_number_str}_{index}",
        f"{room_number_str} {index}", f"{room_number_str}a{index}",
        f"{room_number_str}_{index:02d}",
    ]
    extensions = [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG", ".WEBP"]
    for format_name in possible_formats:
        for ext in extensions:
            filename = f"{format_name}{ext}"
            if os.path.exists(os.path.join(ROOMS_DIR, filename)):
                return url_for("static", filename=f"images/rooms/{filename}")
    return get_room_image(room_number)

def sync_room_statuses():
    """Синхронизирует статусы номеров с актуальными бронированиями."""
    try:
        conn = get_db()
        cursor = conn.cursor()
        today_str = datetime.now().date().strftime("%Y-%m-%d")
        cursor.execute("UPDATE Номера SET Статус = 'Свободен'")
        cursor.execute("""
            SELECT DISTINCT ID_Номера FROM Бронирования
            WHERE Статус = 'Заселен' AND Дата_заезда <= ? AND Дата_выезда > ?
        """, (today_str, today_str))
        for room in cursor.fetchall():
            cursor.execute("UPDATE Номера SET Статус = 'Занят' WHERE ID_Номера = ?", (room["ID_Номера"],))
        cursor.execute("""
            SELECT DISTINCT ID_Номера FROM Бронирования
            WHERE Статус = 'Подтверждено' AND Дата_заезда > ?
        """, (today_str,))
        for room in cursor.fetchall():
            cursor.execute("""
                UPDATE Номера SET Статус = 'Будет занят'
                WHERE ID_Номера = ? AND Статус = 'Свободен'
            """, (room["ID_Номера"],))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Ошибка синхронизации: {e}")
        return False

def register_context_processors(app):
    @app.context_processor
    def utility_processor():
        return {
            "now": datetime.now(),
            "today": datetime.now().date(),
            "timedelta": timedelta,
            "get_room_image": get_room_image,
            "get_room_image_extra": get_room_image_extra,
        }
