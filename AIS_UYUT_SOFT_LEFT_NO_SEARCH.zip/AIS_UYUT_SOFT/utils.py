"""Общие вспомогательные функции приложения."""
import os
from datetime import datetime, timedelta
from flask import url_for
from db import get_db

def init_uploads():
    upload_folder = os.path.join("static", "images", "rooms")
    os.makedirs(upload_folder, exist_ok=True)

def get_room_image(room_number):
    room_number_str = str(room_number)
    extensions = [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG", ".WEBP"]
    for ext in extensions:
        filename = f"{room_number_str}{ext}"
        full_path = os.path.join("static", "images", "rooms", filename)
        if os.path.exists(full_path):
            return url_for("static", filename=f"images/rooms/{filename}")
    return url_for("static", filename="images/rooms/default.jpg")

def get_room_image_extra(room_number, index):
    room_number_str = str(room_number)
    possible_formats = [
        f"{room_number_str}-{index}", f"{room_number_str}_{index}",
        f"{room_number_str} {index}", f"{room_number_str}a{index}",
        f"{room_number_str}_{index:02d}",
    ]
    extensions = [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG", ".WEBP"]
    for format_name in possible_formats:
        for ext in extensions:
            filename = f"{format_name}{ext}"
            if os.path.exists(os.path.join("static", "images", "rooms", filename)):
                return url_for("static", filename=f"images/rooms/{filename}")
    return get_room_image(room_number)

def sync_room_statuses():
    """Синхронизирует статусы номеров с актуальными бронированиями."""
    try:
        conn = get_db()
        cursor = conn.cursor()
        today_str = datetime.now().date().strftime("%Y-%m-%d")
        cursor.execute("UPDATE Номера SET Статус = 'Свободен'")
        cursor.execute("""
            SELECT DISTINCT ID_Номера FROM Бронирования
            WHERE Статус = 'Заселен' AND Дата_заезда <= ? AND Дата_выезда > ?
        """, (today_str, today_str))
        for room in cursor.fetchall():
            cursor.execute("UPDATE Номера SET Статус = 'Занят' WHERE ID_Номера = ?", (room["ID_Номера"],))
        cursor.execute("""
            SELECT DISTINCT ID_Номера FROM Бронирования
            WHERE Статус = 'Подтверждено' AND Дата_заезда > ?
        """, (today_str,))
        for room in cursor.fetchall():
            cursor.execute("""
                UPDATE Номера SET Статус = 'Будет занят'
                WHERE ID_Номера = ? AND Статус = 'Свободен'
            """, (room["ID_Номера"],))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Ошибка синхронизации: {e}")
        return False

def register_context_processors(app):
    @app.context_processor
    def utility_processor():
        return {
            "now": datetime.now(),
            "today": datetime.now().date(),
            "timedelta": timedelta,
            "get_room_image": get_room_image,
            "get_room_image_extra": get_room_image_extra,
        }
