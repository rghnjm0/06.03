# app.py
"""Точка входа в приложение отеля «Уют».

Маршруты и служебная логика вынесены в отдельные модули,
чтобы проект было проще поддерживать и расширять.
"""
import os
from flask import Flask
from db import DB_NAME
from utils import init_uploads, sync_room_statuses, register_context_processors
from routes.public import register_public_routes
from routes.auth import register_auth_routes
from routes.admin import register_admin_routes

app = Flask(__name__)
app.secret_key = os.environ.get("UYUT_SECRET_KEY", "uyut-dev-secret-change-in-production")
app.config["UPLOAD_FOLDER"] = "static/images/rooms"
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

init_uploads()
register_context_processors(app)
register_public_routes(app)
register_auth_routes(app)
register_admin_routes(app)

if __name__ == "__main__":
    if not os.path.exists(DB_NAME):
        print("База данных не найдена. Запустите: python db.py")
    else:
        sync_room_statuses()
        app.run(debug=True, host="0.0.0.0", port=5000)
