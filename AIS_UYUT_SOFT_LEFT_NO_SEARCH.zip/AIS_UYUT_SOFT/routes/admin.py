from flask import render_template, request, redirect, url_for, flash, session
from datetime import datetime, timedelta
import sqlite3
import os
from db import get_db, DB_NAME
from utils import sync_room_statuses
from auth import admin_required



def register_admin_routes(app):
    @app.route('/admin/dashboard')


    @admin_required


    def admin_dashboard():


        sync_room_statuses()


        conn = get_db()


        cursor = conn.cursor()





        cursor.execute("SELECT COUNT(*) FROM Клиенты")


        total_clients = cursor.fetchone()[0]





        cursor.execute("SELECT COUNT(*) FROM Номера")


        total_rooms = cursor.fetchone()[0]





        cursor.execute("SELECT COUNT(*) FROM Номера WHERE Статус = 'Свободен'")


        free_rooms = cursor.fetchone()[0]





        cursor.execute("SELECT COUNT(*) FROM Бронирования WHERE Статус IN ('Подтверждено', 'Заселен')")


        active_bookings = cursor.fetchone()[0]





        cursor.execute("""


            SELECT COUNT(*) FROM Бронирования 


            WHERE Статус = 'Подтверждено' AND Дата_заезда >= date('now')


        """)


        upcoming_bookings = cursor.fetchone()[0]





        # Статистика по категориям номеров


        cursor.execute("""


            SELECT Категория, 


                   COUNT(*) as total,


                   SUM(CASE WHEN Статус = 'Свободен' THEN 1 ELSE 0 END) as free


            FROM Номера


            GROUP BY Категория


        """)


        room_status_stats = cursor.fetchall()





        # Ближайшие заезды


        cursor.execute("""


            SELECT b.Дата_заезда, c.Фамилия, c.Имя, n.Номер_Комнаты


            FROM Бронирования b


            JOIN Клиенты c ON b.ID_Клиента = c.ID_Клиента


            JOIN Номера n ON b.ID_Номера = n.ID_Номера


            WHERE b.Статус = 'Подтверждено' 


            AND b.Дата_заезда BETWEEN date('now') AND date('now', '+2 days')


            ORDER BY b.Дата_заезда


            LIMIT 5


        """)


        upcoming_checkins = cursor.fetchall()





        # Статистика бронирований по категориям


        cursor.execute("""


            SELECT n.Категория, COUNT(*) as count


            FROM Бронирования b


            JOIN Номера n ON b.ID_Номера = n.ID_Номера


            WHERE b.Статус != 'Отменено'


            GROUP BY n.Категория


            ORDER BY count DESC


        """)


        booking_stats = cursor.fetchall()





        # Финансовая статистика


        cursor.execute("""


            SELECT 


                SUM(Предоплата) as total_prepaid,


                SUM(CASE WHEN Статус = 'Подтверждено' THEN Предоплата * 7/3 ELSE 0 END) as total_remaining,


                SUM(CASE WHEN Статус != 'Отменено' THEN Предоплата * 10/3 ELSE 0 END) as total_amount


            FROM Бронирования


            WHERE Статус != 'Отменено'


        """)


        financial = cursor.fetchone()


        if financial and financial['total_prepaid'] is None:


            financial = {'total_prepaid': 0, 'total_remaining': 0, 'total_amount': 0}





        # Популярные номера


        cursor.execute("""


            SELECT n.Номер_Комнаты, n.Категория, COUNT(b.ID_Бронирования) as booking_count


            FROM Номера n


            LEFT JOIN Бронирования b ON n.ID_Номера = b.ID_Номера AND b.Статус != 'Отменено'


            GROUP BY n.ID_Номера


            ORDER BY booking_count DESC


            LIMIT 5


        """)


        popular_rooms = cursor.fetchall()





        # Свежие бронирования


        cursor.execute("""


            SELECT b.*, n.Номер_Комнаты, c.Фамилия, c.Имя


            FROM Бронирования b


            JOIN Номера n ON b.ID_Номера = n.ID_Номера


            JOIN Клиенты c ON b.ID_Клиента = c.ID_Клиента


            ORDER BY b.Дата_бронирования DESC


            LIMIT 8


        """)


        recent_bookings = cursor.fetchall()





        conn.close()





        occupied_rooms = total_rooms - free_rooms





        return render_template('admin/dashboard.html',


                               total_clients=total_clients,


                               total_rooms=total_rooms,


                               free_rooms=free_rooms,


                               occupied_rooms=occupied_rooms,


                               active_bookings=active_bookings,


                               upcoming_bookings=upcoming_bookings,


                               room_status_stats=room_status_stats,


                               upcoming_checkins=upcoming_checkins,


                               booking_stats=booking_stats,


                               financial=financial,


                               popular_rooms=popular_rooms,


                               recent_bookings=recent_bookings)








    # Выход из админ-панели


    @app.route('/admin/logout')


    def admin_logout():


        session.clear()


        flash('Вы вышли из админ-панели', 'info')


        return redirect(url_for('login'))








    # Управление номерами


    @app.route('/admin/rooms')


    @admin_required


    def admin_rooms():


        sync_room_statuses()


        conn = get_db()


        cursor = conn.cursor()


        cursor.execute("SELECT * FROM Номера ORDER BY Номер_Комнаты")


        rooms = cursor.fetchall()


        conn.close()


        return render_template('admin/rooms.html', rooms=rooms)


    @app.route('/admin/room/add', methods=['GET', 'POST'])


    @admin_required


    def admin_room_add():


        if request.method == 'POST':


            try:


                room_number = request.form['room_number']


                category = request.form['category']


                capacity = int(request.form['capacity'])


                price = float(request.form['price'])


                floor = int(request.form['floor'])


                status = request.form['status']





                conn = get_db()


                cursor = conn.cursor()





                cursor.execute("SELECT COUNT(*) FROM Номера")


                count = cursor.fetchone()[0] + 1


                room_id = f"RM{count:03d}"





                cursor.execute("""


                    INSERT INTO Номера (ID_Номера, Номер_Комнаты, Категория, Вместимость, Цена_за_сутки, Статус, Этаж)


                    VALUES (?, ?, ?, ?, ?, ?, ?)


                """, (room_id, room_number, category, capacity, price, status, floor))





                conn.commit()


                conn.close()


                flash('Номер успешно добавлен', 'success')


                return redirect(url_for('admin_rooms'))


            except Exception as e:


                flash(f'Ошибка: {str(e)}', 'danger')





        return render_template('admin/room_form.html')


    @app.route('/admin/room/edit/<string:room_id>', methods=['GET', 'POST'])


    @admin_required


    def admin_room_edit(room_id):


        conn = get_db()


        cursor = conn.cursor()





        if request.method == 'POST':


            try:


                room_number = request.form['room_number']


                category = request.form['category']


                capacity = int(request.form['capacity'])


                price = float(request.form['price'])


                floor = int(request.form['floor'])


                status = request.form['status']





                cursor.execute("""


                    UPDATE Номера 


                    SET Номер_Комнаты=?, Категория=?, Вместимость=?, Цена_за_сутки=?, Статус=?, Этаж=?


                    WHERE ID_Номера=?


                """, (room_number, category, capacity, price, status, floor, room_id))





                conn.commit()


                flash('Номер успешно обновлен', 'success')


                return redirect(url_for('admin_rooms'))


            except Exception as e:


                flash(f'Ошибка: {str(e)}', 'danger')





        cursor.execute("SELECT * FROM Номера WHERE ID_Номера = ?", (room_id,))


        room = cursor.fetchone()


        conn.close()





        return render_template('admin/room_form.html', room=room)


    @app.route('/admin/room/delete/<string:room_id>')


    @admin_required


    def admin_room_delete(room_id):


        try:


            conn = get_db()


            cursor = conn.cursor()





            cursor.execute("""


                SELECT COUNT(*) FROM Бронирования 


                WHERE ID_Номера = ? AND Статус IN ('Подтверждено', 'Заселен')


            """, (room_id,))





            if cursor.fetchone()[0] > 0:


                flash('Нельзя удалить номер с активными бронированиями', 'danger')


            else:


                cursor.execute("DELETE FROM Номера WHERE ID_Номера = ?", (room_id,))


                conn.commit()


                flash('Номер удален', 'success')





            conn.close()


        except Exception as e:


            flash(f'Ошибка: {str(e)}', 'danger')





        return redirect(url_for('admin_rooms'))








    # Управление бронированиями


    @app.route('/admin/bookings')


    @admin_required


    def admin_bookings():


        sync_room_statuses()


        status = request.args.get('status', '')





        conn = get_db()


        cursor = conn.cursor()





        query = """


            SELECT b.*, n.Номер_Комнаты, n.Категория, c.Фамилия, c.Имя, c.Телефон


            FROM Бронирования b


            JOIN Номера n ON b.ID_Номера = n.ID_Номера


            JOIN Клиенты c ON b.ID_Клиента = c.ID_Клиента


        """


        params = []





        if status:


            query += " WHERE b.Статус = ?"


            params.append(status)





        query += " ORDER BY b.Дата_заезда DESC"





        cursor.execute(query, params)


        bookings = cursor.fetchall()





        conn.close()


        return render_template('admin/bookings.html', bookings=bookings, selected_status=status)


    @app.route('/admin/booking/update/<string:booking_id>', methods=['POST'])


    @admin_required


    def admin_booking_update(booking_id):


        status = request.form['status']





        try:


            conn = get_db()


            cursor = conn.cursor()





            cursor.execute("SELECT ID_Номера, Дата_заезда, Дата_выезда FROM Бронирования WHERE ID_Бронирования = ?",


                           (booking_id,))


            booking = cursor.fetchone()





            cursor.execute("UPDATE Бронирования SET Статус = ? WHERE ID_Бронирования = ?", (status, booking_id))





            today = datetime.now().date()


            check_in_date = datetime.strptime(booking['Дата_заезда'], '%Y-%m-%d').date()





            if status in ['Отменено', 'Завершено']:


                # Проверяем, есть ли другие активные брони


                cursor.execute("""


                    SELECT COUNT(*) FROM Бронирования 


                    WHERE ID_Номера = ? AND Статус IN ('Подтверждено', 'Заселен')


                """, (booking['ID_Номера'],))


                if cursor.fetchone()[0] == 0:


                    cursor.execute("UPDATE Номера SET Статус = 'Свободен' WHERE ID_Номера = ?", (booking['ID_Номера'],))


            elif status == 'Заселен':


                cursor.execute("UPDATE Номера SET Статус = 'Занят' WHERE ID_Номера = ?", (booking['ID_Номера'],))


            elif status == 'Подтверждено':


                if check_in_date == today or check_in_date == today + timedelta(days=1):


                    cursor.execute("UPDATE Номера SET Статус = 'Занят' WHERE ID_Номера = ?", (booking['ID_Номера'],))


                else:


                    cursor.execute("UPDATE Номера SET Статус = 'Будет занят' WHERE ID_Номера = ?", (booking['ID_Номера'],))





            conn.commit()


            conn.close()


            flash('Статус бронирования обновлен', 'success')


        except Exception as e:


            flash(f'Ошибка: {str(e)}', 'danger')





        return redirect(url_for('admin_bookings'))








    # Управление клиентами


    @app.route('/admin/clients')


    @admin_required


    def admin_clients():


        search = request.args.get('search', '')





        conn = get_db()


        cursor = conn.cursor()





        if search:


            cursor.execute("""


                SELECT * FROM Клиенты 


                WHERE Фамилия LIKE ? OR Имя LIKE ? OR Телефон LIKE ?


                ORDER BY Фамилия


            """, (f'%{search}%', f'%{search}%', f'%{search}%'))


        else:


            cursor.execute("SELECT * FROM Клиенты ORDER BY Фамилия")





        clients = cursor.fetchall()


        conn.close()





        return render_template('admin/clients.html', clients=clients, search=search)


    @app.route('/admin/client/<string:client_id>')


    @admin_required


    def admin_client_detail(client_id):


        conn = get_db()


        cursor = conn.cursor()





        cursor.execute("SELECT * FROM Клиенты WHERE ID_Клиента = ?", (client_id,))


        client = cursor.fetchone()





        cursor.execute("""


            SELECT b.*, n.Номер_Комнаты, n.Категория


            FROM Бронирования b


            JOIN Номера n ON b.ID_Номера = n.ID_Номера


            WHERE b.ID_Клиента = ?


            ORDER BY b.Дата_заезда DESC


        """, (client_id,))


        bookings = cursor.fetchall()





        conn.close()





        return render_template('admin/client_detail.html', client=client, bookings=bookings)








    # Отчеты


    @app.route('/admin/reports')


    @admin_required


    def admin_reports():


        conn = get_db()


        cursor = conn.cursor()





        cursor.execute("""


            SELECT Категория, COUNT(*) as count, AVG(Цена_за_сутки) as avg_price


            FROM Номера


            GROUP BY Категория


        """)


        room_stats = cursor.fetchall()





        cursor.execute("""


            SELECT strftime('%Y-%m', Дата_заезда) as month, COUNT(*) as count


            FROM Бронирования


            WHERE Статус != 'Отменено'


            GROUP BY month


            ORDER BY month DESC


            LIMIT 6


        """)


        monthly_stats = cursor.fetchall()





        cursor.execute("""


            SELECT SUM(Предоплата) as total_prepaid, COUNT(*) as total_bookings


            FROM Бронирования


            WHERE Статус != 'Отменено'


        """)


        financial = cursor.fetchone()


        if financial and financial['total_prepaid'] is None:


            financial = {'total_prepaid': 0, 'total_bookings': 0}





        conn.close()





        return render_template('admin/reports.html',


                               room_stats=room_stats,


                               monthly_stats=monthly_stats,


                               financial=financial)








    if __name__ == '__main__':


        if not os.path.exists(DB_NAME):


            print("База данных не найдена. Запустите db.py для создания базы данных.")


            print("Выполните команду: python db.py")


        else:


            # Синхронизация статусов при запуске


            sync_room_statuses()


            app.run(debug=True, host='0.0.0.0', port=5000)
