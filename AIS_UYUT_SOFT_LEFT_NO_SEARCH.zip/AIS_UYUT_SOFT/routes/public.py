from flask import render_template, request, redirect, url_for, flash, session
from datetime import datetime, timedelta
import sqlite3
import os
from db import get_db, DB_NAME
from utils import sync_room_statuses



def register_public_routes(app):
    @app.route('/')


    def index():


        try:


            sync_room_statuses()


            conn = get_db()


            cursor = conn.cursor()


            cursor.execute("SELECT DISTINCT Категория FROM Номера ORDER BY Категория")


            categories = [row['Категория'] for row in cursor.fetchall()]


            cursor.execute("""


                SELECT * FROM Номера 


                ORDER BY 


                    CASE Статус 


                        WHEN 'Свободен' THEN 1


                        WHEN 'Будет занят' THEN 2


                        WHEN 'Занят' THEN 3


                    END,


                    Номер_Комнаты


            """)


            rooms = cursor.fetchall()


            conn.close()


            return render_template('index.html', rooms=rooms, categories=categories)


        except Exception as e:


            flash(f'Ошибка при загрузке данных: {str(e)}', 'danger')


            return render_template('index.html', rooms=[], categories=[])








    # Поиск номеров


    @app.route('/search')


    def search_rooms():


        try:


            sync_room_statuses()


            check_in = request.args.get('check_in', '')


            check_out = request.args.get('check_out', '')


            guests = request.args.get('guests', 1, type=int)


            category = request.args.get('category', '')





            conn = get_db()


            cursor = conn.cursor()





            query = """


                SELECT * FROM Номера 


                WHERE Вместимость >= ? 


                AND Статус = 'Свободен'


            """


            params = [guests]





            if category:


                query += " AND Категория = ?"


                params.append(category)





            if check_in and check_out:


                query += """


                    AND ID_Номера NOT IN (


                        SELECT ID_Номера FROM Бронирования 


                        WHERE Статус IN ('Подтверждено', 'Заселен')


                        AND NOT (Дата_выезда <= ? OR Дата_заезда >= ?)


                    )


                """


                params.extend([check_in, check_out])





            query += " ORDER BY Цена_за_сутки"





            cursor.execute(query, params)


            rooms = cursor.fetchall()





            cursor.execute("SELECT DISTINCT Категория FROM Номера ORDER BY Категория")


            categories = [row['Категория'] for row in cursor.fetchall()]





            conn.close()





            return render_template('rooms.html', rooms=rooms, categories=categories,


                                   check_in=check_in, check_out=check_out,


                                   guests=guests, selected_category=category)


        except Exception as e:


            flash(f'Ошибка при поиске: {str(e)}', 'danger')


            return redirect(url_for('index'))








    # Детальная страница номера


    @app.route('/room/<string:room_id>')


    def room_detail(room_id):


        try:


            sync_room_statuses()


            conn = get_db()


            cursor = conn.cursor()


            cursor.execute("SELECT * FROM Номера WHERE ID_Номера = ?", (room_id,))


            room = cursor.fetchone()


            if not room:


                flash('Номер не найден', 'danger')


                conn.close()


                return redirect(url_for('index'))


            conn.close()


            return render_template('room_detail.html', room=room)


        except Exception as e:


            flash(f'Ошибка при загрузке номера: {str(e)}', 'danger')


            return redirect(url_for('index'))








    # Регистрация клиента


    @app.route('/contact')


    def contact():


        return render_template('contact.html')








    # ============= АДМИН-ПАНЕЛЬ =============





    # Главная админ-панели
