"""Авторизация и проверки доступа."""
from functools import wraps
from flask import session, flash, redirect, url_for

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "client_id" not in session and session.get("user_role") != "admin":
            flash("Пожалуйста, войдите в систему", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_role") != "admin":
            flash("Доступ запрещен. Требуются права администратора.", "danger")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function
