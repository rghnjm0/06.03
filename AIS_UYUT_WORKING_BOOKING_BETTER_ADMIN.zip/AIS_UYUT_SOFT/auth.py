"""Проверки доступа для сайта «Уют»."""
from functools import wraps
from flask import session, flash, redirect, url_for

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("user_role"):
            flash("Пожалуйста, войдите в систему.", "warning")
            return redirect(url_for("login", next=request_path()))
        return f(*args, **kwargs)
    return decorated_function

def client_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_role") != "client" or not session.get("client_id"):
            flash("Для бронирования войдите как гость.", "warning")
            return redirect(url_for("login", next=request_path()))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_role") != "admin":
            flash("Доступ доступен только администратору.", "danger")
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return decorated_function

def request_path():
    # Импорт внутри функции, чтобы не создавать циклическую зависимость.
    from flask import request
    return request.full_path.rstrip("?")
