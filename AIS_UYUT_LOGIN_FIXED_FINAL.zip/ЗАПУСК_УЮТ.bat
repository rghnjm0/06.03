@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Создаю виртуальное окружение...
  py -3 -m venv .venv
  if errorlevel 1 (
    echo Не удалось создать .venv. Проверьте, что Python установлен и команда py доступна.
    pause
    exit /b 1
  )
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Не удалось установить зависимости.
  pause
  exit /b 1
)
python app.py
pause
