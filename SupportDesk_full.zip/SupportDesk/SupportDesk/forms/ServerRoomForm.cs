﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    /// <summary>
    /// Журнал посещений серверной: кто заходил, когда, зачем и что делал.
    /// «Кто», «когда», «зачем» и «что делал» подставляются автоматически.
    /// </summary>
    public partial class ServerRoomForm : Form
    {
        #region Настройки формы
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion
        #region Локальные переменные
        private SQLiteConnection DB;
        private List<ServerRoomTicket> activeTickets = new List<ServerRoomTicket>();
        private List<ServerRoomVisit> shownVisits = new List<ServerRoomVisit>();
        private string suggestionsFor = "";
        private string lastAutoReason = "";
        private bool loading;
        private static readonly Color colorInside = Color.FromArgb(220, 245, 220);
        private static readonly Color colorStale = Color.FromArgb(255, 232, 190);
        private static bool IsAdmin => DataUsers.GroupUser == "ADMIN";
        #endregion

        public ServerRoomForm()
        {
            InitializeComponent();
        }

        private void ServerRoomForm_Load(object sender, EventArgs e)
        {
            try
            {
                DB = new SQLiteConnection(Database.connectionString);
                DB.Open();
                ServerRoomJournal.EnsureTable(DB);

                expUIButtonDelete.Visible = IsAdmin;

                loading = true;
                comboBoxPeriod.Items.AddRange(new object[] { "Сегодня", "7 дней", "30 дней", "Всё время" });
                comboBoxPeriod.SelectedIndex = 2;
                loading = false;

                foreach (string name in ServerRoomJournal.GetKnownVisitors(DB))
                {
                    comboBoxVisitor.Items.Add(name);
                }
                comboBoxVisitor.Text = DataUsers.Initials;
                LoadReasonSuggestions();
                RefreshJournal(null);
            }
            catch (Exception ex)
            {
                loading = false;
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }

        private void ServerRoomForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (DB != null)
            {
                DB.Dispose();
                DB = null;
            }
        }

        #region Управление формой
        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _ = ReleaseCapture();
                _ = SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
        #region Назад
        [Obsolete]
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            if (DataUsers.GroupUser == "ADMIN")
            {
                Form fMain = new MainAdminForm();
                fMain.Show();
                fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                Hide();
            }
            else
            {
                Form fMain = new MainWorkerForm();
                fMain.Show();
                fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                Hide();
            }
        }

        private void Form_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }
        #endregion

        #region Автозаполнение «Зачем»
        private string CurrentVisitor()
        {
            string visitor = comboBoxVisitor.Text.Trim();
            return visitor.Length > 0 ? visitor : (DataUsers.Initials ?? "");
        }

        /// <summary>
        /// Подставляет причину визита: заявка сотрудника «В работе», иначе первая готовая причина.
        /// Причину, которую человек уже вписал сам, не затирает.
        /// </summary>
        private void LoadReasonSuggestions()
        {
            string visitor = CurrentVisitor();
            suggestionsFor = visitor;
            activeTickets = ServerRoomJournal.GetActiveTickets(DB, visitor);

            comboBoxReason.Items.Clear();
            foreach (ServerRoomTicket ticket in activeTickets)
            {
                comboBoxReason.Items.Add(ticket.Caption);
            }
            foreach (string template in ServerRoomJournal.ReasonTemplates)
            {
                comboBoxReason.Items.Add(template);
            }

            string current = comboBoxReason.Text.Trim();
            if (current.Length == 0 || current == lastAutoReason)
            {
                lastAutoReason = activeTickets.Count > 0 ? activeTickets[0].Caption : "";
                comboBoxReason.Text = lastAutoReason;
            }
        }

        private void ComboBoxVisitor_Changed(object sender, EventArgs e)
        {
            if (DB != null && !string.Equals(suggestionsFor, CurrentVisitor(), StringComparison.Ordinal))
            {
                LoadReasonSuggestions();
            }
        }
        #endregion

        #region Журнал
        private DateTime? PeriodStart()
        {
            DateTime today = DateTime.Today;
            switch (comboBoxPeriod.SelectedIndex)
            {
                case 0: return today;
                case 1: return today.AddDays(-6);
                case 2: return today.AddDays(-29);
                default: return null;
            }
        }

        private static bool TextContains(string text, string query)
        {
            return CultureInfo.CurrentCulture.CompareInfo.IndexOf(text ?? "", query, CompareOptions.IgnoreCase) >= 0;
        }

        private void Filter_Changed(object sender, EventArgs e)
        {
            if (!loading)
            {
                RefreshJournal(null);
            }
        }

        private void RefreshJournal(int? selectId)
        {
            if (DB == null)
            {
                return;
            }
            try
            {
                string query = textBoxSearch.Text.Trim();
                bool onlyInside = checkBoxOpenOnly.Checked;
                DateTime now = DateTime.Now;

                shownVisits = ServerRoomJournal.Load(DB, PeriodStart())
                    .Where(v => (!onlyInside || v.IsOpen)
                        && (query.Length == 0 || TextContains(v.Visitor, query) || TextContains(v.Reason, query) || TextContains(v.Actions, query)))
                    .ToList();

                loading = true;
                dataGridViewVisits.Rows.Clear();
                foreach (ServerRoomVisit v in shownVisits)
                {
                    bool stale = v.IsStale(now);
                    string exit = v.Exit.HasValue ? v.Exit.Value.ToString("dd.MM.yyyy HH:mm") : "—";
                    string duration = v.Exit.HasValue
                        ? ServerRoomJournal.FormatDuration(v.Exit.Value - v.Enter)
                        : (stale ? "—" : ServerRoomJournal.FormatDuration(now - v.Enter));
                    int index = dataGridViewVisits.Rows.Add(
                        v.Id,
                        v.Visitor,
                        v.Enter.ToString("dd.MM.yyyy HH:mm"),
                        exit,
                        duration,
                        v.Reason,
                        OneLine(v.Actions),
                        ServerRoomJournal.StateText(v, now));
                    if (v.IsOpen)
                    {
                        dataGridViewVisits.Rows[index].DefaultCellStyle.BackColor = stale ? colorStale : colorInside;
                    }
                }
                dataGridViewVisits.ClearSelection();
                if (selectId.HasValue)
                {
                    foreach (DataGridViewRow row in dataGridViewVisits.Rows)
                    {
                        if (Convert.ToInt32(row.Cells["ColumnId"].Value) == selectId.Value)
                        {
                            row.Selected = true;
                            try
                            {
                                dataGridViewVisits.FirstDisplayedScrollingRowIndex = row.Index;
                            }
                            catch (InvalidOperationException)
                            {
                                // Таблица ещё не отрисована: прокрутка не нужна.
                            }
                            break;
                        }
                    }
                }
                loading = false;

                ShowSelected();
                ShowWhoIsInside(now);
            }
            catch (Exception ex)
            {
                loading = false;
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }

        private static string OneLine(string text)
        {
            return (text ?? "").Replace("\r\n", " | ").Replace("\n", " | ");
        }

        private void ShowWhoIsInside(DateTime now)
        {
            List<string> inside = ServerRoomJournal.Load(DB, DateTime.Today.AddDays(-1))
                .Where(v => v.IsOpen && !v.IsStale(now))
                .Select(v => v.Visitor)
                .Distinct()
                .ToList();
            labelInside.Text = inside.Count == 0
                ? "В серверной сейчас: никого"
                : "В серверной сейчас: " + string.Join(", ", inside);
        }

        private ServerRoomVisit SelectedVisit()
        {
            if (dataGridViewVisits.SelectedRows.Count == 0)
            {
                return null;
            }
            int id = Convert.ToInt32(dataGridViewVisits.SelectedRows[0].Cells["ColumnId"].Value);
            return shownVisits.FirstOrDefault(v => v.Id == id);
        }

        private void DataGridViewVisits_SelectionChanged(object sender, EventArgs e)
        {
            if (!loading)
            {
                ShowSelected();
            }
        }

        private void ShowSelected()
        {
            ServerRoomVisit v = SelectedVisit();
            bool has = v != null;
            textBoxEditReason.Enabled = has;
            textBoxEditActions.Enabled = has;
            textBoxEditReason.Text = has ? v.Reason : "";
            textBoxEditActions.Text = has ? v.Actions : "";
            groupBoxEdit.Text = has
                ? $"Выбранная запись №{v.Id} — {v.Visitor}"
                : "Выбранная запись (выберите строку в таблице, чтобы поправить «Зачем» и «Что делал»)";
        }
        #endregion

        #region Вошёл
        private void ExpUIButtonEnter_Click(object sender, EventArgs e)
        {
            if (DB == null)
            {
                return;
            }
            try
            {
                string visitor = CurrentVisitor();
                if (visitor.Length == 0)
                {
                    MessageBoxUI.Show("Укажите, кто входит в серверную.", "Журнал серверной", "Error");
                    return;
                }

                // Человек мог сменить поле «Кто» и сразу нажать «Вошёл»: подбираем причину под него.
                if (!string.Equals(suggestionsFor, visitor, StringComparison.Ordinal))
                {
                    LoadReasonSuggestions();
                }

                DateTime now = DateTime.Now;
                ServerRoomVisit open = ServerRoomJournal.FindOpenVisit(DB, visitor);
                if (open != null && !open.IsStale(now))
                {
                    MessageBoxUI.Show($"{visitor} уже отмечен(а) в серверной с {open.Enter:dd.MM.yyyy HH:mm}. Сначала отметьте выход.",
                        "Журнал серверной", "Info");
                    return;
                }

                string reason = comboBoxReason.Text.Trim();
                int? requestId = null;
                ServerRoomTicket ticket = activeTickets.FirstOrDefault(t => string.Equals(t.Caption, reason, StringComparison.Ordinal));
                if (ticket != null)
                {
                    requestId = ticket.Id;
                }
                if (reason.Length == 0)
                {
                    reason = ServerRoomJournal.ReasonTemplates[0];
                }

                int id = ServerRoomJournal.Enter(DB, visitor, now, reason, requestId, DataUsers.Initials);
                WriteLog($"{DataUsers.Initials} отметил(а) вход: {visitor}, причина: {reason} ({now:dd.MM.yyyy HH:mm})");
                if (checkBoxTelegram.Checked)
                {
                    TelegramForm.ServerRoomEnter(DataUsers.Initials, visitor, reason, now.ToString("dd.MM.yyyy HH:mm"));
                }
                RefreshJournal(id);
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }
        #endregion

        #region Вышел
        private void ExpUIButtonLeave_Click(object sender, EventArgs e)
        {
            if (DB == null)
            {
                return;
            }
            try
            {
                ServerRoomVisit selected = SelectedVisit();
                bool selectedIsTarget = selected != null && selected.IsOpen;
                ServerRoomVisit target = selectedIsTarget ? selected : ServerRoomJournal.FindOpenVisit(DB, CurrentVisitor());
                if (target == null)
                {
                    MessageBoxUI.Show("Нет открытого визита: никто не отмечен как находящийся в серверной.", "Журнал серверной", "Info");
                    return;
                }

                DateTime now = DateTime.Now;

                // Что человек успел вписать сам (если выбрал свою строку), плюс то, что журнал собрал автоматически.
                string reason = target.Reason;
                string typed = "";
                if (selectedIsTarget)
                {
                    typed = textBoxEditActions.Text.Trim();
                    if (textBoxEditReason.Text.Trim().Length > 0)
                    {
                        reason = textBoxEditReason.Text.Trim();
                    }
                }
                else if (!string.IsNullOrWhiteSpace(target.Actions))
                {
                    typed = target.Actions.Trim();
                }

                string auto = ServerRoomJournal.BuildActions(DB, target.Visitor, target.Enter, now, target.RequestId);
                List<string> parts = new List<string>();
                if (typed.Length > 0)
                {
                    parts.Add(typed);
                }
                if (auto.Length > 0)
                {
                    parts.Add(auto);
                }
                if (target.IsStale(now))
                {
                    parts.Add("Выход отмечен с опозданием, фактическое время ухода неизвестно.");
                }
                string actions = string.Join(Environment.NewLine, parts);

                if (!ServerRoomJournal.Leave(DB, target.Id, now, reason, actions))
                {
                    MessageBoxUI.Show("Этот визит уже закрыт.", "Журнал серверной", "Info");
                    RefreshJournal(target.Id);
                    return;
                }

                string duration = ServerRoomJournal.FormatDuration(now - target.Enter);
                WriteLog($"{DataUsers.Initials} отметил(а) выход: {target.Visitor}, пробыл(а) {duration} ({now:dd.MM.yyyy HH:mm})");
                if (checkBoxTelegram.Checked)
                {
                    TelegramForm.ServerRoomLeave(DataUsers.Initials, target.Visitor, duration, reason, actions);
                }
                RefreshJournal(target.Id);
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }
        #endregion

        #region Обновить
        private void ExpUIButtonRefresh_Click(object sender, EventArgs e)
        {
            RefreshJournal(null);
            LoadReasonSuggestions();
        }
        #endregion

        #region Сохранить правку
        private void ExpUIButtonSave_Click(object sender, EventArgs e)
        {
            ServerRoomVisit v = SelectedVisit();
            if (v == null)
            {
                MessageBoxUI.Show("Выберите запись в таблице.", "Журнал серверной", "Info");
                return;
            }
            if (!IsAdmin && !string.Equals(v.RegisteredBy, DataUsers.Initials, StringComparison.OrdinalIgnoreCase))
            {
                MessageBoxUI.Show("Править можно только записи, которые вы сами создали.", "Журнал серверной", "Error");
                return;
            }
            try
            {
                ServerRoomJournal.UpdateText(DB, v.Id, textBoxEditReason.Text.Trim(), textBoxEditActions.Text.Trim());
                WriteLog($"{DataUsers.Initials} отредактировал(а) запись журнала серверной №{v.Id} ({DateTime.Now:dd.MM.yyyy HH:mm})");
                MessageBoxUI.Show("Сохранение прошло успешно!", "Редактирование", "Accept");
                RefreshJournal(v.Id);
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }
        #endregion

        #region Удалить
        private void ExpUIButtonDelete_Click(object sender, EventArgs e)
        {
            if (!IsAdmin)
            {
                return;
            }
            ServerRoomVisit v = SelectedVisit();
            if (v == null)
            {
                MessageBoxUI.Show("Выберите запись в таблице.", "Журнал серверной", "Info");
                return;
            }
            DialogResult answer = MessageBox.Show(
                $"Удалить запись №{v.Id} ({v.Visitor}, {v.Enter:dd.MM.yyyy HH:mm})?\nЖурнал доступа лучше не чистить без необходимости.",
                "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes)
            {
                return;
            }
            try
            {
                ServerRoomJournal.Delete(DB, v.Id);
                WriteLog($"{DataUsers.Initials} удалил(а) запись журнала серверной №{v.Id}: {v.Visitor}, {v.Enter:dd.MM.yyyy HH:mm} ({DateTime.Now:dd.MM.yyyy HH:mm})");
                RefreshJournal(null);
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }
        #endregion

        #region Экспорт
        private void ExpUIButtonExport_Click(object sender, EventArgs e)
        {
            if (shownVisits.Count == 0)
            {
                MessageBoxUI.Show("В таблице нет записей для экспорта.", "Экспорт", "Info");
                return;
            }
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "Таблица CSV (*.csv)|*.csv";
                dialog.FileName = $"журнал_серверной_{DateTime.Now:yyyy-MM-dd}.csv";
                if (dialog.ShowDialog() != DialogResult.OK)
                {
                    return;
                }
                try
                {
                    DateTime now = DateTime.Now;
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("№;Кто;Вошёл;Вышел;Длительность;Зачем;Что делал;Статус;Отметил(а)");
                    foreach (ServerRoomVisit v in shownVisits)
                    {
                        string duration = v.Exit.HasValue ? ServerRoomJournal.FormatDuration(v.Exit.Value - v.Enter) : "";
                        sb.AppendLine(string.Join(";", new[]
                        {
                            v.Id.ToString(CultureInfo.InvariantCulture),
                            Csv(v.Visitor),
                            Csv(v.Enter.ToString("dd.MM.yyyy HH:mm")),
                            Csv(v.Exit.HasValue ? v.Exit.Value.ToString("dd.MM.yyyy HH:mm") : ""),
                            Csv(duration),
                            Csv(v.Reason),
                            Csv(v.Actions),
                            Csv(ServerRoomJournal.StateText(v, now)),
                            Csv(v.RegisteredBy)
                        }));
                    }
                    File.WriteAllText(dialog.FileName, sb.ToString(), new UTF8Encoding(true));
                    MessageBoxUI.Show("Журнал сохранён!", "Экспорт", "Accept");
                }
                catch (Exception ex)
                {
                    MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
                }
            }
        }

        private static string Csv(string value)
        {
            string text = value ?? "";
            // Защита от формул: Excel выполнит ячейку, начинающуюся с = + - @.
            if (text.Length > 0 && "=+-@".IndexOf(text[0]) >= 0)
            {
                text = "'" + text;
            }
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }
        #endregion

        private static void WriteLog(string text)
        {
            File.AppendAllText(Logs.file, $"[{ServerRoomJournal.LogSection}]{text}");
            File.AppendAllText(Logs.file, Environment.NewLine);
        }
    }
}
