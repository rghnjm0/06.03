﻿namespace SupportDesk.forms
{
    partial class ServerRoomForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServerRoomForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.expUIButtonEnter = new ExpUI.dll.ExpUIButton();
            this.expUIButtonLeave = new ExpUI.dll.ExpUIButton();
            this.expUIButtonRefresh = new ExpUI.dll.ExpUIButton();
            this.expUIButtonSave = new ExpUI.dll.ExpUIButton();
            this.expUIButtonExport = new ExpUI.dll.ExpUIButton();
            this.expUIButtonDelete = new ExpUI.dll.ExpUIButton();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.buttonExit = new ExpUI.dll.ExpUIButtonIcon();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelFilter = new System.Windows.Forms.Panel();
            this.labelPeriod = new System.Windows.Forms.Label();
            this.comboBoxPeriod = new System.Windows.Forms.ComboBox();
            this.labelSearch = new System.Windows.Forms.Label();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.checkBoxOpenOnly = new System.Windows.Forms.CheckBox();
            this.dataGridViewVisits = new System.Windows.Forms.DataGridView();
            this.ColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnVisitor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnEnter = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnExit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDuration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReason = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnActions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.groupBoxNew = new System.Windows.Forms.GroupBox();
            this.labelVisitor = new System.Windows.Forms.Label();
            this.comboBoxVisitor = new System.Windows.Forms.ComboBox();
            this.labelReason = new System.Windows.Forms.Label();
            this.comboBoxReason = new System.Windows.Forms.ComboBox();
            this.groupBoxEdit = new System.Windows.Forms.GroupBox();
            this.labelEditReason = new System.Windows.Forms.Label();
            this.textBoxEditReason = new System.Windows.Forms.TextBox();
            this.labelEditActions = new System.Windows.Forms.Label();
            this.textBoxEditActions = new System.Windows.Forms.TextBox();
            this.labelInside = new System.Windows.Forms.Label();
            this.checkBoxTelegram = new System.Windows.Forms.CheckBox();
            this.panelMenu.SuspendLayout();
            this.panelTitle.SuspendLayout();
            this.panelFilter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisits)).BeginInit();
            this.panelBottom.SuspendLayout();
            this.groupBoxNew.SuspendLayout();
            this.groupBoxEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.DodgerBlue;
            this.panelMenu.Controls.Add(this.expUIButtonEnter);
            this.panelMenu.Controls.Add(this.expUIButtonLeave);
            this.panelMenu.Controls.Add(this.expUIButtonRefresh);
            this.panelMenu.Controls.Add(this.expUIButtonSave);
            this.panelMenu.Controls.Add(this.expUIButtonExport);
            this.panelMenu.Controls.Add(this.expUIButtonDelete);
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(150, 558);
            this.panelMenu.TabIndex = 1;
            this.panelMenu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormControl);
            // 
            // expUIButtonEnter
            // 
            this.expUIButtonEnter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.expUIButtonEnter.BorderSize = 1;
            this.expUIButtonEnter.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonEnter.ColorTextForBorder = System.Drawing.Color.White;
            this.expUIButtonEnter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.expUIButtonEnter.DisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonEnter.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.expUIButtonEnter.ForeColor = System.Drawing.Color.White;
            this.expUIButtonEnter.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.expUIButtonEnter.Image = ((System.Drawing.Image)(resources.GetObject("expUIButtonEnter.Image")));
            this.expUIButtonEnter.Location = new System.Drawing.Point(0, 60);
            this.expUIButtonEnter.Name = "expUIButtonEnter";
            this.expUIButtonEnter.Remember = false;
            this.expUIButtonEnter.ResponsiveFontOn = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.expUIButtonEnter.ResponsiveText = true;
            this.expUIButtonEnter.Size = new System.Drawing.Size(150, 35);
            this.expUIButtonEnter.StyleButton = ExpUI.dll.ExpUIButton.styleButton.Standart;
            this.expUIButtonEnter.TabIndex = 1;
            this.expUIButtonEnter.Text = "Вошёл";
            this.expUIButtonEnter.TextAlign = ExpUI.dll.ExpUIButton.textAlign.MiddleRight;
            this.expUIButtonEnter.Click += new System.EventHandler(this.ExpUIButtonEnter_Click);
            // 
            // expUIButtonLeave
            // 
            this.expUIButtonLeave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.expUIButtonLeave.BorderSize = 1;
            this.expUIButtonLeave.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonLeave.ColorTextForBorder = System.Drawing.Color.White;
            this.expUIButtonLeave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.expUIButtonLeave.DisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonLeave.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.expUIButtonLeave.ForeColor = System.Drawing.Color.White;
            this.expUIButtonLeave.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.expUIButtonLeave.Image = ((System.Drawing.Image)(resources.GetObject("expUIButtonLeave.Image")));
            this.expUIButtonLeave.Location = new System.Drawing.Point(0, 105);
            this.expUIButtonLeave.Name = "expUIButtonLeave";
            this.expUIButtonLeave.Remember = false;
            this.expUIButtonLeave.ResponsiveFontOn = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.expUIButtonLeave.ResponsiveText = true;
            this.expUIButtonLeave.Size = new System.Drawing.Size(150, 35);
            this.expUIButtonLeave.StyleButton = ExpUI.dll.ExpUIButton.styleButton.Standart;
            this.expUIButtonLeave.TabIndex = 2;
            this.expUIButtonLeave.Text = "Вышел";
            this.expUIButtonLeave.TextAlign = ExpUI.dll.ExpUIButton.textAlign.MiddleRight;
            this.expUIButtonLeave.Click += new System.EventHandler(this.ExpUIButtonLeave_Click);
            // 
            // expUIButtonRefresh
            // 
            this.expUIButtonRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(116)))), ((int)(((byte)(228)))));
            this.expUIButtonRefresh.BorderSize = 1;
            this.expUIButtonRefresh.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonRefresh.ColorTextForBorder = System.Drawing.Color.White;
            this.expUIButtonRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.expUIButtonRefresh.DisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonRefresh.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.expUIButtonRefresh.ForeColor = System.Drawing.Color.White;
            this.expUIButtonRefresh.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.expUIButtonRefresh.Image = ((System.Drawing.Image)(resources.GetObject("expUIButtonRefresh.Image")));
            this.expUIButtonRefresh.Location = new System.Drawing.Point(0, 170);
            this.expUIButtonRefresh.Name = "expUIButtonRefresh";
            this.expUIButtonRefresh.Remember = false;
            this.expUIButtonRefresh.ResponsiveFontOn = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.expUIButtonRefresh.ResponsiveText = true;
            this.expUIButtonRefresh.Size = new System.Drawing.Size(150, 35);
            this.expUIButtonRefresh.StyleButton = ExpUI.dll.ExpUIButton.styleButton.Standart;
            this.expUIButtonRefresh.TabIndex = 3;
            this.expUIButtonRefresh.Text = "Обновить";
            this.expUIButtonRefresh.TextAlign = ExpUI.dll.ExpUIButton.textAlign.MiddleRight;
            this.expUIButtonRefresh.Click += new System.EventHandler(this.ExpUIButtonRefresh_Click);
            // 
            // expUIButtonSave
            // 
            this.expUIButtonSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(116)))), ((int)(((byte)(228)))));
            this.expUIButtonSave.BorderSize = 1;
            this.expUIButtonSave.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonSave.ColorTextForBorder = System.Drawing.Color.White;
            this.expUIButtonSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.expUIButtonSave.DisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonSave.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.expUIButtonSave.ForeColor = System.Drawing.Color.White;
            this.expUIButtonSave.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.expUIButtonSave.Image = ((System.Drawing.Image)(resources.GetObject("expUIButtonSave.Image")));
            this.expUIButtonSave.Location = new System.Drawing.Point(0, 215);
            this.expUIButtonSave.Name = "expUIButtonSave";
            this.expUIButtonSave.Remember = false;
            this.expUIButtonSave.ResponsiveFontOn = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.expUIButtonSave.ResponsiveText = true;
            this.expUIButtonSave.Size = new System.Drawing.Size(150, 35);
            this.expUIButtonSave.StyleButton = ExpUI.dll.ExpUIButton.styleButton.Standart;
            this.expUIButtonSave.TabIndex = 4;
            this.expUIButtonSave.Text = "Сохранить";
            this.expUIButtonSave.TextAlign = ExpUI.dll.ExpUIButton.textAlign.MiddleRight;
            this.expUIButtonSave.Click += new System.EventHandler(this.ExpUIButtonSave_Click);
            // 
            // expUIButtonExport
            // 
            this.expUIButtonExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(116)))), ((int)(((byte)(228)))));
            this.expUIButtonExport.BorderSize = 1;
            this.expUIButtonExport.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonExport.ColorTextForBorder = System.Drawing.Color.White;
            this.expUIButtonExport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.expUIButtonExport.DisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonExport.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.expUIButtonExport.ForeColor = System.Drawing.Color.White;
            this.expUIButtonExport.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.expUIButtonExport.Image = ((System.Drawing.Image)(resources.GetObject("expUIButtonExport.Image")));
            this.expUIButtonExport.Location = new System.Drawing.Point(0, 260);
            this.expUIButtonExport.Name = "expUIButtonExport";
            this.expUIButtonExport.Remember = false;
            this.expUIButtonExport.ResponsiveFontOn = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.expUIButtonExport.ResponsiveText = true;
            this.expUIButtonExport.Size = new System.Drawing.Size(150, 35);
            this.expUIButtonExport.StyleButton = ExpUI.dll.ExpUIButton.styleButton.Standart;
            this.expUIButtonExport.TabIndex = 5;
            this.expUIButtonExport.Text = "Экспорт";
            this.expUIButtonExport.TextAlign = ExpUI.dll.ExpUIButton.textAlign.MiddleRight;
            this.expUIButtonExport.Click += new System.EventHandler(this.ExpUIButtonExport_Click);
            // 
            // expUIButtonDelete
            // 
            this.expUIButtonDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(116)))), ((int)(((byte)(228)))));
            this.expUIButtonDelete.BorderSize = 1;
            this.expUIButtonDelete.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonDelete.ColorTextForBorder = System.Drawing.Color.White;
            this.expUIButtonDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.expUIButtonDelete.DisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.expUIButtonDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.expUIButtonDelete.ForeColor = System.Drawing.Color.White;
            this.expUIButtonDelete.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.expUIButtonDelete.Image = ((System.Drawing.Image)(resources.GetObject("expUIButtonDelete.Image")));
            this.expUIButtonDelete.Location = new System.Drawing.Point(0, 305);
            this.expUIButtonDelete.Name = "expUIButtonDelete";
            this.expUIButtonDelete.Remember = false;
            this.expUIButtonDelete.ResponsiveFontOn = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.expUIButtonDelete.ResponsiveText = true;
            this.expUIButtonDelete.Size = new System.Drawing.Size(150, 35);
            this.expUIButtonDelete.StyleButton = ExpUI.dll.ExpUIButton.styleButton.Standart;
            this.expUIButtonDelete.TabIndex = 6;
            this.expUIButtonDelete.Text = "Удалить";
            this.expUIButtonDelete.TextAlign = ExpUI.dll.ExpUIButton.textAlign.MiddleRight;
            this.expUIButtonDelete.Click += new System.EventHandler(this.ExpUIButtonDelete_Click);
            // 
            // panelTitle
            // 
            this.panelTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(116)))), ((int)(((byte)(228)))));
            this.panelTitle.Controls.Add(this.buttonExit);
            this.panelTitle.Controls.Add(this.labelTitle);
            this.panelTitle.Location = new System.Drawing.Point(150, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(798, 20);
            this.panelTitle.TabIndex = 2;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(116)))), ((int)(((byte)(228)))));
            this.buttonExit.BorderColor = System.Drawing.Color.Black;
            this.buttonExit.BorderSize = 1;
            this.buttonExit.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonExit.HoverColor = System.Drawing.Color.Red;
            this.buttonExit.Image = ((System.Drawing.Image)(resources.GetObject("buttonExit.Image")));
            this.buttonExit.Location = new System.Drawing.Point(778, 0);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Remember = false;
            this.buttonExit.RememberColor = System.Drawing.Color.White;
            this.buttonExit.ShowBorder = false;
            this.buttonExit.Size = new System.Drawing.Size(20, 20);
            this.buttonExit.StyleButton = ExpUI.dll.ExpUIButtonIcon.styleButton.Standart;
            this.buttonExit.TabIndex = 46;
            this.buttonExit.Text = "expUIButtonIcon1";
            this.buttonExit.Click += new System.EventHandler(this.ButtonExit_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(0, 0);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(778, 20);
            this.labelTitle.TabIndex = 45;
            this.labelTitle.Text = "Журнал серверной";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormControl);
            // 
            // panelFilter
            // 
            this.panelFilter.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelFilter.Controls.Add(this.labelPeriod);
            this.panelFilter.Controls.Add(this.comboBoxPeriod);
            this.panelFilter.Controls.Add(this.labelSearch);
            this.panelFilter.Controls.Add(this.textBoxSearch);
            this.panelFilter.Controls.Add(this.checkBoxOpenOnly);
            this.panelFilter.Location = new System.Drawing.Point(150, 20);
            this.panelFilter.Name = "panelFilter";
            this.panelFilter.Size = new System.Drawing.Size(798, 32);
            this.panelFilter.TabIndex = 3;
            // 
            // labelPeriod
            // 
            this.labelPeriod.AutoSize = true;
            this.labelPeriod.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPeriod.Location = new System.Drawing.Point(10, 9);
            this.labelPeriod.Name = "labelPeriod";
            this.labelPeriod.Size = new System.Drawing.Size(55, 15);
            this.labelPeriod.TabIndex = 0;
            this.labelPeriod.Text = "Период:";
            // 
            // comboBoxPeriod
            // 
            this.comboBoxPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPeriod.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxPeriod.FormattingEnabled = true;
            this.comboBoxPeriod.Location = new System.Drawing.Point(70, 5);
            this.comboBoxPeriod.Name = "comboBoxPeriod";
            this.comboBoxPeriod.Size = new System.Drawing.Size(130, 23);
            this.comboBoxPeriod.TabIndex = 1;
            this.comboBoxPeriod.SelectedIndexChanged += new System.EventHandler(this.Filter_Changed);
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSearch.Location = new System.Drawing.Point(220, 9);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(48, 15);
            this.labelSearch.TabIndex = 2;
            this.labelSearch.Text = "Поиск:";
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSearch.Location = new System.Drawing.Point(274, 5);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(250, 22);
            this.textBoxSearch.TabIndex = 3;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.Filter_Changed);
            // 
            // checkBoxOpenOnly
            // 
            this.checkBoxOpenOnly.AutoSize = true;
            this.checkBoxOpenOnly.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxOpenOnly.Location = new System.Drawing.Point(545, 7);
            this.checkBoxOpenOnly.Name = "checkBoxOpenOnly";
            this.checkBoxOpenOnly.Size = new System.Drawing.Size(163, 19);
            this.checkBoxOpenOnly.TabIndex = 4;
            this.checkBoxOpenOnly.Text = "Только кто внутри";
            this.checkBoxOpenOnly.UseVisualStyleBackColor = true;
            this.checkBoxOpenOnly.CheckedChanged += new System.EventHandler(this.Filter_Changed);
            // 
            // dataGridViewVisits
            // 
            this.dataGridViewVisits.AllowUserToAddRows = false;
            this.dataGridViewVisits.AllowUserToDeleteRows = false;
            this.dataGridViewVisits.AllowUserToResizeColumns = false;
            this.dataGridViewVisits.AllowUserToResizeRows = false;
            this.dataGridViewVisits.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVisits.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewVisits.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVisits.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewVisits.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnId,
            this.ColumnVisitor,
            this.ColumnEnter,
            this.ColumnExit,
            this.ColumnDuration,
            this.ColumnReason,
            this.ColumnActions,
            this.ColumnState});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVisits.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewVisits.Location = new System.Drawing.Point(150, 52);
            this.dataGridViewVisits.MultiSelect = false;
            this.dataGridViewVisits.Name = "dataGridViewVisits";
            this.dataGridViewVisits.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewVisits.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewVisits.RowHeadersVisible = false;
            this.dataGridViewVisits.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVisits.Size = new System.Drawing.Size(798, 298);
            this.dataGridViewVisits.TabIndex = 4;
            this.dataGridViewVisits.SelectionChanged += new System.EventHandler(this.DataGridViewVisits_SelectionChanged);
            // 
            // ColumnId
            // 
            this.ColumnId.FillWeight = 10F;
            this.ColumnId.HeaderText = "ID";
            this.ColumnId.Name = "ColumnId";
            this.ColumnId.ReadOnly = true;
            this.ColumnId.Visible = false;
            // 
            // ColumnVisitor
            // 
            this.ColumnVisitor.FillWeight = 16F;
            this.ColumnVisitor.HeaderText = "Кто";
            this.ColumnVisitor.Name = "ColumnVisitor";
            this.ColumnVisitor.ReadOnly = true;
            // 
            // ColumnEnter
            // 
            this.ColumnEnter.FillWeight = 13F;
            this.ColumnEnter.HeaderText = "Вошёл";
            this.ColumnEnter.Name = "ColumnEnter";
            this.ColumnEnter.ReadOnly = true;
            // 
            // ColumnExit
            // 
            this.ColumnExit.FillWeight = 13F;
            this.ColumnExit.HeaderText = "Вышел";
            this.ColumnExit.Name = "ColumnExit";
            this.ColumnExit.ReadOnly = true;
            // 
            // ColumnDuration
            // 
            this.ColumnDuration.FillWeight = 11F;
            this.ColumnDuration.HeaderText = "Длительность";
            this.ColumnDuration.Name = "ColumnDuration";
            this.ColumnDuration.ReadOnly = true;
            // 
            // ColumnReason
            // 
            this.ColumnReason.FillWeight = 22F;
            this.ColumnReason.HeaderText = "Зачем";
            this.ColumnReason.Name = "ColumnReason";
            this.ColumnReason.ReadOnly = true;
            // 
            // ColumnActions
            // 
            this.ColumnActions.FillWeight = 28F;
            this.ColumnActions.HeaderText = "Что делал";
            this.ColumnActions.Name = "ColumnActions";
            this.ColumnActions.ReadOnly = true;
            // 
            // ColumnState
            // 
            this.ColumnState.FillWeight = 13F;
            this.ColumnState.HeaderText = "Статус";
            this.ColumnState.Name = "ColumnState";
            this.ColumnState.ReadOnly = true;
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.Color.White;
            this.panelBottom.Controls.Add(this.groupBoxNew);
            this.panelBottom.Controls.Add(this.groupBoxEdit);
            this.panelBottom.Controls.Add(this.labelInside);
            this.panelBottom.Controls.Add(this.checkBoxTelegram);
            this.panelBottom.Location = new System.Drawing.Point(150, 350);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(798, 208);
            this.panelBottom.TabIndex = 5;
            // 
            // groupBoxNew
            // 
            this.groupBoxNew.Controls.Add(this.labelVisitor);
            this.groupBoxNew.Controls.Add(this.comboBoxVisitor);
            this.groupBoxNew.Controls.Add(this.labelReason);
            this.groupBoxNew.Controls.Add(this.comboBoxReason);
            this.groupBoxNew.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxNew.Location = new System.Drawing.Point(6, 2);
            this.groupBoxNew.Name = "groupBoxNew";
            this.groupBoxNew.Size = new System.Drawing.Size(786, 62);
            this.groupBoxNew.TabIndex = 0;
            this.groupBoxNew.TabStop = false;
            this.groupBoxNew.Text = "Новый визит (всё подставляется само, можно просто нажать «Вошёл»)";
            // 
            // labelVisitor
            // 
            this.labelVisitor.AutoSize = true;
            this.labelVisitor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelVisitor.Location = new System.Drawing.Point(10, 31);
            this.labelVisitor.Name = "labelVisitor";
            this.labelVisitor.Size = new System.Drawing.Size(36, 15);
            this.labelVisitor.TabIndex = 0;
            this.labelVisitor.Text = "Кто:";
            // 
            // comboBoxVisitor
            // 
            this.comboBoxVisitor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBoxVisitor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxVisitor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxVisitor.FormattingEnabled = true;
            this.comboBoxVisitor.Location = new System.Drawing.Point(52, 27);
            this.comboBoxVisitor.Name = "comboBoxVisitor";
            this.comboBoxVisitor.Size = new System.Drawing.Size(250, 23);
            this.comboBoxVisitor.TabIndex = 1;
            this.comboBoxVisitor.SelectionChangeCommitted += new System.EventHandler(this.ComboBoxVisitor_Changed);
            this.comboBoxVisitor.Leave += new System.EventHandler(this.ComboBoxVisitor_Changed);
            // 
            // labelReason
            // 
            this.labelReason.AutoSize = true;
            this.labelReason.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelReason.Location = new System.Drawing.Point(316, 31);
            this.labelReason.Name = "labelReason";
            this.labelReason.Size = new System.Drawing.Size(52, 15);
            this.labelReason.TabIndex = 2;
            this.labelReason.Text = "Зачем:";
            // 
            // comboBoxReason
            // 
            this.comboBoxReason.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxReason.FormattingEnabled = true;
            this.comboBoxReason.Location = new System.Drawing.Point(374, 27);
            this.comboBoxReason.Name = "comboBoxReason";
            this.comboBoxReason.Size = new System.Drawing.Size(402, 23);
            this.comboBoxReason.TabIndex = 3;
            // 
            // groupBoxEdit
            // 
            this.groupBoxEdit.Controls.Add(this.labelEditReason);
            this.groupBoxEdit.Controls.Add(this.textBoxEditReason);
            this.groupBoxEdit.Controls.Add(this.labelEditActions);
            this.groupBoxEdit.Controls.Add(this.textBoxEditActions);
            this.groupBoxEdit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxEdit.Location = new System.Drawing.Point(6, 66);
            this.groupBoxEdit.Name = "groupBoxEdit";
            this.groupBoxEdit.Size = new System.Drawing.Size(786, 112);
            this.groupBoxEdit.TabIndex = 1;
            this.groupBoxEdit.TabStop = false;
            this.groupBoxEdit.Text = "Выбранная запись";
            // 
            // labelEditReason
            // 
            this.labelEditReason.AutoSize = true;
            this.labelEditReason.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEditReason.Location = new System.Drawing.Point(10, 24);
            this.labelEditReason.Name = "labelEditReason";
            this.labelEditReason.Size = new System.Drawing.Size(52, 15);
            this.labelEditReason.TabIndex = 0;
            this.labelEditReason.Text = "Зачем:";
            // 
            // textBoxEditReason
            // 
            this.textBoxEditReason.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxEditReason.Location = new System.Drawing.Point(82, 20);
            this.textBoxEditReason.Name = "textBoxEditReason";
            this.textBoxEditReason.Size = new System.Drawing.Size(694, 22);
            this.textBoxEditReason.TabIndex = 1;
            // 
            // labelEditActions
            // 
            this.labelEditActions.AutoSize = true;
            this.labelEditActions.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEditActions.Location = new System.Drawing.Point(10, 52);
            this.labelEditActions.Name = "labelEditActions";
            this.labelEditActions.Size = new System.Drawing.Size(70, 15);
            this.labelEditActions.TabIndex = 2;
            this.labelEditActions.Text = "Что делал:";
            // 
            // textBoxEditActions
            // 
            this.textBoxEditActions.AcceptsReturn = true;
            this.textBoxEditActions.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxEditActions.Location = new System.Drawing.Point(82, 48);
            this.textBoxEditActions.Multiline = true;
            this.textBoxEditActions.Name = "textBoxEditActions";
            this.textBoxEditActions.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxEditActions.Size = new System.Drawing.Size(694, 56);
            this.textBoxEditActions.TabIndex = 3;
            // 
            // labelInside
            // 
            this.labelInside.AutoEllipsis = true;
            this.labelInside.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelInside.Location = new System.Drawing.Point(10, 184);
            this.labelInside.Name = "labelInside";
            this.labelInside.Size = new System.Drawing.Size(580, 18);
            this.labelInside.TabIndex = 2;
            this.labelInside.Text = "В серверной сейчас: никого";
            // 
            // checkBoxTelegram
            // 
            this.checkBoxTelegram.AutoSize = true;
            this.checkBoxTelegram.Checked = true;
            this.checkBoxTelegram.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxTelegram.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxTelegram.Location = new System.Drawing.Point(600, 183);
            this.checkBoxTelegram.Name = "checkBoxTelegram";
            this.checkBoxTelegram.Size = new System.Drawing.Size(188, 19);
            this.checkBoxTelegram.TabIndex = 3;
            this.checkBoxTelegram.Text = "Уведомлять в Telegram";
            this.checkBoxTelegram.UseVisualStyleBackColor = true;
            // 
            // ServerRoomForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(948, 558);
            this.ControlBox = false;
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.dataGridViewVisits);
            this.Controls.Add(this.panelFilter);
            this.Controls.Add(this.panelTitle);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(950, 560);
            this.MinimumSize = new System.Drawing.Size(950, 560);
            this.Name = "ServerRoomForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Журнал серверной";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ServerRoomForm_FormClosed);
            this.Load += new System.EventHandler(this.ServerRoomForm_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelTitle.ResumeLayout(false);
            this.panelFilter.ResumeLayout(false);
            this.panelFilter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisits)).EndInit();
            this.panelBottom.ResumeLayout(false);
            this.panelBottom.PerformLayout();
            this.groupBoxNew.ResumeLayout(false);
            this.groupBoxNew.PerformLayout();
            this.groupBoxEdit.ResumeLayout(false);
            this.groupBoxEdit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private ExpUI.dll.ExpUIButton expUIButtonEnter;
        private ExpUI.dll.ExpUIButton expUIButtonLeave;
        private ExpUI.dll.ExpUIButton expUIButtonRefresh;
        private ExpUI.dll.ExpUIButton expUIButtonSave;
        private ExpUI.dll.ExpUIButton expUIButtonExport;
        private ExpUI.dll.ExpUIButton expUIButtonDelete;
        private System.Windows.Forms.Panel panelTitle;
        private ExpUI.dll.ExpUIButtonIcon buttonExit;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panelFilter;
        private System.Windows.Forms.Label labelPeriod;
        private System.Windows.Forms.ComboBox comboBoxPeriod;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.CheckBox checkBoxOpenOnly;
        private System.Windows.Forms.DataGridView dataGridViewVisits;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnVisitor;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnEnter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDuration;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReason;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnActions;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnState;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.GroupBox groupBoxNew;
        private System.Windows.Forms.Label labelVisitor;
        private System.Windows.Forms.ComboBox comboBoxVisitor;
        private System.Windows.Forms.Label labelReason;
        private System.Windows.Forms.ComboBox comboBoxReason;
        private System.Windows.Forms.GroupBox groupBoxEdit;
        private System.Windows.Forms.Label labelEditReason;
        private System.Windows.Forms.TextBox textBoxEditReason;
        private System.Windows.Forms.Label labelEditActions;
        private System.Windows.Forms.TextBox textBoxEditActions;
        private System.Windows.Forms.Label labelInside;
        private System.Windows.Forms.CheckBox checkBoxTelegram;
    }
}
