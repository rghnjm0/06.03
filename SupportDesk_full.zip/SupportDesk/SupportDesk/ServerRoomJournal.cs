﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace SupportDesk
{
    /// <summary>
    /// Заявка исполнителя в работе. По ней журнал сам определяет, зачем человек пошёл в серверную.
    /// </summary>
    internal sealed class ServerRoomTicket
    {
        public int Id { get; set; }
        public string Tema { get; set; }
        public string Kabinet { get; set; }
        public string Status { get; set; }
        public string Result { get; set; }

        public string Caption
        {
            get
            {
                string cab = string.IsNullOrWhiteSpace(Kabinet) ? "" : $", каб. {Kabinet}";
                return $"Заявка №{Id}: {Tema}{cab}";
            }
        }
    }

    /// <summary>
    /// Одна запись журнала: один визит в серверную.
    /// </summary>
    internal sealed class ServerRoomVisit
    {
        public int Id { get; set; }
        public string Visitor { get; set; }
        public DateTime Enter { get; set; }
        public DateTime? Exit { get; set; }
        public string Reason { get; set; }
        public string Actions { get; set; }
        public int? RequestId { get; set; }
        public string RegisteredBy { get; set; }

        public bool IsOpen => !Exit.HasValue;
        public bool IsStale(DateTime now) => IsOpen && (now - Enter).TotalHours >= ServerRoomJournal.StaleHours;
    }

    /// <summary>
    /// Логика журнала посещений серверной: хранение, автозаполнение причины и выполненных действий.
    /// </summary>
    internal static class ServerRoomJournal
    {
        /// <summary>Формат хранения даты в БД (сортируется как строка).</summary>
        public const string DbDateFormat = "yyyy-MM-dd HH:mm:ss";
        /// <summary>Сколько часов визит может быть открыт, прежде чем он считается «выход не отмечен».</summary>
        public const int StaleHours = 12;
        /// <summary>Название раздела в logs.txt.</summary>
        public const string LogSection = "Серверная";

        /// <summary>Готовые причины визита (первая подставляется, если причину определить не удалось).</summary>
        public static readonly string[] ReasonTemplates =
        {
            "Плановый осмотр и обслуживание",
            "Замена или установка оборудования",
            "Настройка сети и коммутации",
            "Резервное копирование",
            "Обслуживание ИБП, кондиционера, питания",
            "Прокладка и проверка кабелей",
            "Проверка / сопровождение посторонних лиц",
            "Устранение аварии"
        };

        /// <summary>
        /// Разделы logs.txt, действия из которых попадают в «что делал».
        /// Список разрешённых, а не запрещённых: в логе встречаются пароли и персональные данные.
        /// </summary>
        private static readonly string[] ActionLogSections =
        {
            "Задача", "Создание задачи", "Редактирование заявки", "Исполнитель",
            "Инвентаризация", "Оборудование", "Картриджи", "Принтер", "Лицензии", "Лицензия"
        };

        private static readonly Regex LogLine = new Regex(
            @"^\[(?<section>[^\]]+)\]\s*(?<text>.*?)\s*\((?<date>\d{2}\.\d{2}\.\d{4} \d{2}:\d{2})\)\s*$",
            RegexOptions.Compiled);

        #region База данных
        public static void EnsureTable(SQLiteConnection db)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"CREATE TABLE IF NOT EXISTS [{Table_serverRoom.main}] (" +
                $"[{Table_serverRoom.id}] INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
                $"[{Table_serverRoom.visitor}] TEXT NOT NULL, " +
                $"[{Table_serverRoom.enterTime}] TEXT NOT NULL, " +
                $"[{Table_serverRoom.exitTime}] TEXT, " +
                $"[{Table_serverRoom.reason}] TEXT, " +
                $"[{Table_serverRoom.actions}] TEXT, " +
                $"[{Table_serverRoom.requestId}] INTEGER, " +
                $"[{Table_serverRoom.registeredBy}] TEXT NOT NULL)", db))
            {
                _ = cmd.ExecuteNonQuery();
            }
        }

        public static int Enter(SQLiteConnection db, string visitor, DateTime when, string reason, int? requestId, string registeredBy)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"INSERT INTO [{Table_serverRoom.main}] " +
                $"([{Table_serverRoom.visitor}], [{Table_serverRoom.enterTime}], [{Table_serverRoom.reason}], " +
                $"[{Table_serverRoom.requestId}], [{Table_serverRoom.registeredBy}]) " +
                "VALUES (@visitor, @time, @reason, @request, @by)", db))
            {
                _ = cmd.Parameters.AddWithValue("visitor", visitor);
                _ = cmd.Parameters.AddWithValue("time", when.ToString(DbDateFormat, CultureInfo.InvariantCulture));
                _ = cmd.Parameters.AddWithValue("reason", reason);
                _ = cmd.Parameters.AddWithValue("request", requestId.HasValue ? (object)requestId.Value : DBNull.Value);
                _ = cmd.Parameters.AddWithValue("by", registeredBy ?? "");
                _ = cmd.ExecuteNonQuery();
            }
            using (SQLiteCommand idCmd = new SQLiteCommand("SELECT last_insert_rowid()", db))
            {
                return Convert.ToInt32(idCmd.ExecuteScalar());
            }
        }

        /// <summary>Отмечает выход. Возвращает false, если визит уже был закрыт.</summary>
        public static bool Leave(SQLiteConnection db, int id, DateTime when, string reason, string actions)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"UPDATE [{Table_serverRoom.main}] SET [{Table_serverRoom.exitTime}] = @time, " +
                $"[{Table_serverRoom.reason}] = @reason, [{Table_serverRoom.actions}] = @actions " +
                $"WHERE [{Table_serverRoom.id}] = @id AND [{Table_serverRoom.exitTime}] IS NULL", db))
            {
                _ = cmd.Parameters.AddWithValue("time", when.ToString(DbDateFormat, CultureInfo.InvariantCulture));
                _ = cmd.Parameters.AddWithValue("reason", reason ?? "");
                _ = cmd.Parameters.AddWithValue("actions", actions ?? "");
                _ = cmd.Parameters.AddWithValue("id", id);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public static void UpdateText(SQLiteConnection db, int id, string reason, string actions)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"UPDATE [{Table_serverRoom.main}] SET [{Table_serverRoom.reason}] = @reason, " +
                $"[{Table_serverRoom.actions}] = @actions WHERE [{Table_serverRoom.id}] = @id", db))
            {
                _ = cmd.Parameters.AddWithValue("reason", reason ?? "");
                _ = cmd.Parameters.AddWithValue("actions", actions ?? "");
                _ = cmd.Parameters.AddWithValue("id", id);
                _ = cmd.ExecuteNonQuery();
            }
        }

        public static void Delete(SQLiteConnection db, int id)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"DELETE FROM [{Table_serverRoom.main}] WHERE [{Table_serverRoom.id}] = @id", db))
            {
                _ = cmd.Parameters.AddWithValue("id", id);
                _ = cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Визиты за период (и все ещё открытые визиты, даже если они старше периода).</summary>
        public static List<ServerRoomVisit> Load(SQLiteConnection db, DateTime? from)
        {
            string where = from.HasValue
                ? $"WHERE [{Table_serverRoom.enterTime}] >= @from OR [{Table_serverRoom.exitTime}] IS NULL "
                : "";
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"SELECT * FROM [{Table_serverRoom.main}] {where}ORDER BY [{Table_serverRoom.id}] DESC", db))
            {
                if (from.HasValue)
                {
                    _ = cmd.Parameters.AddWithValue("from", from.Value.ToString(DbDateFormat, CultureInfo.InvariantCulture));
                }
                return ReadVisits(cmd);
            }
        }

        public static ServerRoomVisit FindOpenVisit(SQLiteConnection db, string visitor)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"SELECT * FROM [{Table_serverRoom.main}] WHERE [{Table_serverRoom.visitor}] = @visitor " +
                $"AND [{Table_serverRoom.exitTime}] IS NULL ORDER BY [{Table_serverRoom.id}] DESC LIMIT 1", db))
            {
                _ = cmd.Parameters.AddWithValue("visitor", visitor);
                List<ServerRoomVisit> list = ReadVisits(cmd);
                return list.Count > 0 ? list[0] : null;
            }
        }

        private static List<ServerRoomVisit> ReadVisits(SQLiteCommand cmd)
        {
            List<ServerRoomVisit> list = new List<ServerRoomVisit>();
            using (SQLiteDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    ServerRoomVisit v = new ServerRoomVisit
                    {
                        Id = Convert.ToInt32(r[Table_serverRoom.id]),
                        Visitor = Convert.ToString(r[Table_serverRoom.visitor]),
                        Enter = ParseDate(r[Table_serverRoom.enterTime]) ?? DateTime.MinValue,
                        Exit = ParseDate(r[Table_serverRoom.exitTime]),
                        Reason = Convert.ToString(r[Table_serverRoom.reason]),
                        Actions = Convert.ToString(r[Table_serverRoom.actions]),
                        RegisteredBy = Convert.ToString(r[Table_serverRoom.registeredBy])
                    };
                    object req = r[Table_serverRoom.requestId];
                    if (req != null && req != DBNull.Value)
                    {
                        v.RequestId = Convert.ToInt32(req);
                    }
                    list.Add(v);
                }
            }
            return list;
        }

        private static DateTime? ParseDate(object value)
        {
            if (value == null || value == DBNull.Value)
            {
                return null;
            }
            DateTime parsed;
            return DateTime.TryParseExact(Convert.ToString(value), DbDateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed)
                ? parsed
                : (DateTime?)null;
        }
        #endregion

        #region Автозаполнение
        /// <summary>Сотрудники и внешние контакты, которых можно выбрать в поле «Кто».</summary>
        public static List<string> GetKnownVisitors(SQLiteConnection db)
        {
            List<string> names = new List<string>();
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"SELECT [{Table_users.initials}] FROM [{Table_users.main}] ORDER BY [{Table_users.initials}]", db))
            using (SQLiteDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    string name = Convert.ToString(r[0]);
                    if (!string.IsNullOrWhiteSpace(name) && !names.Contains(name))
                    {
                        names.Add(name);
                    }
                }
            }
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"SELECT [{Table_contacts.name}], [{Table_contacts.company}] FROM [{Table_contacts.main}] ORDER BY [{Table_contacts.company}]", db))
            using (SQLiteDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    string name = Convert.ToString(r[0]);
                    string company = Convert.ToString(r[1]);
                    if (string.IsNullOrWhiteSpace(name))
                    {
                        continue;
                    }
                    string full = string.IsNullOrWhiteSpace(company) ? name : $"{name} ({company})";
                    if (!names.Contains(full))
                    {
                        names.Add(full);
                    }
                }
            }
            return names;
        }

        /// <summary>Заявки сотрудника в статусе «В работе»: именно с ними он, скорее всего, идёт в серверную.</summary>
        public static List<ServerRoomTicket> GetActiveTickets(SQLiteConnection db, string initials)
        {
            List<ServerRoomTicket> list = new List<ServerRoomTicket>();
            if (string.IsNullOrWhiteSpace(initials))
            {
                return list;
            }
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"SELECT [ID], [{Table_requests.tema}], [{Table_requests.kabinet}], [{Table_requests.status}] " +
                $"FROM [{Table_requests.main}] " +
                $"WHERE ([{Table_requests.executor}] = @initials OR [{Table_requests.executor2}] = @initials) " +
                $"AND [{Table_requests.status}] = @status ORDER BY [ID] DESC", db))
            {
                _ = cmd.Parameters.AddWithValue("initials", initials);
                _ = cmd.Parameters.AddWithValue("status", "В работе");
                using (SQLiteDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new ServerRoomTicket
                        {
                            Id = Convert.ToInt32(r[0]),
                            Tema = Convert.ToString(r[1]),
                            Kabinet = Convert.ToString(r[2]),
                            Status = Convert.ToString(r[3])
                        });
                    }
                }
            }
            return list;
        }

        public static ServerRoomTicket GetTicket(SQLiteConnection db, int id)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(
                $"SELECT [ID], [{Table_requests.tema}], [{Table_requests.kabinet}], [{Table_requests.status}], [result] " +
                $"FROM [{Table_requests.main}] WHERE [ID] = @id", db))
            {
                _ = cmd.Parameters.AddWithValue("id", id);
                using (SQLiteDataReader r = cmd.ExecuteReader())
                {
                    if (!r.Read())
                    {
                        return null;
                    }
                    return new ServerRoomTicket
                    {
                        Id = Convert.ToInt32(r[0]),
                        Tema = Convert.ToString(r[1]),
                        Kabinet = Convert.ToString(r[2]),
                        Status = Convert.ToString(r[3]),
                        Result = Convert.ToString(r[4])
                    };
                }
            }
        }

        /// <summary>
        /// Собирает «что делал» без участия человека:
        /// результат заявки, к которой привязан визит, и действия этого сотрудника в программе за время визита.
        /// </summary>
        public static string BuildActions(SQLiteConnection db, string visitor, DateTime enter, DateTime exit, int? requestId)
        {
            List<string> lines = new List<string>();

            if (requestId.HasValue)
            {
                ServerRoomTicket ticket = GetTicket(db, requestId.Value);
                if (ticket != null)
                {
                    string result = Regex.Replace(ticket.Result ?? "", @"\s+", " ").Trim();
                    lines.Add(result.Length > 0
                        ? $"{ticket.Caption} — {result}"
                        : $"{ticket.Caption} (статус заявки: {ticket.Status})");
                }
            }

            List<string> appActions = ReadAppActions(visitor, enter, exit);
            if (appActions.Count > 0)
            {
                lines.Add("Действия в программе за время визита:");
                lines.AddRange(appActions);
            }

            return string.Join(Environment.NewLine, lines);
        }

        private static List<string> ReadAppActions(string visitor, DateTime from, DateTime to)
        {
            List<string> result = new List<string>();
            if (string.IsNullOrWhiteSpace(visitor) || !File.Exists(Logs.file))
            {
                return result;
            }
            // В логе время хранится с точностью до минуты.
            DateTime start = new DateTime(from.Year, from.Month, from.Day, from.Hour, from.Minute, 0);
            try
            {
                using (FileStream fs = new FileStream(Logs.file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (StreamReader sr = new StreamReader(fs, Encoding.UTF8))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        Match m = LogLine.Match(line);
                        if (!m.Success)
                        {
                            continue;
                        }
                        string section = m.Groups["section"].Value.Trim();
                        if (Array.IndexOf(ActionLogSections, section) < 0)
                        {
                            continue;
                        }
                        string text = m.Groups["text"].Value;
                        if (text.IndexOf(visitor, StringComparison.OrdinalIgnoreCase) < 0)
                        {
                            continue;
                        }
                        DateTime when;
                        if (!DateTime.TryParseExact(m.Groups["date"].Value, "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out when))
                        {
                            continue;
                        }
                        if (when < start || when > to)
                        {
                            continue;
                        }
                        string item = $"[{section}] {text}";
                        if (!result.Contains(item))
                        {
                            result.Add(item);
                        }
                        if (result.Count >= 20)
                        {
                            break;
                        }
                    }
                }
            }
            catch (IOException)
            {
                // Лог занят или недоступен: журнал работает и без него.
            }
            catch (UnauthorizedAccessException)
            {
            }
            return result;
        }
        #endregion

        #region Форматирование
        public static string FormatDuration(TimeSpan span)
        {
            if (span < TimeSpan.Zero)
            {
                span = TimeSpan.Zero;
            }
            int hours = (int)span.TotalHours;
            return hours > 0 ? $"{hours} ч {span.Minutes:00} мин" : $"{span.Minutes} мин";
        }

        public static string StateText(ServerRoomVisit visit, DateTime now)
        {
            if (!visit.IsOpen)
            {
                return "Завершён";
            }
            return visit.IsStale(now) ? "Выход не отмечен" : "В серверной";
        }
        #endregion
    }
}
