from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from .extensions import db


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    bio = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # simple brute-force protection
    failed_logins = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)

    memberships = db.relationship('ChannelMember', back_populates='user', cascade='all, delete-orphan')
    messages = db.relationship('Message', back_populates='author', lazy='dynamic')

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def to_public_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'bio': self.bio or '',
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }


class Channel(db.Model):
    __tablename__ = 'channels'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, default='')
    is_public = db.Column(db.Boolean, default=True, nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    members = db.relationship('ChannelMember', back_populates='channel', cascade='all, delete-orphan')
    messages = db.relationship('Message', back_populates='channel', lazy='dynamic',
                               foreign_keys='Message.channel_id')

    def to_dict(self, member_count=None):
        d = {
            'id': self.id,
            'name': self.name,
            'description': self.description or '',
            'is_public': self.is_public,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }
        if member_count is not None:
            d['member_count'] = member_count
        return d


class ChannelMember(db.Model):
    __tablename__ = 'channel_members'

    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.Integer, db.ForeignKey('channels.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint('channel_id', 'user_id', name='uq_channel_user'),)

    channel = db.relationship('Channel', back_populates='members')
    user = db.relationship('User', back_populates='memberships')


class PrivateChat(db.Model):
    """1-to-1 private chat. user1_id < user2_id for uniqueness."""
    __tablename__ = 'private_chats'

    id = db.Column(db.Integer, primary_key=True)
    user1_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user2_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint('user1_id', 'user2_id', name='uq_private_pair'),)

    messages = db.relationship('Message', back_populates='private_chat', lazy='dynamic',
                               foreign_keys='Message.private_chat_id')

    def other_user_id(self, me_id: int) -> int:
        return self.user2_id if self.user1_id == me_id else self.user1_id

    def to_dict(self, me_id: int = None):
        d = {
            'id': self.id,
            'user1_id': self.user1_id,
            'user2_id': self.user2_id,
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }
        if me_id is not None:
            d['other_user_id'] = self.other_user_id(me_id)
        return d


class Message(db.Model):
    __tablename__ = 'messages'

    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.Text, nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    channel_id = db.Column(db.Integer, db.ForeignKey('channels.id'), nullable=True)
    private_chat_id = db.Column(db.Integer, db.ForeignKey('private_chats.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    author = db.relationship('User', back_populates='messages')
    channel = db.relationship('Channel', back_populates='messages', foreign_keys=[channel_id])
    private_chat = db.relationship('PrivateChat', back_populates='messages', foreign_keys=[private_chat_id])

    def to_dict(self):
        return {
            'id': self.id,
            'text': self.body,
            'author_id': self.author_id,
            'author': self.author.username if self.author else None,
            'channel_id': self.channel_id,
            'chat_id': self.private_chat_id,
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }
