from flask import Blueprint, render_template, abort, session
from .models import User, Channel, ChannelMember, Message, PrivateChat
from .extensions import db

bp = Blueprint('main', __name__)


@bp.get('/')
def index():
    return render_template('index.html')


@bp.get('/u/<username>')
def public_profile(username):
    """Public profile page — bio is auto-escaped by Jinja (XSS protection)."""
    user = User.query.filter_by(username=username).first()
    if not user:
        abort(404)
    # channels the user is member of (public ones)
    memberships = ChannelMember.query.filter_by(user_id=user.id).all()
    channels = []
    for m in memberships:
        ch = db.session.get(Channel, m.channel_id)
        if ch and ch.is_public:
            channels.append(ch)
    return render_template('profile.html', profile_user=user, channels=channels)


@bp.get('/chats/<int:chat_id>')
def chat_page(chat_id):
    """Simple HTML view of a private chat — messages escaped by Jinja."""
    user_id = session.get('user_id')
    if not user_id:
        abort(401)
    chat = db.session.get(PrivateChat, chat_id)
    if not chat:
        abort(404)
    if user_id not in (chat.user1_id, chat.user2_id):
        abort(403)
    msgs = (Message.query
            .filter_by(private_chat_id=chat.id)
            .order_by(Message.created_at.asc())
            .limit(200).all())
    return render_template('chat.html', chat=chat, messages=msgs)


@bp.get('/channels/<int:channel_id>')
def channel_page(channel_id):
    """Simple HTML view of a channel — messages escaped by Jinja."""
    user_id = session.get('user_id')
    if not user_id:
        abort(401)
    ch = db.session.get(Channel, channel_id)
    if not ch:
        abort(404)
    msgs = (Message.query
            .filter_by(channel_id=ch.id)
            .order_by(Message.created_at.asc())
            .limit(200).all())
    return render_template('channel.html', channel=ch, messages=msgs)
