from datetime import datetime, timedelta
import time

from flask import (
    Blueprint, render_template, request, redirect, url_for,
    session, flash, make_response
)
from .models import User
from .extensions import db

bp = Blueprint('auth', __name__)

# In-memory per-IP counter (process lifetime)
_ip_attempts = {}  # ip -> (count, window_start)
MAX_IP_ATTEMPTS = 20
IP_WINDOW_SEC = 60
LOCKOUT_AFTER = 5
LOCKOUT_MINUTES = 5


def _client_ip():
    return request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()


def _check_ip_rate():
    ip = _client_ip()
    now = time.time()
    count, start = _ip_attempts.get(ip, (0, now))
    if now - start > IP_WINDOW_SEC:
        count, start = 0, now
    count += 1
    _ip_attempts[ip] = (count, start)
    return count <= MAX_IP_ATTEMPTS


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if not username or not password:
            flash('Заполните все поля')
        elif len(username) < 3 or len(username) > 80:
            flash('Имя пользователя: 3–80 символов')
        elif len(password) < 6:
            flash('Пароль минимум 6 символов')
        elif User.query.filter_by(username=username).first():
            flash('Пользователь уже существует')
        else:
            user = User(username=username)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            return redirect(url_for('auth.login'))
    return render_template('auth/register.html')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if not _check_ip_rate():
            flash('Слишком много попыток. Подождите.')
            resp = make_response(render_template('auth/login.html'), 429)
            resp.headers['Retry-After'] = '60'
            return resp

        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()

        # slow down brute-force (avg response > 300ms)
        time.sleep(0.35)

        if user and user.locked_until and user.locked_until > datetime.utcnow():
            flash('Аккаунт временно заблокирован')
            resp = make_response(render_template('auth/login.html'), 429)
            resp.headers['Retry-After'] = '300'
            return resp

        if user and user.check_password(password):
            user.failed_logins = 0
            user.locked_until = None
            db.session.commit()
            session['user_id'] = user.id
            session.permanent = True
            return redirect(url_for('main.index'))

        if user:
            user.failed_logins = (user.failed_logins or 0) + 1
            if user.failed_logins >= LOCKOUT_AFTER:
                user.locked_until = datetime.utcnow() + timedelta(minutes=LOCKOUT_MINUTES)
                user.failed_logins = 0
            db.session.commit()
        flash('Неверные данные')
    return render_template('auth/login.html')


@bp.get('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('main.index'))
