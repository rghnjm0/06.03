from functools import wraps
from io import StringIO

from flask import (
    Blueprint, jsonify, request, session, current_app,
    Response, make_response
)
from sqlalchemy import or_
from sqlalchemy.exc import IntegrityError

from .extensions import db
from .models import User, Channel, ChannelMember, PrivateChat, Message

bp = Blueprint('api', __name__)

ALLOWED_EXPORT_FORMATS = {'txt', 'json'}


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'authentication required'}), 401
        user = db.session.get(User, user_id)
        if not user:
            session.pop('user_id', None)
            return jsonify({'error': 'authentication required'}), 401
        return f(user, *args, **kwargs)
    return decorated


def _err(msg, code=400):
    return jsonify({'error': msg}), code


def _user_in_chat(user, chat: PrivateChat) -> bool:
    return user.id in (chat.user1_id, chat.user2_id)


def _user_in_channel(user, channel: Channel) -> bool:
    return ChannelMember.query.filter_by(
        channel_id=channel.id, user_id=user.id
    ).first() is not None


# ---------------------------------------------------------------------------
# 0. Health
# ---------------------------------------------------------------------------
@bp.get('/health')
def health():
    return jsonify({
        'status': 'ok',
        'team_id': current_app.config['TEAM_ID'],
        'team_name': current_app.config['TEAM_NAME'],
    })


# ---------------------------------------------------------------------------
# 2. Public channels
# ---------------------------------------------------------------------------
@bp.get('/channels')
@login_required
def list_channels(user):
    channels = Channel.query.filter_by(is_public=True).order_by(Channel.name).all()
    result = []
    for ch in channels:
        cnt = ChannelMember.query.filter_by(channel_id=ch.id).count()
        result.append(ch.to_dict(member_count=cnt))
    return jsonify({'channels': result})


@bp.post('/channels')
@login_required
def create_channel(user):
    data = request.get_json(silent=True) or {}
    name = (data.get('name') or '').strip()
    description = (data.get('description') or '').strip()
    if not name or len(name) > 120:
        return _err('name required, max 120 chars')
    if len(description) > 1000:
        return _err('description too long')
    ch = Channel(name=name, description=description, is_public=True, created_by=user.id)
    try:
        db.session.add(ch)
        db.session.flush()
        db.session.add(ChannelMember(channel_id=ch.id, user_id=user.id))
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return _err('channel name already exists', 409)
    return jsonify(ch.to_dict(member_count=1)), 201


@bp.post('/channels/<int:channel_id>/join')
@login_required
def join_channel(user, channel_id):
    ch = db.session.get(Channel, channel_id)
    if not ch or not ch.is_public:
        return _err('channel not found', 404)
    if ChannelMember.query.filter_by(channel_id=ch.id, user_id=user.id).first():
        return jsonify({'status': 'already_member', 'channel': ch.to_dict()})
    db.session.add(ChannelMember(channel_id=ch.id, user_id=user.id))
    db.session.commit()
    return jsonify({'status': 'joined', 'channel': ch.to_dict()}), 201


@bp.get('/channels/<int:channel_id>/messages')
@login_required
def channel_messages(user, channel_id):
    """Any authenticated user may read public channel messages (per TZ)."""
    ch = db.session.get(Channel, channel_id)
    if not ch:
        return _err('channel not found', 404)
    limit = min(int(request.args.get('limit', 50) or 50), 200)
    offset = max(int(request.args.get('offset', 0) or 0), 0)
    msgs = (Message.query
            .filter_by(channel_id=ch.id)
            .order_by(Message.created_at.desc())
            .offset(offset).limit(limit).all())
    return jsonify({'messages': [m.to_dict() for m in reversed(msgs)]})


# ---------------------------------------------------------------------------
# 3. Private chats
# ---------------------------------------------------------------------------
@bp.get('/chats')
@login_required
def list_chats(user):
    chats = (PrivateChat.query
             .filter(or_(PrivateChat.user1_id == user.id,
                         PrivateChat.user2_id == user.id))
             .order_by(PrivateChat.created_at.desc()).all())
    return jsonify({'chats': [c.to_dict(me_id=user.id) for c in chats]})


@bp.post('/chats')
@login_required
def create_chat(user):
    data = request.get_json(silent=True) or {}
    other_username = (data.get('username') or '').strip()
    if not other_username:
        return _err('username required')
    other = User.query.filter_by(username=other_username).first()
    if not other:
        return _err('user not found', 404)
    if other.id == user.id:
        return _err('cannot chat with yourself')
    u1, u2 = sorted([user.id, other.id])
    existing = PrivateChat.query.filter_by(user1_id=u1, user2_id=u2).first()
    if existing:
        return jsonify(existing.to_dict(me_id=user.id))
    chat = PrivateChat(user1_id=u1, user2_id=u2)
    db.session.add(chat)
    db.session.commit()
    return jsonify(chat.to_dict(me_id=user.id)), 201


@bp.get('/chats/<int:chat_id>/messages')
@login_required
def chat_messages(user, chat_id):
    """IDOR protection: only participants."""
    chat = db.session.get(PrivateChat, chat_id)
    if not chat:
        return _err('chat not found', 404)
    if not _user_in_chat(user, chat):
        return _err('access denied', 403)
    limit = min(int(request.args.get('limit', 50) or 50), 200)
    offset = max(int(request.args.get('offset', 0) or 0), 0)
    msgs = (Message.query
            .filter_by(private_chat_id=chat.id)
            .order_by(Message.created_at.desc())
            .offset(offset).limit(limit).all())
    return jsonify({'messages': [m.to_dict() for m in reversed(msgs)]})


# ---------------------------------------------------------------------------
# 4. Send message (unified)
# ---------------------------------------------------------------------------
@bp.post('/messages')
@login_required
def post_message(user):
    data = request.get_json(silent=True) or {}
    text = (data.get('text') or '').strip()
    if not text:
        return _err('text required')
    if len(text) > 4000:
        return _err('text too long (max 4000)')

    chat_id = data.get('chat_id')
    channel_id = data.get('channel_id')

    if chat_id is not None and channel_id is not None:
        return _err('provide either chat_id or channel_id, not both')
    if chat_id is None and channel_id is None:
        return _err('chat_id or channel_id required')

    if chat_id is not None:
        try:
            chat_id = int(chat_id)
        except (TypeError, ValueError):
            return _err('invalid chat_id')
        chat = db.session.get(PrivateChat, chat_id)
        if not chat:
            return _err('chat not found', 404)
        # Broken Authorization protection
        if not _user_in_chat(user, chat):
            return _err('access denied', 403)
        msg = Message(body=text, author_id=user.id, private_chat_id=chat.id)
    else:
        try:
            channel_id = int(channel_id)
        except (TypeError, ValueError):
            return _err('invalid channel_id')
        ch = db.session.get(Channel, channel_id)
        if not ch:
            return _err('channel not found', 404)
        if not _user_in_channel(user, ch):
            return _err('not a member', 403)
        msg = Message(body=text, author_id=user.id, channel_id=ch.id)

    db.session.add(msg)
    db.session.commit()
    return jsonify(msg.to_dict()), 201


# ---------------------------------------------------------------------------
# 6. Search (parameterized — no SQLi)
# ---------------------------------------------------------------------------
@bp.get('/messages/search')
@login_required
def search_messages(user):
    q = (request.args.get('q') or '').strip()
    if not q:
        return _err('q parameter required')
    if len(q) > 200:
        return _err('query too long')

    member_channel_ids = [
        m.channel_id for m in
        ChannelMember.query.filter_by(user_id=user.id).all()
    ]
    chat_ids = [
        c.id for c in PrivateChat.query.filter(
            or_(PrivateChat.user1_id == user.id, PrivateChat.user2_id == user.id)
        ).all()
    ]

    if not member_channel_ids and not chat_ids:
        return jsonify({'messages': []})

    # SQLAlchemy .contains uses parameterized LIKE — safe from SQLi
    query = Message.query.filter(Message.body.contains(q))
    conditions = []
    if member_channel_ids:
        conditions.append(Message.channel_id.in_(member_channel_ids))
    if chat_ids:
        conditions.append(Message.private_chat_id.in_(chat_ids))
    query = query.filter(or_(*conditions))

    msgs = query.order_by(Message.created_at.desc()).limit(50).all()
    return jsonify({'messages': [m.to_dict() for m in msgs]})


# ---------------------------------------------------------------------------
# 7. Profile
# ---------------------------------------------------------------------------
@bp.post('/profile')
@login_required
def update_profile(user):
    data = request.get_json(silent=True) or {}
    bio = data.get('bio')
    if bio is None:
        return _err('bio field required')
    if not isinstance(bio, str):
        return _err('bio must be a string')
    if len(bio) > 2000:
        return _err('bio too long (max 2000)')
    # no mass-assignment of other fields
    user.bio = bio
    db.session.commit()
    return jsonify(user.to_public_dict())


# ---------------------------------------------------------------------------
# 8. Export (whitelist format — no path traversal)
# ---------------------------------------------------------------------------
def _export_messages(msgs, fmt: str, title: str):
    if fmt == 'json':
        import json
        payload = {
            'title': title,
            'count': len(msgs),
            'messages': [m.to_dict() for m in msgs],
        }
        body = json.dumps(payload, ensure_ascii=False, indent=2)
        return Response(body, mimetype='application/json',
                        headers={'Content-Disposition': f'attachment; filename="{title}.json"'})
    # txt
    lines = [f'# {title}', f'# messages: {len(msgs)}', '']
    for m in msgs:
        ts = m.created_at.strftime('%Y-%m-%d %H:%M:%S') if m.created_at else ''
        author = m.author.username if m.author else str(m.author_id)
        lines.append(f'[{ts}] {author}: {m.body}')
    body = '\n'.join(lines) + '\n'
    return Response(body, mimetype='text/plain; charset=utf-8',
                    headers={'Content-Disposition': f'attachment; filename="{title}.txt"'})


@bp.get('/chats/<int:chat_id>/export')
@login_required
def export_chat(user, chat_id):
    fmt = (request.args.get('format') or 'txt').lower().strip()
    if fmt not in ALLOWED_EXPORT_FORMATS:
        return _err('format must be one of: txt, json', 400)
    chat = db.session.get(PrivateChat, chat_id)
    if not chat:
        return _err('chat not found', 404)
    if not _user_in_chat(user, chat):
        return _err('access denied', 403)
    msgs = (Message.query
            .filter_by(private_chat_id=chat.id)
            .order_by(Message.created_at.asc())
            .limit(5000).all())
    return _export_messages(msgs, fmt, f'chat_{chat_id}')


@bp.get('/channels/<int:channel_id>/export')
@login_required
def export_channel(user, channel_id):
    fmt = (request.args.get('format') or 'txt').lower().strip()
    if fmt not in ALLOWED_EXPORT_FORMATS:
        return _err('format must be one of: txt, json', 400)
    ch = db.session.get(Channel, channel_id)
    if not ch:
        return _err('channel not found', 404)
    # any authenticated user can export public channel (consistent with read)
    msgs = (Message.query
            .filter_by(channel_id=ch.id)
            .order_by(Message.created_at.asc())
            .limit(5000).all())
    return _export_messages(msgs, fmt, f'channel_{channel_id}')
